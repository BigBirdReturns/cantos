"use strict";
const $ = (id) => document.getElementById(id);
const state = {catalog:null, decision:null, comparison:null, deployment:null, deploymentUploadId:null, history:[], busy:false, comparisonFile:null, deploymentFiles:[], jobDownloadUrls:[]};
const number = (x) => x !== null && x !== undefined && x !== "" && Number.isFinite(Number(x));
const fmt = (x,d=2) => number(x) ? Number(x).toLocaleString(undefined,{maximumFractionDigits:d}) : "Unknown";
const dollars = (x,d=3) => number(x) ? "$"+Number(x).toLocaleString(undefined,{minimumFractionDigits:d,maximumFractionDigits:d}) : "Cost input needed";
const arr = (x) => Array.isArray(x) ? x : (x && typeof x === "object" ? Object.values(x) : []);
const label = (x) => typeof x === "string" ? x : x?.label || x?.name || x?.model_display_name || x?.title || x?.id || x?.model || "Record";
const ident = (x) => typeof x === "string" ? x : x?.id || x?.workload_id || x?.model || x?.value || x?.name || "";
const first = (...values) => values.find(v => v !== undefined && v !== null);
function el(tag,text,cls) { const n=document.createElement(tag); if(text!==undefined&&text!==null)n.textContent=String(text); if(cls)n.className=cls; return n; }
function clear(n) { n.replaceChildren(); return n; }
function paragraph(n,text) { if(text)n.append(el("p",typeof text==="string"?text:JSON.stringify(text))); }
function evidenceBasisSummary(basis) {
  if(typeof basis==='string')return basis.length>160?basis.slice(0,157)+'…':basis;
  const records=arr(basis);if(!records.length)return 'Unknown';
  const counts=new Map(),sources=new Set();
  for(const record of records){const name=['observed','published','modeled','unknown'].includes(record?.basis)?record.basis:'unknown';counts.set(name,(counts.get(name)||0)+1);if(record?.source_sha256||record?.source)sources.add(record.source_sha256||record.source);}
  return [...counts].map(([name,count])=>count+' '+name+' inputs').join(', ')+(sources.size?' from '+sources.size+' source'+(sources.size===1?'':'s'):'')+'. Full sources and values are available below.';
}
function showMessage(text,type="error",target="global-message") { const box=$(target);box.textContent=text;box.className="notice "+type;box.hidden=!text; }
async function api(path,options={}) {
  const response=await fetch(path,{...options,headers:{"Content-Type":"application/json",...options.headers}});
  let data; try {data=await response.json();} catch {throw new Error("The local service returned an unreadable response.");}
  if(!response.ok)throw new Error(data?.error?.message || data?.message || (typeof data?.error==="string"?data.error:null) || "The request could not be completed.");
  return data;
}
function parseObject(text,label){let value;try{value=JSON.parse(text);}catch{throw new Error(label+' must be valid JSON.');}if(!value||typeof value!=='object'||Array.isArray(value))throw new Error(label+' must be a JSON object.');return value;}
function initializeDeploymentSetup(){
  const identity={implementation:{name:'',revision:''},model:{revision:'',sha256:''},tokenizer:{revision:''},hardware:{id:'',description:''},precision:'',context_limit:null,settings:{}};
  for(const arm of ['baseline','candidate'])$('deployment-'+arm+'-identity').value=JSON.stringify(identity,null,2);
  $('deployment-workload').value=JSON.stringify({schema:'cantos.maintainer.workload/1',name:'',version:'1',cases:[]},null,2);
  $('deployment-policy').value=JSON.stringify({schema:'cantos.maintainer.policy/1',allowed_changes:[],min_trials:3,min_baseline_acceptance:1,min_candidate_acceptance:1,max_acceptance_drop:0,max_new_failures:0,max_p95_latency_increase:.15,max_p95_ttft_increase:.15,max_accepted_throughput_drop:.15,require_observed_model:true,require_observed_version:false},null,2);
  $('deployment-protocol').value=JSON.stringify({trials:3,repeats:1,concurrency:1,seed:1729,timeout_s:60,max_tokens:512,warmup:0,extra_body:{}},null,2);
  $('deployment-requirements').value=JSON.stringify({objective:'min_cost_per_accepted',economics_required:true,operational_requirements:[]},null,2);
}
function jobFile(name,value){return {name,bytes:typeof value==='string'?value:JSON.stringify(value,null,2)+'\n'};}
async function prepareDeploymentJob(event){
  event.preventDefault();const button=$('deployment-prepare');button.disabled=true;showMessage('','error','deployment-setup-message');$('deployment-files').hidden=true;
  try{
    const name=$('deployment-name').value.trim();if(!name)throw new Error('Name the application work you are testing.');
    const workload=parseObject($('deployment-workload').value,'Workload');
    if(workload.schema!=='cantos.maintainer.workload/1'||!Array.isArray(workload.cases)||!workload.cases.length)throw new Error('Supply a native workload with at least one of your own application cases.');
    if(!workload.name?.trim())throw new Error('Give your workload a name.');
    if(workload.cases.some(c=>(c.steps||[c]).some(step=>step.expect?.kind==='external')))throw new Error('External-grader cases need explicit bound grade receipts through the trusted grading workflow. This preparation form currently supports exact text/JSON cases.');
    const policy=parseObject($('deployment-policy').value,'Native policy'),protocol=parseObject($('deployment-protocol').value,'Capture protocol'),decision=parseObject($('deployment-requirements').value,'Deployment requirements');
    const spec={schema:'cantos.maintainer.spec/1',workload:'workload.json',policy:'policy.json',protocol};
    const manifest={schema:'cantos.deployment-job/1',id:'deployment-'+(name.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,50)||'application')+'-'+Date.now(),comparison:{spec:'spec.json'},decision,arms:{}};
    const files=[];
    for(const arm of ['baseline','candidate']){
      const base_url=$('deployment-'+arm+'-url').value.trim(),model=$('deployment-'+arm+'-model').value.trim();
      let url;try{url=new URL(base_url);}catch{throw new Error(arm+' endpoint must be a complete URL.');}
      if(!['http:','https:'].includes(url.protocol)||url.username||url.password||url.search||url.hash)throw new Error(arm+' endpoint must be HTTP(S) without credentials, query or fragment.');
      if(!model)throw new Error('Enter the exact '+arm+' served model ID.');
      const identity=parseObject($('deployment-'+arm+'-identity').value,arm+' identity');
      for(const key of ['implementation','model','tokenizer','hardware'])if(!identity[key]||typeof identity[key]!=='object'||Array.isArray(identity[key]))throw new Error('Record '+arm+' '+key+' identity.');
      if(!identity.implementation.name||!identity.implementation.revision||!identity.model.revision||!identity.tokenizer.revision||!identity.hardware.id||!identity.precision||!Number.isFinite(identity.context_limit)||identity.context_limit<=0)throw new Error('Complete '+arm+' implementation/model/tokenizer revisions, hardware ID, precision and context limit.');
      spec[arm]={base_url,model,identity,allow_remote:!['localhost','127.0.0.1','[::1]'].includes(url.hostname)};
      manifest.arms[arm]={operations:[],resources:null};
      const resources=$('deployment-'+arm+'-resources').value.trim();if(resources){const filename=arm+'-resources.json';files.push(jobFile(filename,parseObject(resources,arm+' resources')));manifest.arms[arm].resources=filename;}
      let index=0;for(const file of $('deployment-'+arm+'-operations').files){const text=await file.text();parseObject(text,arm+' operational receipt '+file.name);const filename=arm+'-operations-'+String(index++).padStart(3,'0')+'.json';files.push(jobFile(filename,text));manifest.arms[arm].operations.push(filename);}
    }
    files.unshift(jobFile('deployment-job.json',manifest),jobFile('spec.json',spec),jobFile('workload.json',workload),jobFile('policy.json',policy),jobFile('decision-requirements.json',decision));
    for(const url of state.jobDownloadUrls)URL.revokeObjectURL(url);state.jobDownloadUrls=[];const downloads=clear($('deployment-downloads'));
    for(const file of files){const link=el('a',file.name);link.href=URL.createObjectURL(new Blob([file.bytes],{type:'application/json'}));link.download=file.name;state.jobDownloadUrls.push(link.href);downloads.append(link);}
    $('deployment-command').textContent='python -B compute/maintainer/job.py validate --manifest deployment-job.json\npython -B compute/maintainer/job.py run --manifest deployment-job.json --out new-deployment-run\npython -B compute/maintainer/job.py export --job new-deployment-run --out deployment-bundle';
    $('deployment-files').hidden=false;showMessage('Job files prepared. The native driver will validate the complete contracts before execution. Use a new output directory for each actual run.','success','deployment-setup-message');
  }catch(error){showMessage(error.message,'error','deployment-setup-message');}finally{button.disabled=false;}
}
function selectDeploymentFiles(files){state.deploymentFiles=Array.from(files);$('deployment-selected').textContent=state.deploymentFiles.length?state.deploymentFiles.length+' files selected. The manifest and every named part will be checked before upload.':'No returned bundle selected.';$('deployment-import-button').disabled=!state.deploymentFiles.length;}
function base64Bytes(bytes){let binary='';for(let i=0;i<bytes.length;i+=0x8000)binary+=String.fromCharCode(...bytes.subarray(i,i+0x8000));return btoa(binary);}
async function importDeploymentBundle(){
  const button=$('deployment-import-button');if(state.busy)return;if(state.deploymentUploadId){showMessage('Close the previous incomplete upload before starting another. Its partial evidence will be retained.','error','deployment-import-message');return;}state.busy=true;button.disabled=true;showMessage('','error','deployment-import-message');$('deployment-progress').hidden=false;$('deployment-progress').value=0;
  let uploadId;
  try{
    const files=new Map();for(const file of state.deploymentFiles){if(files.has(file.name))throw new Error('Selected folder contains duplicate filenames.');files.set(file.name,file);}
    if(!files.has('bundle.json'))throw new Error('Select the returned folder containing bundle.json and its part files.');
    const manifest=parseObject(await files.get('bundle.json').text(),'Bundle manifest');if(!Array.isArray(manifest.parts)||!manifest.parts.length)throw new Error('Bundle manifest must name its data parts.');
    const seen=new Set();let total=0;for(const part of manifest.parts){if(!part||!/^part-\d{5}\.bin$/.test(part.path)||seen.has(part.path)||!Number.isInteger(part.bytes)||part.bytes<0||part.bytes>4*1024*1024||typeof part.sha256!=='string'||!/^[a-f0-9]{64}$/.test(part.sha256))throw new Error('Bundle contains an invalid or duplicate part declaration.');seen.add(part.path);const file=files.get(part.path);if(!file||file.size!==part.bytes)throw new Error('Missing or incorrectly sized bundle part: '+part.path);total+=part.bytes;}
    if(total>1024*1024*1024)throw new Error('Bundle exceeds the 1 GiB total limit.');
    const begin=await api('/api/deployment/begin',{method:'POST',body:JSON.stringify({manifest})});if(typeof begin.upload_id!=='string'||!begin.upload_id)throw new Error('Service returned no upload identity.');uploadId=begin.upload_id;state.deploymentUploadId=uploadId;
    let sent=0;for(const part of manifest.parts){$('deployment-upload-status').textContent='Uploading '+part.path+' · '+sent+' of '+manifest.parts.length+' parts retained';const bytes=new Uint8Array(await files.get(part.path).arrayBuffer());const accepted=await api('/api/deployment/part',{method:'POST',body:JSON.stringify({upload_id:uploadId,name:part.path,base64:base64Bytes(bytes)})});if(accepted.accepted!==true)throw new Error('Service did not acknowledge part '+part.path);sent++;$('deployment-progress').value=sent/manifest.parts.length;}
    $('deployment-upload-status').textContent='Validating retained evidence and joining the deployment decision…';const record=await api('/api/deployment/finish',{method:'POST',body:JSON.stringify({upload_id:uploadId})});state.deploymentUploadId=null;$('deployment-cancel-upload').hidden=true;renderDeploymentDecision(record);await loadHistory(false);$('deployment-upload-status').textContent='Deployment decision retained. No inference or grading was replayed during import.';
  }catch(error){showMessage(error.message+(uploadId?' Upload identity '+uploadId+' is retained; no automatic retry was made.':''),'error','deployment-import-message');$('deployment-upload-status').textContent='Import stopped.';$('deployment-cancel-upload').hidden=!state.deploymentUploadId;}finally{state.busy=false;button.disabled=!state.deploymentFiles.length;}
}
async function closeDeploymentUpload(){if(state.busy||!state.deploymentUploadId)return;const button=$('deployment-cancel-upload');button.disabled=true;try{const result=await api('/api/deployment/cancel',{method:'POST',body:JSON.stringify({upload_id:state.deploymentUploadId})});if(result.cancelled!==true)throw new Error('The service did not acknowledge upload closure.');state.deploymentUploadId=null;button.hidden=true;showMessage('Incomplete upload closed. Its partial evidence remains retained; you can start a new upload.','success','deployment-import-message');}catch(error){showMessage(error.message,'error','deployment-import-message');}finally{button.disabled=false;}}
function renderDeploymentDecision(record){
  const d=record?.record||record,joined=d?.deployment_decision;if(d?.kind!=='deployment-decision'||!d.id||!joined?.state||!d.native?.verdict)throw new Error('The service returned no complete joined deployment decision.');
  state.deployment=d;$('deployment-result').hidden=false;$('deployment-result-title').textContent=d.title||'Your deployment decision';$('deployment-result-status').textContent=joined.state;
  const descriptions={'SELECT-CANDIDATE':'Candidate meets the selected useful-work, operational and economic decision requirements.','KEEP-BASELINE':'The retained evidence supports keeping the baseline under the selected requirements.','NO-ELIGIBLE':'Neither configuration qualifies under the selected deployment requirements.','INCOMPARABLE':'The native comparison cannot support a deployment preference between these observations.','INCOMPLETE':'Required evidence is incomplete.','UNDETERMINED':'The available evidence does not resolve the selected deployment decision.'};
  $('deployment-result-summary').textContent=descriptions[joined.state]||'Inspect the retained native and deployment layers below.';
  const native=clear($('deployment-native-result'));native.append(el('strong','Native useful-work verdict: '+d.native.verdict));for(const arm of ['baseline','candidate']){const side=d.native[arm]||{};paragraph(native,arm+': '+fmt(side.accepted_tasks,0)+' accepted / '+fmt(side.total_tasks,0)+' offered');}for(const reason of arr(d.native.reasons))paragraph(native,reason);if(d.post_hoc||joined.post_hoc)paragraph(native,'Post-hoc edition: the original evidence is preserved; changed requirements create a linked decision.');
  const actions=clear($('deployment-next-actions'));if(arr(joined.reversal_conditions).length||arr(joined.unknowns).length){actions.className='deployment-actions';actions.append(el('strong','What would change the decision'));const unknowns=arr(joined.unknowns).map(x=>typeof x==='string'?x:[x.layer,x.arm,x.id,x.reason].filter(Boolean).join(' · '));valueList(actions,[...arr(joined.reversal_conditions),...unknowns]);}else{actions.className='';}
  const layerHost=clear($('deployment-layers')),layers=joined.layers||{};
  for(const [key,title] of [['useful_work','A · Useful application work'],['operations','B · Operational requirements'],['economics','C · Resource economics']]){const layer=layers[key],panel=el('section',null,'panel deployment-layer');panel.append(el('div',key==='useful_work'?'Native acceptance':'Deployment evidence','panel-label'),el('h3',title));if(!layer){paragraph(panel,'Evidence not supplied.');}else if(key==='useful_work'){paragraph(panel,'Native verdict: '+(layer.verdict||d.native.verdict));}else{for(const arm of ['baseline','candidate']){const side=layer[arm];panel.append(el('h4',arm.charAt(0).toUpperCase()+arm.slice(1)));if(!side){paragraph(panel,'Unknown — no source evidence supplied.');continue;}paragraph(panel,'Status: '+(side.status||'unknown'));if(key==='operations'){if(!arr(side.gates).length)paragraph(panel,'No operational requirements selected. This does not establish operational qualification.');for(const gate of arr(side.gates))paragraph(panel,[gate.id,gate.check_id,gate.status,gate.reason].filter(Boolean).join(' · '));}else{const range=value=>Array.isArray(value)&&value.length===2?fmt(value[0])+' – '+fmt(value[1]):'Unknown';paragraph(panel,'Cost / accepted (USD scenario): '+range(side.cost_per_accepted_range));paragraph(panel,'Known subtotal (USD; partial when status is unknown): '+range(side.known_subtotal_range));paragraph(panel,'Energy / accepted (J): '+range(side.energy_per_accepted_range));paragraph(panel,'Energy boundary: '+(side.energy_scope||'unknown'));if(side.duration_basis)paragraph(panel,side.duration_basis);paragraph(panel,'Evidence basis: '+evidenceBasisSummary(side.basis));for(const unknown of arr(side.unknowns))paragraph(panel,typeof unknown==='string'?unknown:JSON.stringify(unknown));}}}const details=el('details'),summary=el('summary','Source bindings, thresholds and full layer record'),pre=el('pre',JSON.stringify(layer??null,null,2));details.append(summary,pre);panel.append(details);layerHost.append(panel);}
  if(layers.retry){
    const retry=layers.retry,panel=el('section',null,'panel deployment-retry');panel.append(el('div','Failures and retries','panel-label'),el('h3','Retry campaign accounting'));
    paragraph(panel,'Status: '+retry.status);paragraph(panel,retry.accounting);
    if(joined.economic_population==='retry_campaign')paragraph(panel,'This decision uses the complete retry campaigns for economic comparison. Native trial costs above remain a separate population and are not added to campaign costs.');
    for(const arm of ['baseline','candidate']){const side=retry.arms?.[arm];panel.append(el('h4',arm.charAt(0).toUpperCase()+arm.slice(1)));if(!side){paragraph(panel,'No bound retry campaign supplied.');continue;}paragraph(panel,fmt(side.metrics?.accepted_tasks,0)+' accepted tasks; '+fmt(side.metrics?.total_task_attempts,0)+' total attempts; '+fmt(side.metrics?.retries_total,0)+' retries.');const bounds=side.allocations?.cost_per_accepted_range;paragraph(panel,'Campaign cost / accepted including allocations (USD): '+(Array.isArray(bounds)?dollars(bounds[0],6)+' to '+dollars(bounds[1],6):'Unknown'));paragraph(panel,'Scenario subtotal / accepted before additional allocations (USD): '+dollars(side.resources?.economics?.modeled_cost_per_accepted_usd,6));}
    for(const reason of arr(retry.unknowns))paragraph(panel,reason);const details=el('details'),summary=el('summary','Retained campaign bindings and resource evidence'),pre=el('pre',JSON.stringify(retry,null,2));details.append(summary,pre);panel.append(details);layerHost.append(panel);
  }
  const id=encodeURIComponent(d.id);$('deployment-export').href='/api/export/'+id;$('deployment-export').download='deployment-decision-'+d.id+'.json';$('deployment-manifest-download').href='/api/deployment/'+id+'/manifest';$('deployment-manifest-download').download='bundle.json';$('deployment-record-id').textContent=d.id;$('deployment-result-json').textContent=JSON.stringify(d,null,2);clear($('deployment-original-parts'));loadDeploymentPartLinks(d);
}
async function loadDeploymentPartLinks(record){try{const manifest=await api('/api/deployment/'+encodeURIComponent(record.id)+'/manifest');if(state.deployment?.id!==record.id)return;const host=clear($('deployment-original-parts'));for(const part of arr(manifest.parts)){if(typeof part.path!=='string')continue;const link=el('a',part.path);link.href='/api/deployment/'+encodeURIComponent(record.id)+'/part/'+encodeURIComponent(part.path);link.download=part.path;host.append(link);}}catch(error){if(state.deployment?.id===record.id)paragraph($('deployment-original-parts'),'Original part links unavailable: '+error.message);}}
function selectOptions(node,items,preferred) {
  const previous=preferred??node.value;clear(node);
  for(const item of items){const option=el("option",label(item));option.value=ident(item);node.append(option);}
  if([...node.options].some(o=>o.value===previous))node.value=previous;
}
function kind(){return document.querySelector('input[name="kind"]:checked').value;}
function setKind(value){const n=document.querySelector('input[name="kind"][value="'+value+'"]');if(n)n.checked=true;updateMode();}
function updateMode(){
  const screen=kind()==="screening";
  $("serving-fields").hidden=screen;$("screening-fields").hidden=!screen;$("screening-options").hidden=!screen;
  for(const o of $("objective").options)o.disabled=screen&&o.value!=="min_cost";
  if(screen)$("objective").value="min_cost";
  renderCostInputs();
}
function renderCostInputs(){
  const old={};for(const n of document.querySelectorAll("[data-cost-id]"))old[n.dataset.costId]=n.value;
  const host=clear($("cost-inputs"));if(!state.catalog||kind()==="screening")return;
  const selected=$("workload").value;
  const arms=arr(state.catalog.serving_arms).filter(a=>!a.workload_id||a.workload_id===selected||a.workload===selected);
  for(const a of arms){const id=ident(a)||a.arm;const l=el("label",null,"field");l.append(el("span",label(a)));const unit=el("div",null,"input-unit");const input=el("input");input.type="number";input.min="0";input.step="0.01";input.placeholder="Source basis";input.dataset.costId=id;input.value=old[id]||"";unit.append(input,el("span","$/h"));l.append(unit);host.append(l);}
}
async function loadCatalog(){
  state.catalog=await api("/api/catalog");
  selectOptions($("workload"),arr(state.catalog.workloads));
  selectOptions($("model"),arr(state.catalog.screening_models||state.catalog.models));
  const dates=arr(state.catalog.as_of_dates||state.catalog.screening_dates||state.catalog.dates);
  selectOptions($("as-of"),dates.length?dates:[state.catalog.defaults?.as_of||"2026-11-17"]);
  $("connection-label").textContent="Local records connected";$("connection-dot").className="status-dot ready";
  const models=arr(state.catalog.screening_models||state.catalog.models).length;const providers=arr(state.catalog.providers).length;
  $("footer-status").textContent=models+" model cohorts · "+providers+" provider records";
  renderCostInputs();
  await loadOperations();
}
function requestFromForm(){
  const constraints={};
  if($("min-accepted").value!=="")constraints.min_accepted_fraction=Number($("min-accepted").value)/100;
  if($("max-ttft").value!=="")constraints.max_ttft_p95_s=Number($("max-ttft").value);
  if($("measured-only").checked)constraints.require_measured_provider=true;
  if($("no-carry").checked&&kind()==="screening")constraints.exclude_carried_prices=true;
  const costs={};for(const n of document.querySelectorAll("[data-cost-id]"))if(n.value!=="")costs[n.dataset.costId]={hourly_usd:Number(n.value)};
  return {kind:kind(),objective:$("objective").value,...(kind()==="serving"?{workload_id:$("workload").value}:{model:$("model").value,as_of:$("as-of").value}),constraints,costs,assumptions:{utilization:Number($("utilization").value)/100,notes:$("assumption-notes").value.trim()}};
}
function restoreDecisionInputs(d){
  const request=d.request||{};const constraints=request.constraints||{};const assumptions=request.assumptions||{};
  setKind(request.kind||d.kind||"serving");
  if(request.workload_id)$("workload").value=request.workload_id;
  if(request.model)$("model").value=request.model;
  if(request.as_of)$("as-of").value=request.as_of;
  renderCostInputs();
  $("objective").value=request.objective||d.objective||"min_cost";
  $("min-accepted").value=number(constraints.min_accepted_fraction)?100*constraints.min_accepted_fraction:"";
  $("max-ttft").value=number(constraints.max_ttft_p95_s)?constraints.max_ttft_p95_s:"";
  $("measured-only").checked=constraints.require_measured_provider===true;
  $("no-carry").checked=constraints.exclude_carried_prices===true;
  for(const input of document.querySelectorAll("[data-cost-id]")){const value=request.costs?.[input.dataset.costId]?.hourly_usd;input.value=number(value)?value:"";}
  $("utilization").value=100*(number(assumptions.utilization)?assumptions.utilization:1);
  $("utilization-value").textContent=$("utilization").value+"%";
  $("assumption-notes").value=assumptions.notes||"";
  $("cost-summary").textContent=$("utilization").value!=="100"||[...document.querySelectorAll("[data-cost-id]")].some(x=>x.value!=="")?"Scenario":"Retained basis";
}
async function compare(event){
  event?.preventDefault();if(state.busy)return;state.busy=true;$("compare-button").disabled=true;$("compare-button").textContent="Comparing…";showMessage("");
  try{const d=await api("/api/decision",{method:"POST",body:JSON.stringify(requestFromForm())});renderDecision(d);await loadHistory(false);}
  catch(error){showMessage(error.message);$("loading-state").hidden=true;}
  finally{state.busy=false;$("compare-button").disabled=false;$("compare-button").replaceChildren(document.createTextNode("Compare configurations "),el("span","→"));}
}
async function submitComparison(path,body){
  if(state.busy)return;state.busy=true;$('comparison-loading').hidden=false;$('comparison-detail').hidden=true;$('comparison-example-button').disabled=true;$('comparison-import-button').disabled=true;showMessage('');
  try{const record=await api(path,{method:'POST',body:JSON.stringify(body)});renderMaintainerComparison(record);await loadHistory(false);}
  catch(error){showMessage(error.message,'error','comparison-message');$('comparison-loading').hidden=true;}
  finally{state.busy=false;$('comparison-example-button').disabled=false;$('comparison-import-button').disabled=!state.comparisonFile;}
}
async function importComparison(){
  if(!state.comparisonFile)return;const file=state.comparisonFile;
  if(file.size>8*1024*1024){showMessage('Choose a comparison ZIP smaller than 8 MiB. Keep bulk evidence in the referenced source location.','error','comparison-message');return;}
  try{const bytes=new Uint8Array(await file.arrayBuffer());let binary='';const chunk=0x8000;for(let i=0;i<bytes.length;i+=chunk)binary+=String.fromCharCode(...bytes.subarray(i,i+chunk));const archive_base64=btoa(binary);await submitComparison('/api/comparison',{archive_base64,title:file.name});}
  catch(error){showMessage(error.message,'error','comparison-message');}
}
function valueList(host,items,empty='None recorded.',append=false){
  if(!append)clear(host);const values=arr(items).filter(v=>v!==null&&v!==undefined&&v!=='');
  if(!values.length){host.append(el('p',empty));return;}
  const list=el('ul');for(const value of values){const li=el('li');if(typeof value==='object'){li.textContent=JSON.stringify(value);}else li.textContent=String(value);list.append(li);}host.append(list);
}
function metricValue(value,suffix=''){return number(value)?fmt(value,3)+suffix:'Unknown';}
function renderMaintainerComparison(record){
  const d=record?.record||record;const native=d?.native||d;
  if(!d?.id||!native?.verdict)throw new Error('The service returned a comparison without its native verdict and identity.');
  state.comparison=d;$('comparison-loading').hidden=true;$('comparison-detail').hidden=false;$('comparison-title').textContent=d.title||'Serving change';$('comparison-record-type').textContent=d.post_hoc?'POST-HOC ANALYSIS · linked to original record':'ORIGINAL NATIVE VERDICT';
  const verdict=String(native.verdict).toLowerCase();const display={pass:'Pass',regression:'Regression',incomparable:'Incomparable',error:'Error'}[verdict]||verdict;
  $('comparison-verdict').textContent=display;$('comparison-verdict').className='badge verdict-'+verdict;
  const title={pass:'Candidate meets the recorded acceptance policy',regression:'Candidate has a recorded regression',incomparable:'These observations are not comparable',error:'The comparison could not be completed'}[verdict]||'Native comparison result';
  const bothMissQuality=['baseline','candidate'].every(side=>number(native[side]?.acceptance_rate)&&number(native.policy?.['min_'+side+'_acceptance'])&&native[side].acceptance_rate<native.policy['min_'+side+'_acceptance']);
  $('comparison-verdict-title').textContent=verdict==='incomparable'&&bothMissQuality?'Neither configuration meets the acceptance requirement':title;
  const next=clear($('comparison-next'));if(arr(d.what_would_change).length){next.append(el('div','What would change this answer','panel-label'));valueList(next,arr(d.what_would_change).slice(0,2),'None recorded.',true);}
  const reasons=[...arr(native.reasons),...arr(native.errors)].filter(Boolean);
  $('comparison-verdict-copy').textContent=reasons.length?reasons.join(' '):'Verdict is reported by the native comparison analyzer.';
  const counts=clear($('comparison-counts'));
  for(const [name,side] of [['Baseline',native.baseline||{}],['Candidate',native.candidate||{}]]){
    const total=Number(side.total_tasks),accepted=Number(side.accepted_tasks);const failed=Number.isFinite(total)&&Number.isFinite(accepted)?Math.max(0,total-accepted):null;
    const cell=el('div',null,'comparison-count');cell.append(el('span',name+' · accepted / total offered','metric-label'),el('strong',metricValue(side.accepted_tasks,` / ${number(side.total_tasks)?fmt(side.total_tasks,0):'?'}`)),el('span',failed===null?'Failed or unaccepted: Unknown':`Failed or unaccepted: ${fmt(failed,0)}`,'subtle'));
    const rate=number(side.acceptance_rate)?100*Number(side.acceptance_rate):null;cell.append(el('span',rate===null?'Acceptance rate: Unknown':`Acceptance rate: ${fmt(rate,1)}%`,'subtle'));
    counts.append(cell);
  }
  $('comparison-id').textContent=String(d.id);const bundle=d.bundle_url||'/api/comparison/'+encodeURIComponent(d.id)+'/bundle';$('comparison-bundle').href=bundle;$('comparison-bundle').download='original-evidence-'+d.id+'.zip';$('comparison-export').href='/api/export/'+encodeURIComponent(d.id);$('comparison-export').download='comparison-analysis-'+d.id+'.json';
  const policy=clear($('comparison-policy'));const pol=native.policy||d.original_policy||{};const pairs=Object.entries(pol);
  if(pairs.length){const list=el('dl','', 'policy-list');for(const [key,value] of pairs){const niceKey=key.replaceAll('_',' ');let shown=typeof value==='object'?JSON.stringify(value):String(value);if(typeof value==='number'&&value>=0&&value<=1&&/accept|fraction|threshold|min/i.test(key))shown=fmt(value*100,1)+'% ('+value+')';list.append(el('dt',niceKey),el('dd',shown));}policy.append(list);}else paragraph(policy,'No policy fields were provided.');
  $('comparison-policy-json').value=JSON.stringify(pol,null,2);
  valueList($('comparison-factors'),native.changed_factors);
  const ids=clear($('comparison-identities'));const identityRoot=d.identities||{};
  for(const sideName of ['baseline','candidate']){const item=identityRoot[sideName]||{};const card=el('section',null,'identity-card');card.append(el('strong',sideName[0].toUpperCase()+sideName.slice(1)));const declared=item.declared_identity||{};const observed=item.observed_identity||{};const fields=[['Model',first(declared.model,declared.model_id,declared.model_name)],['Weights',first(declared.weights_sha256,declared.weights_hash)],['Tokenizer',first(declared.tokenizer_sha256,declared.tokenizer_hash)],['Implementation',first(declared.implementation,declared.runtime,declared.serving_software)],['Hardware',first(declared.hardware,declared.accelerator,declared.gpu)],['Precision',declared.precision],['Observation',item.observation_id],['Workload SHA-256',item.workload_sha256]];let shown=0;for(const [name,value] of fields){if(value===undefined||value===null||value==='')continue;const line=el('p');line.append(el('strong',name+': '),el('span',typeof value==='object'?JSON.stringify(value):String(value)));card.append(line);shown++;}if(!shown)paragraph(card,'Declared identity unavailable.');const detail=el('details');detail.append(el('summary','Full declared, observed and protocol identity'));detail.append(el('pre',JSON.stringify({declared_identity:declared,observed_identity:observed,configuration:item.configuration,protocol:item.protocol,started_at:item.started_at,ended_at:item.ended_at,observation_id:item.observation_id,observation_identity:item.observation_identity,observation_key:item.observation_key,workload_sha256:item.workload_sha256,producer_files:item.producer_files},null,2)));card.append(detail);ids.append(card);}
  const summary=el('p');summary.append(el('strong','Analysis identity: '),el('span',d.analysis_identity===undefined?'Unknown':typeof d.analysis_identity==='object'?JSON.stringify(d.analysis_identity):String(d.analysis_identity)));ids.append(summary);
  const hashes=clear($('comparison-hashes'));for(const [heading,hashObj] of [['Observation hashes',d.observation_hashes||{}],['Input hashes, including policy and grades',d.input_hashes||{}]]){const section=el('div',null,'hash-group');section.append(el('div',heading,'panel-label'));for(const [key,value] of Object.entries(hashObj)){const line=el('p');line.append(el('strong',key+': '),el('code',typeof value==='object'?JSON.stringify(value):String(value)));section.append(line);}if(!Object.keys(hashObj).length)paragraph(section,'Unavailable.');hashes.append(section);}
  valueList($('comparison-failures'),[...arr(native.comparability_failures),...arr(native.regressions),...arr(native.errors)]);
  const performance=clear($('comparison-performance'));
  for(const [name,side] of [['Baseline',native.baseline||{}],['Candidate',native.candidate||{}]]){const line=el('p');line.append(el('strong',name+': '),el('span',`p95 latency ${metricValue(side.p95_latency_s,' s')} · p95 first token ${metricValue(side.p95_ttft_s,' s')} · accepted/s ${metricValue(side.accepted_per_s)} · cost/accepted ${number(side.cost_per_accepted)?dollars(side.cost_per_accepted):'Unknown'}`));performance.append(line);}
  const checks=el('div');checks.append(el('div','Recorded performance checks','panel-label'));valueList(checks,native.performance_checks,'No separate performance checks recorded.',true);performance.append(checks);
  const population=el('div',null,'timing-scope');population.append(el('div','Performance population','panel-label'));for(const [name,side] of [['Baseline',native.baseline||{}],['Candidate',native.candidate||{}]]){const p=el('p');p.append(el('strong',name+': '),el('span',side.performance_population===undefined?'Unknown':typeof side.performance_population==='object'?JSON.stringify(side.performance_population):String(side.performance_population)));population.append(p);}performance.append(population);
  const durations=[native.cost_duration_scope,native.baseline?.cost_duration_scope,native.candidate?.cost_duration_scope].filter(Boolean);const timingBlock=el('div',null,'timing-scope');timingBlock.append(el('div','Cost and duration scope','panel-label'));valueList(timingBlock,durations,'Not recorded.',true);const schedule=[native.trial_schedule,native.paired_trials].filter(Boolean);if(schedule.length){const title=el('div','Trial schedule','panel-label');title.style.marginTop='12px';timingBlock.append(title);valueList(timingBlock,schedule.map(v=>v===true?'Paired baseline/candidate trials':v),'None recorded.',true);}performance.append(timingBlock);
  const limits=[...arr(native.limitations),...arr(d.what_would_change)];valueList($('comparison-limitations'),limits);
  $('comparison-limitations').append(el('p','Cost per accepted task is shown only when recorded. Full-system economics such as CPU, host and facility costs remain unknown unless measured in this evidence.','subtle'));
  const execution=d.execution||{};if(Number(execution.inference_requests??native.new_inference_requests)===0||execution.retained_evidence_reused){const wording=d.post_hoc?'Post-hoc analysis reuses captured responses and existing application grades with zero new inference requests. A changed acceptance rule can change which tasks qualify; it cannot change captured responses or their grades.':'This review uses retained captures and makes zero new inference requests. Application acceptance and grades remain those recorded under the displayed policy.';const disclosure=el('p',wording,'posthoc-disclosure');$('comparison-limitations').prepend(disclosure);}
  const posthoc=!!d.post_hoc;const posthocPanel=document.querySelector('.posthoc-panel');posthocPanel.hidden=false;
  const links=clear($('posthoc-links'));if(posthoc){links.append(el('span','Post-hoc analysis · linked parent: '),el('code',d.parent_id||'Unknown'),document.createTextNode(' · original: '),el('code',d.original_id||'Unknown'));}
  $('comparison-json').textContent=JSON.stringify(d,null,2);
  $('comparison-detail').scrollIntoView({block:'start',behavior:'smooth'});
}
async function reanalyzeComparison(){
  if(!state.comparison)return;let policy;try{policy=JSON.parse($('comparison-policy-json').value);}catch{showMessage('Policy must be valid JSON.','error','comparison-message');return;}
  const button=$('comparison-reanalyze');button.disabled=true;button.textContent='Reanalyzing…';
  try{const record=await api('/api/comparison/reanalyze',{method:'POST',body:JSON.stringify({id:state.comparison.id,policy})});renderMaintainerComparison(record);await loadHistory(false);}
  catch(error){showMessage(error.message,'error','comparison-message');}
  finally{button.disabled=false;button.textContent='Reanalyze retained observations';}
}
function evidenceLabel(v){
  const s=String(v||"").toLowerCase();if(s.startsWith("operator_imported_")){if(s.includes("_observed_"))return "Imported measurement";if(s.includes("_published_"))return "Published result";if(s.includes("_modeled_"))return "Modeled result";return "Imported evidence";}if(s.includes("scenario"))return "Cost scenario";if(s.includes("published")||s.includes("listing")||s.includes("screen"))return "Published evidence";if(s.includes("observed")||s.includes("measured"))return "Measured configuration";if(s.includes("retained"))return "Retained evidence";return v||"Source-bound result";
}
function winningRow(d){
  const r=d.recommendation;const ranked=arr(d.ranked);
  if(r&&typeof r==="object"){
    if(r.configuration&&typeof r.configuration==="object")return r.configuration;
    const id=first(r.id,r.arm_id,r.configuration_id,r.candidate_id,r.winner_id);
    if(id)return ranked.find(x=>first(x.id,x.arm,x.arm_id)===id)||r;
    if(r.label||r.accepted!==undefined||r.accelerator)return r;
  }
  if(typeof r==="string")return ranked.find(x=>[x.id,x.arm,x.label].includes(r))||ranked[0];
  if(d.selected)return d.selected;
  return ranked[0];
}
function renderDecision(d){
  state.decision=d;const screen=d.kind==="screening";const winner=winningRow(d);const recommendation=d.recommendation;const ranked=arr(d.ranked);const excluded=arr(d.excluded);
  $("loading-state").hidden=true;$("decision-results").hidden=false;
  const hasChoice=!!winner && recommendation!==null && recommendation!==false;
  $("recommendation-label").textContent=screen?"Screened candidate":"Recommended configuration";
  $("recommendation-title").textContent=hasChoice?(winner.label||[winner.accelerator,winner.provider].filter(Boolean).join(" · ")||winner.id):"No configuration meets these inputs";
  const explanation=typeof recommendation==="string"&&!ranked.some(x=>x.id===recommendation)?recommendation:first(recommendation?.summary,recommendation?.reason,recommendation?.explanation,d.summary,d.message);
  $("recommendation-text").textContent=explanation||(hasChoice?(screen?"Lowest listed token cost within the selected model cohort and requirements.":"The selected objective ranks the retained configurations below. Source conditions and your assumptions remain attached."):"Review the exclusions or supply the cost inputs required by this objective.");
  $("decision-badge").textContent=(screen?"Published benchmark":evidenceLabel(first(winner?.evidence_class,d.evidence_class,"retained")))+(winner?.cost_evidence_class==="modeled"?" · modeled cost":"");
  $("primary-metric-label").textContent=screen?"Cost / million output tokens":"Cost / 1,000 accepted";
  $("primary-metric").textContent=dollars(screen?winner?.cost_per_million_tokens_usd:first(winner?.cost_per_1000_accepted_usd,winner?.usd_per_1000_accepted));
  $("secondary-metric-label").textContent=screen?"Listed GPU-hour":"Accepted / offered";
  $("secondary-metric").textContent=screen?dollars(first(winner?.usd_per_gpu_hour,winner?.hourly_usd),2):(number(winner?.accepted)?fmt(winner.accepted,0)+" / "+fmt(winner.offered,0):"Unknown");
  $("third-metric-label").textContent=screen?"Decision date":"First token · p95";
  $("third-metric").textContent=screen?first(d.request?.as_of,winner?.as_of,$("as-of").value,"Unknown"):(number(winner?.ttft_p95_s)?fmt(winner.ttft_p95_s,2)+" s":"Unknown");
  const id=d.id||d.decision_id;$("decision-id").textContent=id?String(id).slice(0,34):"";
  $("export-decision").href="/api/export/"+encodeURIComponent(id);$("export-decision").setAttribute("download","decision-"+id+".json");
  renderComparison(ranked,screen,hasChoice?winner:null);
  $("configuration-count").textContent=ranked.length+" eligible · "+excluded.length+" excluded";
  $("excluded-container").hidden=!excluded.length;$("excluded-rows").hidden=true;$("excluded-toggle").textContent="Show "+excluded.length+" excluded configurations";
  const ex=clear($("excluded-rows"));for(const row of excluded){const item=el("div",null,"excluded-item");item.append(el("strong",row.label||row.id||row.arm||"Configuration"),document.createTextNode(" · "+(arr(row.reasons).join("; ")||row.reason||"Outside requirements")));ex.append(item);}
  const basis=clear($("decision-basis"));paragraph(basis,screen?"Published throughput and listed prices are compared within the selected cohort.":"Acceptance and latency retain the workload's original evaluation rules and run conditions.");
  const assumptions=d.assumptions||d.request?.assumptions||{};
  if(number(assumptions.utilization))paragraph(basis,"Paid-time utilization: "+fmt(100*Number(assumptions.utilization),0)+"%.");
  if(assumptions.notes)paragraph(basis,assumptions.notes);
  const notes=arr(d.evidence);if(notes.length)paragraph(basis,notes.slice(0,2).map(v=>typeof v==="string"?v:(v.label||v.description||v.source||v.path||"Source identities retained in the complete decision.")).join(" "));
  if(winner?.cost_basis)paragraph(basis,winner.cost_basis);
  const limits=clear($("decision-limits"));const limitations=arr(d.limitations).filter(Boolean);
  if(limitations.length){const list=el("ul");for(const item of limitations.slice(0,5))list.append(el("li",typeof item==="string"?item:JSON.stringify(item)));limits.append(list);}else paragraph(limits,"Revisit this choice when workload, accepted quality, utilization, price or service conditions change.");
  const provider=winner?.provider_evidence;$("provider-record").hidden=!provider;
  if(provider){
    $("provider-record-title").textContent=provider.label||provider.id;
    $("provider-record-scope").textContent=provider.as_of?"Published provider record · "+provider.as_of:"Published provider coverage unknown.";
    const dims=clear($("provider-dimensions"));
    for(const [name,dimension] of Object.entries(provider.dimensions||{})){
      const cell=el("div");
      cell.append(el("span",name,"metric-label"),el("strong",String(dimension.status||"unknown").toLowerCase()),el("span",fmt(dimension.evidence_count,0)+" source items","subtle"));
      dims.append(cell);
    }
    renderRetainedOperations(clear($("provider-operations")),arr(provider.operational_evidence));
  }
  $("decision-json").textContent=JSON.stringify(d,null,2);
}
function renderComparison(rows,screen,winner){
  const table=$("comparison-table");const head=clear(table.querySelector("thead"));const body=clear(table.querySelector("tbody"));const tr=el("tr");
  const headers=screen?["Configuration","$/million output","$/GPU-hour","Price age","Evidence"]:["Configuration","$/1k accepted","Accepted","p95 first token","p95 completion"];
  for(const h of headers)tr.append(el("th",h));head.append(tr);
  if(!rows.length){const r=el("tr");const c=el("td","No eligible configuration. Exclusions below identify the missing input or unmet requirement.","table-empty");c.colSpan=5;r.append(c);body.append(r);return;}
  for(const row of rows){const r=el("tr");const rowId=first(row.id,row.arm,row.arm_id);const winnerId=first(winner?.id,winner?.arm,winner?.arm_id);const isWinner=winner&&rowId===winnerId;if(isWinner)r.className="winner";const firstCell=el("td");const name=el("span",null,"config-name");if(isWinner)name.append(el("span",null,"winner-dot"));name.append(document.createTextNode(row.label||[row.accelerator,row.provider].filter(Boolean).join(" / ")||rowId));firstCell.append(name);const detail=[row.model,row.precision||row.quantization,row.runtime||row.backend||row.serving_software].filter(Boolean).join(" · ");if(detail)firstCell.append(el("span",detail,"config-detail"));r.append(firstCell);
    r.append(el("td",dollars(screen?row.cost_per_million_tokens_usd:first(row.cost_per_1000_accepted_usd,row.usd_per_1000_accepted)),"cost-cell"));
    if(screen){r.append(el("td",dollars(first(row.usd_per_gpu_hour,row.hourly_usd),2)));r.append(el("td",number(row.carry_forward_days)?fmt(row.carry_forward_days,0)+" d":(row.price_carried_forward?"Carried":"Snapshot")));r.append(el("td","Published benchmark"));}
    else{r.append(el("td",number(row.accepted)?fmt(row.accepted,0)+" / "+fmt(row.offered,0):"Unknown"));r.append(el("td",number(row.ttft_p95_s)?fmt(row.ttft_p95_s,2)+" s":"Unknown"));r.append(el("td",number(row.latency_p95_s)?fmt(row.latency_p95_s,2)+" s":"Unknown"));}
    body.append(r);
  }
}
function setView(name){for(const v of document.querySelectorAll(".view"))v.hidden=v.id!=="view-"+name;for(const t of document.querySelectorAll(".tab")){const active=t.dataset.view===name;t.classList.toggle("active",active);t.setAttribute("aria-selected",String(active));}showMessage("");if(name==="history")loadHistory();}
async function loadHistory(render=true){
  try{const response=await api("/api/history");state.history=arr(response.items??response);$("history-count").textContent=state.history.length;if(render)renderHistory();}catch(error){if(render)showMessage(error.message);}
}
function renderHistory(){
  const host=clear($("history-list"));$("history-empty").hidden=state.history.length>0;
  for(const item of state.history){
    const isDeployment=item.kind==='deployment-decision',isComparison=item.kind==='maintainer-comparison';
    const card=el('article',null,'history-item panel'),description=el('div'),verdict=item.native_verdict||item.native?.verdict;
    const rec=isDeployment?('Deployment decision · '+(item.deployment_state||item.status||'retained')):isComparison?('Serving comparison · '+(verdict||'verdict unavailable')):(typeof item.recommendation==='string'?item.recommendation:first(item.recommendation?.label,item.recommendation?.summary,item.recommendation?.id,'Saved decision'));
    description.append(el('h3',item.title||rec));let when='';if(item.created_at){const date=new Date(item.created_at);when=Number.isNaN(date.getTime())?item.created_at:date.toLocaleString();}
    const category=isDeployment?'Joined deployment decision':isComparison?'Native maintainer comparison':item.kind==='screening'?'Token economics':'Accepted work';
    description.append(el('p',[when,item.post_hoc?'Post-hoc analysis':category,rec].filter(Boolean).join(' · ')));
    const actions=el('div',null,'history-actions'),open=el('button',isDeployment?'Open deployment decision':isComparison?'Open comparison':'Open decision','button secondary');
    open.addEventListener('click',async()=>{try{const d=await api('/api/export/'+encodeURIComponent(item.id));if(d.kind==='deployment-decision'){setView('deploy');renderDeploymentDecision(d);}else if(d.kind==='maintainer-comparison'){setView('compare');renderMaintainerComparison(d);}else{setView('catalog');restoreDecisionInputs(d);renderDecision(d);}}catch(error){showMessage(error.message);}});
    actions.append(open);
    if(isComparison){const evidence=el('a','Original evidence ZIP','text-button');evidence.href=item.bundle_url||'/api/comparison/'+encodeURIComponent(item.id)+'/bundle';evidence.download='original-evidence-'+item.id+'.zip';actions.append(evidence);}
    const download=el('a',isComparison?'Analysis JSON':isDeployment?'Decision JSON':'Export','text-button');download.href='/api/export/'+encodeURIComponent(item.id);download.download='decision-'+item.id+'.json';actions.append(download);card.append(description,actions);host.append(card);
  }
}
function attemptCounts(accepted, attempted, failed){
  return fmt(accepted,0)+"/"+fmt(attempted,0)+" accepted, "+fmt(failed,0)+" failed";
}
function renderRetainedOperations(host, operations){
  for(const record of operations){
    const details=el("details");
    const outcome=record.outcome==="verified_after_interpreter_correction"?"verified after interpreter correction":record.outcome;
    details.append(el("summary",[record.subject,record.area,"Observed · "+outcome].join(" · ")));
    paragraph(details,record.scope);
    const window=record.observed_window;
    const timeBasis=window.basis==="native_job_bounds"?"Native job window":"Receipt times";
    paragraph(details,window.start?timeBasis+" "+window.start+" to "+window.end:"Last native receipt generated "+window.end);
    if(record.area==="Storage"){
      paragraph(details,fmt(record.result.bytes,0)+" bytes · "+fmt(record.result.blocks,0)+" fsynced blocks · "+fmt(record.result.read_hash_elapsed_ms,3)+" ms read and hash");
    }else if(record.area==="Authenticated peer commands"){
      for(const variant of record.result.variants){
        const duration=variant.median_full_command_ms==null?"":" · "+fmt(variant.median_full_command_ms,1)+" ms median full command";
        paragraph(details,variant.label+" · "+attemptCounts(variant.accepted,variant.attempted,variant.failed)+duration);
        if(variant.failure_stage==="remote_shell_command_not_found_exit_127_independently_inspected"){
          paragraph(details,"The remote shell returned exit 127 because the default python executable was absent.");
        }
      }
    }else{
      const conditions=record.result.conditions;
      for(const [label,condition] of [["Intact service",conditions.normal],["Controlled restarts",conditions.restart]]){
        paragraph(details,label+" · "+attemptCounts(condition.accepted,condition.attempted,condition.failed)+" · "+fmt(condition.p95_accepted_ms,3)+" ms accepted-only p95");
      }
      const recoveries=record.result.injected_recovery_trials;
      const slowest=Math.max(...recoveries.map(trial=>trial.stop_to_recovered_s));
      paragraph(details,recoveries.length+" verified recoveries · "+fmt(slowest,3)+" s slowest recovery · "+record.native_job);
    }
    const sources=el("ul");
    for(const source of record.source_refs){
      const li=el("li");
      const link=el("a",source.path.split("/").pop());
      link.href="/"+source.path;
      li.append(link);
      sources.append(li);
    }
    details.append(sources);
    host.append(details);
  }
}
const OPERATION_LABELS={
  "ocl.operational-evidence/1":"Local operations",
  "ocl.owned-loopback-summary/1":"Loopback recovery",
  "ocl.owned-recovery-comparison/1":"Loopback recovery comparison",
  "ocl.storage-integrity-native/1":"Storage integrity",
  "ocl.storage-audit-comparison/1":"Storage readback comparison",
};
function renderImportedOperations(host, imports){
  for(const receipt of imports){
    const article=el("details");
    article.append(el("summary",receipt.label+" · Imported declaration"));
    paragraph(article,receipt.producer+" · Packet timestamp "+receipt.packet_created_at);
    const list=el("ul");
    for(const record of receipt.operations){
      const title=OPERATION_LABELS[record.schema]||record.operation.replaceAll("_"," ");
      const item=el("li",title+" · "+record.basis);
      const details=record.details;
      if(details?.conditions){
        for(const [condition,result] of Object.entries(details.conditions)){
          if(result && typeof result==="object")paragraph(item,condition+" · "+attemptCounts(result.accepted,result.attempts,result.failed));
        }
      }
      for(const finding of arr(details?.findings)){
        if(!finding?.conditions)continue;
        for(const [condition,value] of Object.entries(finding.conditions)){
          if(value && typeof value==="object")paragraph(item,(finding.label||"Host")+" "+condition+" · "+attemptCounts(value.accepted,value.attempted,value.failed));
        }
      }
      for(const hostResult of arr(details?.hosts)){
        if(hostResult && typeof hostResult==="object"){
          paragraph(item,(hostResult.host_label||"Host")+" · "+(hostResult.accepted===true?"Declared verified":"Verification not established")+" · "+fmt(hostResult.bytes,0)+" bytes");
        }
      }
      if(details?.phase==="verify"){
        paragraph(item,(details.accepted===true?"Declared verified":"Verification not established")+" · "+fmt(details.read_bytes,0)+" bytes read");
      }
      if(details?.categories && typeof details.categories==="object"){
        paragraph(item,Object.entries(details.categories).map(([category,value])=>category+" ("+(value?.evidence||"unknown")+")").join(", "));
      }
      list.append(item);
    }
    const link=el("a","Open exact imported packet");
    link.href="/api/imports/"+encodeURIComponent(receipt.id);
    article.append(list,link);
    host.append(article);
  }
}
async function loadOperations(){
  const host=clear($("operations-list"));
  try{
    const evidence=await api("/api/operations");
    paragraph(host,evidence.scope);
    if(evidence.retained_status==="verification_failed")paragraph(host,"Bundled operational records failed source verification.");
    if(evidence.retained_status==="unavailable")paragraph(host,"Bundled raw operational records are unavailable in this installation.");
    renderRetainedOperations(host,arr(evidence.retained));
    renderImportedOperations(host,arr(evidence.imports));
  }catch(error){
    paragraph(host,"Operational evidence is unavailable: "+error.message);
  }
}
async function readImportFile(file){if(!file)return;if(file.size>10*1024*1024){showMessage("Choose a packet smaller than 10 MB. Keep bulk evidence in the referenced source location.","error","import-result");return;}try{const text=await file.text();JSON.parse(text);$("import-json").value=text;showMessage(file.name+" loaded. Import to add its result records.","success","import-result");}catch(error){showMessage("The selected file is not valid JSON: "+error.message,"error","import-result");}}
async function importPacket(){const button=$("import-button");button.disabled=true;try{let packet;try{packet=JSON.parse($("import-json").value);}catch{throw new Error("Paste or choose a valid JSON result packet.");}const result=await api("/api/import",{method:"POST",body:JSON.stringify(packet)});let message="Packet retained in this session.";
if(result.status==="already_imported")message="This packet is already retained.";
else if(result.configuration_added)message="Result imported. Its configuration is available in the catalog.";
else if(Object.values(packet.operations||{}).some(value=>value&&typeof value==="object"))message="Packet retained. Operational receipts appear in the evidence below.";
showMessage(result.message||message,"success","import-result");await loadCatalog();await loadHistory(false);}catch(error){showMessage(error.message,"error","import-result");}finally{button.disabled=false;}}
document.querySelectorAll(".tab").forEach(b=>b.addEventListener("click",()=>setView(b.dataset.view)));
initializeDeploymentSetup();
setView('deploy');
$('deployment-setup-form').addEventListener('submit',prepareDeploymentJob);
$('deployment-folder').addEventListener('change',event=>selectDeploymentFiles(event.target.files));
$('deployment-import-button').addEventListener('click',importDeploymentBundle);
$('deployment-cancel-upload').addEventListener('click',closeDeploymentUpload);
document.querySelectorAll("[data-go]").forEach(b=>b.addEventListener("click",()=>setView(b.dataset.go)));
document.querySelectorAll('input[name="kind"]').forEach(n=>n.addEventListener("change",updateMode));
$("workload").addEventListener("change",renderCostInputs);$("decision-form").addEventListener("submit",compare);$("refresh-history").addEventListener("click",()=>loadHistory());
$("utilization").addEventListener("input",()=>{$("utilization-value").textContent=$("utilization").value+"%";$("cost-summary").textContent=$("utilization").value==="100"?"Retained basis":"Scenario";});
$("cost-inputs").addEventListener("input",()=>{$("cost-summary").textContent=[...document.querySelectorAll("[data-cost-id]")].some(x=>x.value!=="")?"Scenario":"Retained basis";});
$("excluded-toggle").addEventListener("click",()=>{const box=$("excluded-rows");box.hidden=!box.hidden;$("excluded-toggle").textContent=(box.hidden?"Show ":"Hide ")+arr(state.decision?.excluded).length+" excluded configurations";});
$("copy-decision").addEventListener("click",async()=>{if(!state.decision)return;try{await navigator.clipboard.writeText(JSON.stringify(state.decision,null,2));$("copy-decision").textContent="Copied";setTimeout(()=>{$("copy-decision").textContent="Copy result";},1600);}catch{$("decision-json").closest("details").open=true;$("decision-json").scrollIntoView({behavior:"smooth",block:"center"});}});
$("import-file").addEventListener("change",e=>readImportFile(e.target.files[0]));$("import-button").addEventListener("click",importPacket);
$("dropzone").addEventListener("dragover",e=>{e.preventDefault();$("dropzone").classList.add("dragover");});$("dropzone").addEventListener("dragleave",()=>$("dropzone").classList.remove("dragover"));$("dropzone").addEventListener("drop",e=>{e.preventDefault();$("dropzone").classList.remove("dragover");readImportFile(e.dataTransfer.files[0]);});
$("comparison-file").addEventListener("change",e=>{state.comparisonFile=e.target.files[0]||null;$("comparison-import-button").disabled=!state.comparisonFile;if(state.comparisonFile)showMessage(state.comparisonFile.name+" selected. Import to retain and review it.","success","comparison-message");});
$("comparison-import-button").addEventListener("click",importComparison);
$("comparison-example-button").addEventListener("click",()=>submitComparison("/api/comparison/example",{}));
$("comparison-reanalyze").addEventListener("click",reanalyzeComparison);
$("comparison-dropzone").addEventListener("dragover",e=>{e.preventDefault();$("comparison-dropzone").classList.add("dragover");});
$("comparison-dropzone").addEventListener("dragleave",()=>$("comparison-dropzone").classList.remove("dragover"));
$("comparison-dropzone").addEventListener("drop",e=>{e.preventDefault();$("comparison-dropzone").classList.remove("dragover");const file=e.dataTransfer.files[0];if(file){state.comparisonFile=file;$("comparison-import-button").disabled=false;showMessage(file.name+" selected. Import to retain and review it.","success","comparison-message");}});
(async()=>{try{await loadCatalog();await loadHistory(false);}catch(error){$("connection-label").textContent="Start the local workbench service";$("connection-dot").className="status-dot error";showMessage(location.protocol==="file:"?"Open this workbench through its local service. Run the command in WORKBENCH.md, then open http://127.0.0.1:8841/. The evidence report also opens directly as a file.":error.message);}})();
