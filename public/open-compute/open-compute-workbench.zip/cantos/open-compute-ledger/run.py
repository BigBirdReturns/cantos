"""Launch the Cantos Open Compute workbench using Python's standard library."""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser


def default_store() -> Path:
    if os.name == "nt":
        base = Path(os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData" / "Local")))
    else:
        base = Path(os.environ.get("XDG_DATA_HOME", str(Path.home() / ".local" / "share")))
    return base / "Cantos" / "Open-Compute-Ledger"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--store", type=Path, default=default_store(), help="Persistent decisions and imported measurement packets")
    parser.add_argument("--port", type=int, default=8841)
    parser.add_argument("--database", type=Path, help="Optional full retained benchmark/price database")
    parser.add_argument("--open", action="store_true", help="Open the workbench once in the default browser")
    args = parser.parse_args()
    if not 1024 <= args.port <= 65535:
        parser.error("Choose a port from 1024 to 65535.")
    root = Path(__file__).resolve().parent
    args.store.mkdir(parents=True, exist_ok=True)
    address = f"http://127.0.0.1:{args.port}/"
    command = [sys.executable, "-B", str(root / "engine" / "engine.py"), "serve", "--store", str(args.store.resolve()), "--port", str(args.port)]
    if args.database:
        command.extend(["--database", str(args.database.resolve())])
    print(f"Open Compute Workbench: {address}", flush=True)
    print(f"Decisions and imports: {args.store.resolve()}", flush=True)
    process = subprocess.Popen(command, cwd=str(root.parent))
    if args.open:
        def open_once() -> None:
            for _ in range(50):
                if process.poll() is not None:
                    return
                try:
                    with urllib.request.build_opener(urllib.request.ProxyHandler({})).open(address + "api/catalog", timeout=0.5) as response:
                        if response.status == 200 and response.headers.get("Server", "").startswith("OpenComputeLedger/"):
                            webbrowser.open(address)
                            return
                except (OSError, TimeoutError):
                    time.sleep(0.1)
        threading.Thread(target=open_once, daemon=True).start()
    try:
        return process.wait()
    except KeyboardInterrupt:
        process.terminate()
        try:
            return process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            return process.wait()


if __name__ == "__main__":
    raise SystemExit(main())
