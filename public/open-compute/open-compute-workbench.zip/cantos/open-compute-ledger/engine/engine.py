"""Local Open Compute Ledger decision service over retained native evidence.

No inference or acquisition is hidden in a decision. Import is data-only, and all
mutable state stays in the explicitly selected session store.
"""
from __future__ import annotations

import argparse
import copy
from datetime import datetime, timezone
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import importlib.util
import json
import math
import mimetypes
from pathlib import Path
import re
import sqlite3
import socket
import sys
import threading
from urllib.parse import unquote, urlsplit

HERE = Path(__file__).resolve().parent
PACKAGE = HERE.parent
MAX_BODY = 8 * 1024 * 1024
ID_RE = re.compile(r"^[a-f0-9]{64}$")
INSTRUMENT_SCHEMA = "ocl.instrument-packet/1"


class LedgerError(ValueError):
    def __init__(self, code, message, status=400):
        self.code, self.status = code, status
        super().__init__(message)


def encoded(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=False,
                       separators=(",", ":"), allow_nan=False) + "\n").encode("utf-8")


def digest(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def number(value, name, minimum=0, maximum=None, nullable=False):
    if value is None and nullable:
        return None
    if type(value) not in (int, float) or not math.isfinite(value):
        raise LedgerError("invalid_number", name + " must be a finite number")
    if value < minimum or (maximum is not None and value > maximum):
        raise LedgerError("invalid_number", name + " is outside its supported range")
    return value


def object_value(value, name):
    if not isinstance(value, dict):
        raise LedgerError("invalid_object", name + " must be an object")
    return value


def text_value(value, name, maximum=1000):
    if not isinstance(value, str) or not value.strip() or len(value) > maximum:
        raise LedgerError("invalid_text", name + " must be nonempty text of bounded length")
    return value


def source_ref(path, root=PACKAGE):
    data = Path(path).read_bytes()
    return {"path": str(Path(path).relative_to(root)).replace("\\", "/"),
            "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}


def load_native_costs(package):
    path = package / "instruments/controller/ocl/costs.py"
    spec = importlib.util.spec_from_file_location("ocl_retained_costs", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.estimate_cost


class Store:
    """Content-addressed immutable packets and decisions; no payload paths used."""
    def __init__(self, path):
        self.path = Path(path).resolve()
        self.lock = threading.RLock()
        for kind in ("decisions", "imports"):
            (self.path / kind).mkdir(parents=True, exist_ok=True)

    def _path(self, kind, identity):
        if kind not in ("decisions", "imports") or not ID_RE.fullmatch(identity):
            raise LedgerError("invalid_id", "Expected a complete content identifier")
        path = (self.path / kind / (identity + ".json")).resolve()
        if not path.is_relative_to(self.path):
            raise LedgerError("invalid_path", "Store path escapes its root")
        return path

    def save(self, kind, body):
        identity = digest(body)
        result = {"id": identity, **body}
        path = self._path(kind, identity)
        payload = encoded(result)
        with self.lock:
            try:
                with path.open("xb") as handle:
                    handle.write(payload)
            except FileExistsError:
                if path.read_bytes() != payload:
                    raise LedgerError("store_integrity", "Existing content differs from its identifier", 409)
        return result

    def get(self, kind, identity):
        path = self._path(kind, identity)
        try:
            result = read_json(path)
        except FileNotFoundError:
            raise LedgerError("not_found", "No retained item has that identifier", 404)
        body = {k: v for k, v in result.items() if k != "id"}
        if result.get("id") != identity or digest(body) != identity:
            raise LedgerError("store_integrity", "Retained content failed its identity check", 409)
        return result

    def items(self, kind):
        with self.lock:
            paths = sorted((self.path / kind).glob("*.json"))
            return [self.get(kind, p.stem) for p in paths]


def provider_key(value):
    aliases = {"hot_aisle": "hotaisle", "hot-aisle": "hotaisle",
               "primeintellect": "prime-intellect", "digitalocean": "digitalocean"}
    return aliases.get(value.lower(), value.lower())


class Ledger:
    def __init__(self, package, store, database=None):
        self.package = Path(package).resolve()
        self.store = store if isinstance(store, Store) else Store(store)
        self.database = Path(database).resolve() if database else None
        self.native_cost = load_native_costs(self.package)
        self.refs = {}
        self.tables = self._read("inputs/arms/table.json")
        self.provider_rows = self._read("inputs/providers/ratings.json")
        self.coverage = self._read("inputs/providers/COVERAGE-FACTS.json")
        self.screening = self._read("inputs/data/decisions/EVIDENCE.json")
        self.synthetic = self._read("inputs/controller/ocl11-cross-accelerator-decision.json")
        self.timings = self._read("inputs/controller/ocl11-reviewed-timings-20261117.json")
        self.refs["cost_owner"] = source_ref(self.package / "instruments/controller/ocl/costs.py", self.package)
        self._database_cache = {}
        self._database_lock = threading.Lock()

    def _read(self, relative):
        path = self.package / relative
        self.refs[relative] = source_ref(path, self.package)
        return read_json(path)

    def provider(self, slug):
        key = provider_key(slug)
        row = next((r for r in self.provider_rows if provider_key(r["slug"]) == key), None)
        if row is None:
            return {"id": slug, "label": slug, "evidence_class": "unknown",
                    "distance_to_floor": None, "unknown_count": None, "dimensions": {},
                    "source_refs": []}
        return {"id": row["slug"], "label": row["provider"],
                "as_of": row["as_of"], "evidence_class": row["evidence_class"],
                "distance_to_floor": row["distance_to_floor"],
                "unknown_count": row["unknown_count"], "dimensions": row["dimensions"],
                "short_labels": row["short_labels"], "incident_facts": row.get("incident_facts"),
                "source_refs": [self.refs["inputs/providers/ratings.json"]]}

    def serving_rows(self):
        rows = []
        providers = {"mi300x": "hotaisle", "h100": "digitalocean",
                     "mi210": "local-run-b", "rtx8000": "local-run-c"}
        for raw in self.tables:
            arm = raw["arm"]
            workload = "run3" if raw["workload"] == "Run 3" else "agentx-profiles"
            offered = raw.get("scheduled")
            accepted = raw.get("accepted")
            provider = providers.get(arm, "local-profile-a")
            rows.append({"id": arm, "label": raw["hardware"], "provider": provider,
                "accelerator": raw["hardware"].split("1x ")[-1], "model": raw["model"],
                "precision": raw["quantization"], "runtime": raw["serving_software"],
                "workload_id": workload, "workload_identity": raw["workload_id"],
                "offered": offered, "sent": raw.get("sent"), "completed": raw.get("completed"),
                "correct": raw.get("correct"), "accepted": accepted,
                "acceptance_fraction": accepted / offered if accepted is not None and offered else None,
                "failed": raw.get("failed"), "failures": raw.get("failures", {}),
                "latency_p95_s": raw.get("e2e_p95_s"), "ttft_p95_s": raw.get("ttft_p95_s"),
                "window_s": raw["window_s"], "observed_at": raw["window_start_utc"],
                "board_energy_wh": raw.get("board_energy_wh"),
                "output_tokens": raw.get("output_tokens"), "cost_usd": raw.get("cost_usd"),
                "cost_per_1000_accepted_usd": raw.get("usd_per_1000_accepted"),
                "default_hourly_usd": raw["cost_usd"] * 3600 / raw["window_s"] if raw.get("cost_usd") is not None else None,
                "cost_per_million_tokens_usd": None,
                "cost_basis": raw["cost_basis"], "cost_evidence_class": "modeled",
                "evidence_class": "observed_retained_run" if workload == "run3" else "ungraded_profile",
                "provider_measurement_observed": workload == "run3",
                "provider_evidence": self.provider(provider),
                "grading_status": raw["grading_status"],
                "reasons": [], "source_refs": [self.refs["inputs/arms/table.json"]],
                "limits": ["Retained workload and arrival schedule; configuration changes include runtime and precision.",
                           "Latency percentiles cover completed requests; failures remain in offered counts.",
                           "Price basis excludes components stated in the retained methods; no full invoice or facility cost."]})
        for key, host in (("fourb", "local-profile-a"), ("zeropointsix", "local-run-c")):
            raw = self.synthetic[key]
            timing = self.timings["configs"][key]
            offered = self.synthetic["matched"]["offered"]
            rows.append({"id": "lookup-" + key, "label": raw["model"] + " / " + raw["accelerator"],
                "provider": host, "accelerator": raw["accelerator"], "model": raw["model"],
                "precision": None, "runtime": raw["backend"], "workload_id": "lookup-60",
                "workload_identity": self.synthetic["input_equivalence_sha256"],
                "offered": offered, "sent": None, "completed": None, "correct": None,
                "accepted": raw["accepted"], "acceptance_fraction": raw["accepted"] / offered,
                "failed": None, "failures": {"not_accepted": offered - raw["accepted"]},
                "attempts": raw["attempts"], "latency_p95_s": None, "ttft_p95_s": None,
                "window_s": timing["total_task_windows_s"], "observed_at": self.synthetic["generated_utc"],
                "board_energy_wh": None, "partial_board_energy_wh": raw["board_bracketed_wh"],
                "output_tokens": raw["reported_output_tokens"], "cost_usd": None,
                "cost_per_1000_accepted_usd": None, "cost_per_million_tokens_usd": None,
                "cost_basis": "Unknown complete cost; supply a sourced scenario to compare economics",
                "cost_evidence_class": "unknown", "evidence_class": "observed_synthetic_tasks",
                "provider_measurement_observed": True, "provider_evidence": self.provider(host),
                "grading_status": "Exact application acceptance retained for five seeded batches",
                "reasons": [], "source_refs": [self.refs["inputs/controller/ocl11-cross-accelerator-decision.json"],
                                                self.refs["inputs/controller/ocl11-reviewed-timings-20261117.json"]],
                "limits": [self.synthetic["comparison_class"], *self.timings["limitations"]]})
        for item in self.store.items("imports"):
            projection = self._import_projection(item)
            if projection:
                rows.append(projection)
        return rows

    def catalog(self):
        rows = self.serving_rows()
        workloads = [
            {"id": "run3", "label": "Graded coding at the retained Run 3 load", "kind": "graded",
             "acceptance_definition": "EvalPlus base + plus pass; first token <=1 s and completion <=60 s from scheduled arrival",
             "default_objective": "min_cost", "identity": self.tables[0]["workload_id"]},
            {"id": "lookup-60", "label": "60 source-equivalent exact-data tasks", "kind": "synthetic",
             "acceptance_definition": "Exact application validator over five seeded 12-task batches; all attempts retained",
             "default_objective": "max_acceptance", "identity": self.synthetic["input_equivalence_sha256"]},
            {"id": "agentx-profiles", "label": "AgentX profiles with ungraded outcomes", "kind": "agentic",
             "acceptance_definition": "Application correctness unknown; two different trace sets",
             "default_objective": "min_latency", "identity": None}]
        for row in rows:
            if not any(w["id"] == row["workload_id"] for w in workloads):
                workloads.append({"id": row["workload_id"], "label": row.get("workload_label", row["workload_id"]),
                                  "kind": "imported", "identity": row["workload_identity"],
                                  "default_objective": "max_acceptance",
                                  "acceptance_definition": row.get("acceptance_definition")})
        models = {}
        for row in self.screening["rows"]:
            entry = models.setdefault(row["model"], {"id": row["model"], "label": row["model_display_name"],
                "dates": [], "precision": row["precision"], "scenario": row["scenario"],
                "input_tokens": row["input_tokens"], "output_tokens": row["output_tokens"]})
            if row["as_of"] not in entry["dates"]:
                entry["dates"].append(row["as_of"])
        imports = self.store.items("imports")
        for entry in models.values():
            entry["as_of_dates"] = sorted(entry["dates"], reverse=True)
        return {"schema": "ocl.catalog/1", "workloads": workloads, "serving_arms": rows,
                "screening_models": sorted(models.values(), key=lambda x: x["label"]),
                "as_of_dates": sorted({r["as_of"] for r in self.screening["rows"]}, reverse=True),
                "providers": [self.provider(p["slug"]) for p in self.provider_rows],
                "provider_coverage": self.coverage,
                "imports": [{"id": i["id"], "created_at": i["created_at"],
                             "label": i["packet"].get("provenance", {}).get("label", "Imported instrument result"),
                             "has_useful_work": bool(i["packet"].get("acceptance")),
                             "has_operations": bool(i["packet"].get("operations")),
                             "has_inventory": bool(i["packet"].get("host_inventory"))} for i in imports],
                "defaults": {"workload_id": "run3", "objective": "min_cost", "utilization": 1,
                             "as_of": max(r["as_of"] for r in self.screening["rows"])},
                "capabilities": {"bulk_database": bool(self.database), "live_inference": False,
                                 "import_schema": INSTRUMENT_SCHEMA, "portable_decisions": True},
                "coverage": {"serving_configurations": len(rows), "provider_records": len(self.provider_rows),
                             "retained_screening_rows": len(self.screening["rows"]),
                             "screening_mode": "all eligible pairs from the configured native database" if self.database else "retained top-three screened operands",
                             "bulk_database_configured": bool(self.database),
                             "provider_evidence_basis": "Published claims with separately scoped observed campaigns",
                             "market_scope": "Covered sources and methods; no claim of an exhaustive market optimum"},
                "source_refs": list(self.refs.values())}

    def _bulk_rows(self, day, no_carry):
        if not self.database:
            return None
        stat = self.database.stat()
        key = (day, no_carry, stat.st_size, stat.st_mtime_ns)
        with self._database_lock:
            if key in self._database_cache:
                return copy.deepcopy(self._database_cache[key])
            market = self.package.parent / "hot-aisle/campaign/market"
            backfill = market.parent / "backfill"
            for p in (market, backfill):
                if str(p) not in sys.path:
                    sys.path.insert(0, str(p))
            spec = importlib.util.spec_from_file_location("ocl_native_screening", market / "decision_table.py")
            owner = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(owner)
            db = sqlite3.connect(self.database.as_uri() + "?mode=ro", uri=True)
            db.row_factory = sqlite3.Row
            try:
                snapshot = owner.snapshot(db, day, not no_carry, limit=None)
            finally:
                db.close()
            selected = {}
            for row in sorted(snapshot["coverage"], key=lambda r: (-r["logical_points"], str(owner.cohort(r)))):
                if row["eligible"]:
                    selected.setdefault(row["model"], owner.cohort(row))
            result = [r for cohort in selected.values() for r in snapshot["rankings"][cohort]]
            self._database_cache[key] = result
            return copy.deepcopy(result)

    def screening_rows(self, request):
        model = text_value(request.get("model"), "model", 160)
        day = request.get("as_of") or max(r["as_of"] for r in self.screening["rows"])
        try:
            datetime.strptime(day, "%Y-%m-%d")
        except (TypeError, ValueError):
            raise LedgerError("invalid_date", "as_of must be YYYY-MM-DD")
        no_carry = bool(request.get("constraints", {}).get("exclude_carried_prices", False))
        raw_rows = self._bulk_rows(day, no_carry)
        data_scope = "existing native database screening" if raw_rows is not None else "retained screened shortlist"
        if raw_rows is None:
            raw_rows = self.screening["no_carry_rows" if no_carry else "rows"]
        rows = []
        for raw in raw_rows:
            if raw["model"] != model or raw["as_of"] != day:
                continue
            source = [self.refs["inputs/data/decisions/EVIDENCE.json"]]
            if data_scope == "existing native database screening":
                source = [{"kind": "native_screening_query", "date": day,
                           "method": "hot-aisle/campaign/market/decision_table.py:snapshot",
                           "cost_observation_id": raw["cost_observation_id"], "price_id": raw["price_id"]}]
            rows.append({"id": raw["accelerator"].lower() + "-" + raw["provider"] + "-" + raw["price_id"][:12],
                "label": raw["accelerator"] + " / " + raw["provider"], "provider": raw["provider"],
                "accelerator": raw["accelerator"], "model": raw["model_display_name"],
                "precision": raw["precision"], "runtime": raw["framework"], "as_of": day,
                "accepted": None, "offered": None, "acceptance_fraction": None,
                "latency_p95_s": None, "ttft_p95_s": None,
                "cost_per_1000_accepted_usd": None,
                "cost_per_million_tokens_usd": raw["usd_per_million_output_tokens"],
                "usd_per_gpu_hour": raw["usd_per_gpu_hour"],
                "output_tokens_per_second_per_gpu": raw["output_tokens_per_second_per_gpu"],
                "gpu_count": raw["benchmark_allocated_gpus"], "concurrency": raw["concurrency"],
                "benchmark_date": raw["benchmark_date"], "price_carried_forward": raw["price_carried_forward"],
                "carry_forward_days": raw["carry_forward_days"], "price_region": raw["price_region"],
                "evidence_class": "published_benchmark_and_price_scenario", "cost_evidence_class": "modeled",
                "provider_measurement_observed": False, "provider_evidence": self.provider(raw["provider"]),
                "cost_basis": raw["accounting_basis"], "data_scope": data_scope,
                "source_refs": source, "operands": raw, "reasons": [],
                "limits": [raw["configuration_limit"], raw["cost_date_basis"],
                           ("Ranks compare all eligible pairs returned by the existing source-screening method; this is bounded source coverage." if self.database else
                            "Ranks compare the retained top-three shortlist; changed constraints do not establish a market-wide optimum.")]})
        return rows

    def _apply_cost(self, row, override, utilization, kind):
        result = copy.deepcopy(row)
        override = object_value(override or {}, "cost override")
        allowed = {"hourly_usd", "run_cost_usd", "components", "source", "basis"}
        if set(override) - allowed:
            raise LedgerError("unknown_cost_field", "Unsupported cost fields: " + ", ".join(sorted(set(override) - allowed)))
        selected = sum(k in override for k in ("hourly_usd", "run_cost_usd", "components"))
        if selected > 1:
            raise LedgerError("ambiguous_cost", "Choose hourly_usd, run_cost_usd or components")
        if kind == "screening":
            if "run_cost_usd" in override or "components" in override:
                raise LedgerError("unsupported_cost", "Token screening accepts hourly_usd per GPU")
            price = number(override.get("hourly_usd", row["usd_per_gpu_hour"]), "hourly_usd")
            result["cost_per_million_tokens_usd"] = price * 1e6 / (3600 * row["output_tokens_per_second_per_gpu"] * utilization)
            result["usd_per_gpu_hour"] = price
        elif "components" in override:
            if row.get("accepted") is None:
                return result
            number(row.get("window_s"), "measured window_s", minimum=0.000001)
            calculation = self.native_cost({"duration_s": row["window_s"], "accepted_tasks": row["accepted"]},
                                           object_value(override["components"], "components"))
            result["cost_calculation"] = calculation
            result["cost_usd"] = calculation["total_usd"]
            result["cost_per_1000_accepted_usd"] = calculation["modeled_cost_per_accepted_usd"] * 1000 if calculation["modeled_cost_per_accepted_usd"] is not None else None
            result["cost_basis"] = "Existing ocl.costs.estimate_cost with explicit components"
        else:
            if "run_cost_usd" in override:
                cost = number(override["run_cost_usd"], "run_cost_usd")
                basis = "User-supplied total run-cost scenario; includes the supplied scope only"
            elif "hourly_usd" in override:
                number(row.get("window_s"), "measured window_s", minimum=0.000001)
                cost = number(override["hourly_usd"], "hourly_usd") * row["window_s"] / (3600 * utilization)
                basis = "User-supplied all-configuration hourly scenario; reserved-time allocation at stated utilization"
            else:
                cost = row["cost_usd"] / utilization if row.get("cost_usd") is not None else None
                basis = row["cost_basis"] if isinstance(row["cost_basis"], str) else json.dumps(row["cost_basis"], sort_keys=True)
                if utilization != 1:
                    basis += "; uniform reserved-cost allocation scenario divided by utilization, holding performance fixed"
            result["cost_usd"] = cost
            accepted = row.get("accepted")
            result["cost_per_1000_accepted_usd"] = cost * 1000 / accepted if cost is not None and accepted else None
            result["cost_basis"] = basis
        if override or utilization != 1:
            result["cost_evidence_class"] = "user_scenario"
            result["cost_override"] = override
        result["utilization_assumed"] = utilization
        return result

    def decide(self, request):
        request = copy.deepcopy(object_value(request, "decision"))
        kind = request.get("kind", "serving")
        if kind not in ("serving", "screening"):
            raise LedgerError("unsupported_kind", "kind must be serving or screening")
        objective = request.get("objective", "min_cost")
        if objective not in ("min_cost", "max_acceptance", "min_latency"):
            raise LedgerError("unsupported_objective", "Unknown decision objective")
        if kind == "screening" and objective != "min_cost":
            raise LedgerError("unsupported_objective", "Token screening ranks modeled token cost; acceptance and latency are unknown")
        constraints = object_value(request.get("constraints", {}), "constraints")
        known_constraints = {"max_ttft_p95_s", "max_latency_p95_s", "min_accepted_fraction",
                             "require_measured_provider", "exclude_carried_prices", "max_price_age_days",
                             "providers", "max_gpu_count"}
        if set(constraints) - known_constraints:
            raise LedgerError("unknown_constraint", "Unsupported constraints: " + ", ".join(sorted(set(constraints) - known_constraints)))
        for field in ("require_measured_provider", "exclude_carried_prices"):
            if field in constraints and type(constraints[field]) is not bool:
                raise LedgerError("invalid_constraint", field + " must be a boolean")
        assumptions = object_value(request.get("assumptions", {}), "assumptions")
        utilization = number(assumptions.get("utilization", 1), "utilization", minimum=0.000001, maximum=1)
        costs = object_value(request.get("costs", {}), "costs")
        if kind == "serving":
            workload = request.get("workload_id", "run3")
            rows = [r for r in self.serving_rows() if r["workload_id"] == workload]
        else:
            workload = request.get("model")
            rows = self.screening_rows(request)
        if not rows:
            raise LedgerError("no_coverage", "No retained observations cover that selection; choose a catalog option or import an outcome", 422)
        unknown_cost_ids = set(costs) - {r["id"] for r in rows}
        if unknown_cost_ids:
            raise LedgerError("unknown_configuration", "Cost overrides name unavailable configuration IDs: " + ", ".join(sorted(unknown_cost_ids)))
        ranked, excluded = [], []
        for raw in rows:
            row = self._apply_cost(raw, costs.get(raw["id"], {}), utilization, kind)
            reasons = []
            for field, metric in (("max_ttft_p95_s", "ttft_p95_s"), ("max_latency_p95_s", "latency_p95_s"),
                                  ("max_gpu_count", "gpu_count")):
                if constraints.get(field) is not None:
                    bound = number(constraints[field], field)
                    if row.get(metric) is None:
                        reasons.append(metric + " is unobserved")
                    elif row[metric] > bound:
                        reasons.append(metric + " exceeds " + str(bound))
            if constraints.get("min_accepted_fraction") is not None:
                bound = number(constraints["min_accepted_fraction"], "min_accepted_fraction", maximum=1)
                if row.get("acceptance_fraction") is None:
                    reasons.append("Application acceptance is unobserved")
                elif row["acceptance_fraction"] < bound:
                    reasons.append("Acceptance fraction is below " + str(bound))
            if constraints.get("require_measured_provider") and not row["provider_measurement_observed"]:
                reasons.append("This configuration has no direct workload measurement at this provider")
            if constraints.get("max_price_age_days") is not None:
                age = number(constraints["max_price_age_days"], "max_price_age_days")
                if row.get("price_carried_forward"):
                    if row.get("carry_forward_days") is None or row["carry_forward_days"] > age:
                        reasons.append("Carried price exceeds the requested known-age limit")
            if constraints.get("providers"):
                allowed = constraints["providers"]
                if not isinstance(allowed, list) or any(not isinstance(v, str) for v in allowed):
                    raise LedgerError("invalid_providers", "providers must be a list of provider IDs")
                if row["provider"] not in allowed:
                    reasons.append("Provider is outside the selected set")
            if kind == "serving" and row.get("accepted") is None:
                reasons.append("Application outcomes have not been graded")
            metric = ("cost_per_million_tokens_usd" if kind == "screening" else "cost_per_1000_accepted_usd") if objective == "min_cost" else ("acceptance_fraction" if objective == "max_acceptance" else "latency_p95_s")
            if row.get(metric) is None:
                reasons.append(metric + " is unknown for this objective")
            row["reasons"] = reasons
            row["reason"] = "; ".join(reasons) if reasons else "Meets the requested constraints on this evidence"
            (excluded if reasons else ranked).append(row)
        ranked.sort(key=lambda r: ((-r["acceptance_fraction"] if objective == "max_acceptance" else r[metric]), r["id"]))
        for rank, row in enumerate(ranked, 1):
            row["rank"] = rank
        recommendation = copy.deepcopy(ranked[0]) if ranked else None
        explanation = ("Lowest modeled cost among the selected eligible retained configurations" if objective == "min_cost" else
                       "Highest observed accepted fraction among the selected eligible configurations" if objective == "max_acceptance" else
                       "Lowest observed p95 latency among the selected eligible configurations")
        if kind == "screening":
            explanation += " within " + ("the configured database's screened source coverage" if self.database else "the retained top-three shortlist")
        refs = {digest(ref): ref for row in rows for ref in row["source_refs"]}
        used_imports = {ref["import_id"] for row in rows for ref in row["source_refs"] if "import_id" in ref}
        limits = list(dict.fromkeys(limit for row in rows for limit in row.get("limits", [])))
        if kind == "screening":
            limits.append("This decision screens listed candidates; allocation availability and provider execution are unobserved.")
        elif workload == "run3":
            limits.append("The local configurations were overloaded at this retained arrival schedule; lower-load capacity is a separate question.")
        result = {"schema": "ocl.decision/1", "created_at": utc_now(),
                  "title": request.get("title") or ("Serving decision" if kind == "serving" else "Token-cost shortlist"),
                  "kind": kind, "objective": objective, "workload_id": workload,
                  "request": request, "status": "decision_available" if recommendation else "no_eligible_configuration",
                  "recommendation": recommendation, "explanation": explanation if recommendation else "No retained configuration meets all supplied conditions",
                  "ranked": ranked, "excluded": excluded, "assumptions": {**assumptions, "utilization": utilization},
                  "evidence": {"source_refs": list(refs.values()), "native_cost_owner": self.refs["cost_owner"],
                               "import_packets": [self.store.get("imports", identity) for identity in sorted(used_imports)]},
                  "limitations": limits, "calculation_identity": digest({"request": request, "rows": rows, "engine_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}),
                  "execution": {"inference_run": False, "network_acquisition": False, "retained_evidence_reused": True}}
        return self.store.save("decisions", result)

    def import_packet(self, packet):
        packet = copy.deepcopy(object_value(packet, "packet"))
        if packet.get("schema") != INSTRUMENT_SCHEMA:
            raise LedgerError("unsupported_schema", "Expected " + INSTRUMENT_SCHEMA)
        provenance = object_value(packet.get("provenance"), "provenance")
        useful_work_basis = packet.get("useful_work_basis", "unknown")
        if useful_work_basis not in ("observed", "published", "modeled", "unknown"):
            raise LedgerError("invalid_basis", "useful_work_basis must be observed, published, modeled or unknown")
        text_value(provenance.get("producer"), "provenance.producer")
        stamp = text_value(provenance.get("captured_at"), "provenance.captured_at", 100)
        try:
            parsed = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
            if parsed.tzinfo is None:
                raise ValueError()
        except ValueError:
            raise LedgerError("invalid_timestamp", "captured_at must include its timezone")
        files = packet.get("files", [])
        if not isinstance(files, list) or len(files) > 10000:
            raise LedgerError("invalid_manifest", "files must be a bounded manifest list")
        for entry in files:
            object_value(entry, "file manifest entry")
            text_value(entry.get("path"), "manifest path", 4096)
            if not isinstance(entry.get("sha256"), str) or not ID_RE.fullmatch(entry["sha256"]):
                raise LedgerError("invalid_manifest", "Each manifest item needs its full SHA256")
        acceptance = packet.get("acceptance")
        if acceptance:
            object_value(acceptance, "acceptance")
            for key in ("scheduled", "offered", "sent", "completed", "correct", "accepted", "failed"):
                if acceptance.get(key) is not None:
                    if type(acceptance[key]) is not int or acceptance[key] < 0:
                        raise LedgerError("invalid_count", key + " must be a nonnegative integer")
            offered = acceptance.get("offered", acceptance.get("scheduled"))
            accepted = acceptance.get("accepted")
            if accepted is not None and offered is not None and accepted > offered:
                raise LedgerError("invalid_acceptance", "Accepted count exceeds offered count")
            if offered is not None and any(acceptance.get(key) is not None and acceptance[key] > offered for key in ("sent", "completed", "correct")):
                raise LedgerError("invalid_acceptance", "Task count exceeds offered count; HTTP attempts belong in metrics")
            for larger, smaller in (("completed", "correct"), ("correct", "accepted"), ("sent", "completed"), ("completed", "accepted")):
                if acceptance.get(larger) is not None and acceptance.get(smaller) is not None and acceptance[smaller] > acceptance[larger]:
                    raise LedgerError("invalid_acceptance", smaller + " exceeds " + larger)
            if accepted is not None:
                workload = object_value(packet.get("workload"), "workload")
                text_value(workload.get("id"), "workload.id", 200)
                text_value(workload.get("identity"), "workload.identity", 300)
                text_value(workload.get("acceptance_definition"), "workload.acceptance_definition", 5000)
                object_value(packet.get("configuration"), "configuration")
        for kind in ("costs", "energy"):
            if not isinstance(packet.get(kind, []), list):
                raise LedgerError("invalid_measurement", kind + " must be a list")
            for entry in packet.get(kind, []):
                object_value(entry, kind + " item")
                number(entry.get("value"), kind + ".value", nullable=True)
                if entry.get("basis") not in ("observed", "modeled", "published", "unknown"):
                    raise LedgerError("invalid_basis", kind + " basis must retain observed, modeled, published or unknown")
        metrics = object_value(packet.get("metrics", {}), "metrics")
        for key in ("window_s", "ttft_p95_s", "e2e_p95_s", "output_tokens", "board_energy_wh"):
            if metrics.get(key) is not None:
                number(metrics[key], "metrics." + key)
        packet_hash = digest(packet)
        with self.store.lock:
            for retained in self.store.items("imports"):
                if retained["packet_sha256"] == packet_hash:
                    return {"id": retained["id"], "status": "already_imported", "packet_sha256": packet_hash,
                            "configuration_added": bool(self._import_projection(retained))}
            result = self.store.save("imports", {"schema": "ocl.import/1", "created_at": utc_now(),
                "packet_sha256": packet_hash, "packet": packet,
                "evidence_class": "operator_imported_" + useful_work_basis + "_useful_work",
                "useful_work_basis": useful_work_basis,
                "verification": "Packet bytes retained; external-file hashes are declarations unless their bytes are included"})
        return {"id": result["id"], "status": "imported", "packet_sha256": packet_hash,
                "configuration_added": bool(self._import_projection(result))}

    def _import_projection(self, item):
        packet = item["packet"]
        useful_work_basis = packet.get("useful_work_basis", "unknown")
        if useful_work_basis not in ("observed", "published", "modeled", "unknown"):
            useful_work_basis = "unknown"  # Old stored imports did not validate this optional field.
        acceptance = packet.get("acceptance") or {}
        if acceptance.get("accepted") is None:
            return None
        conf, work, metrics = packet.get("configuration", {}), packet.get("workload", {}), packet.get("metrics", {})
        # Matching a familiar label alone never merges an imported workload.
        workload_id = "imported-" + digest({"id": work.get("id"), "identity": work.get("identity"),
            "acceptance_definition": work.get("acceptance_definition")})[:16]
        offered = acceptance.get("offered", acceptance.get("scheduled"))
        costs = [c for c in packet.get("costs", []) if c.get("unit") == "USD" and c.get("scope") in ("run", "whole_run", "complete_run") and c.get("value") is not None]
        total = costs[0]["value"] if len(costs) == 1 else None
        accepted = acceptance["accepted"]
        provider = conf.get("provider", packet["provenance"].get("label", "imported"))
        return {"id": "import-" + item["id"][:24], "label": conf.get("label", conf.get("id", "Imported configuration")),
            "provider": provider, "accelerator": conf.get("accelerator"), "model": conf.get("model"),
            "runtime": conf.get("runtime"), "precision": conf.get("precision"),
            "workload_id": workload_id, "workload_label": work.get("label", work.get("id")),
            "workload_identity": work.get("identity"), "acceptance_definition": work.get("acceptance_definition"),
            "accepted": accepted, "offered": offered, "sent": acceptance.get("sent"),
            "completed": acceptance.get("completed"), "correct": acceptance.get("correct"),
            "failed": acceptance.get("failed"), "failures": packet.get("failures", {}),
            "acceptance_fraction": accepted / offered if offered else None,
            "latency_p95_s": metrics.get("e2e_p95_s"), "ttft_p95_s": metrics.get("ttft_p95_s"),
            "window_s": metrics.get("window_s"), "observed_at": packet["provenance"]["captured_at"],
            "cost_usd": total, "cost_per_1000_accepted_usd": total * 1000 / accepted if total is not None and accepted else None,
            "cost_per_million_tokens_usd": None, "cost_basis": costs[0] if len(costs) == 1 else "Complete run cost unknown",
            "cost_evidence_class": costs[0]["basis"] if len(costs) == 1 else "unknown",
            "evidence_class": "operator_imported_" + useful_work_basis + "_useful_work",
            "useful_work_basis": useful_work_basis,
            "provider_measurement_observed": useful_work_basis == "observed",
            "provider_evidence": self.provider(provider), "reasons": [],
            "source_refs": [{"import_id": item["id"], "packet_sha256": item["packet_sha256"], "provenance": packet["provenance"]}],
            "limits": ["Operator-supplied outcome; content identity preserves custody and does not authenticate its source.", *work.get("limits", [])]}

    def history(self):
        items = sorted(self.store.items("decisions"), key=lambda x: x["created_at"], reverse=True)
        return {"items": [{k: v for k, v in row.items() if k in ("id", "created_at", "title", "kind", "objective", "status", "workload_id", "recommendation")}
                          for row in items]}


class ExclusiveHTTPServer(ThreadingHTTPServer):
    # Windows must reject a collision instead of sharing another app's listener.
    allow_reuse_address = False

    def server_bind(self):
        if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()


def handler_for(ledger):
    class Handler(BaseHTTPRequestHandler):
        server_version = "OpenComputeLedger/1"

        def _host(self):
            host = urlsplit("http://" + self.headers.get("Host", "")).hostname
            if host not in ("localhost", "127.0.0.1"):
                raise LedgerError("invalid_host", "This service accepts loopback hostnames only", 403)

        def _json(self, value, status=200):
            body = encoded(value)
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            self.wfile.write(body)

        def _error(self, error):
            self._json({"error": {"code": error.code, "message": str(error)}}, error.status)

        def do_GET(self):
            try:
                self._host()
                path = unquote(urlsplit(self.path).path)
                if path == "/api/catalog":
                    return self._json(ledger.catalog())
                if path == "/api/history":
                    return self._json(ledger.history())
                if path.startswith("/api/export/"):
                    return self._json(ledger.store.get("decisions", path.removeprefix("/api/export/")))
                if path.startswith("/api/imports/"):
                    return self._json(ledger.store.get("imports", path.removeprefix("/api/imports/")))
                if path.startswith("/api/"):
                    raise LedgerError("not_found", "Unknown API path", 404)
                if path == "/":
                    path = "/workbench.html"
                target = (ledger.package / path.lstrip("/")).resolve()
                if not target.is_relative_to(ledger.package) or any(part.startswith(".") for part in Path(path).parts):
                    raise LedgerError("invalid_path", "Static path escapes the package", 403)
                if not target.is_file():
                    raise LedgerError("not_found", "Requested package file is unavailable", 404)
                body = target.read_bytes()
                mime = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
                self.send_response(200)
                self.send_header("Content-Type", mime + ("; charset=utf-8" if mime.startswith("text/") else ""))
                self.send_header("Content-Length", str(len(body)))
                self.send_header("X-Content-Type-Options", "nosniff")
                self.send_header("Cache-Control", "no-cache")
                self.end_headers()
                self.wfile.write(body)
            except LedgerError as error:
                self._error(error)
            except (ValueError, TypeError, OSError) as error:
                self._error(LedgerError("data_error", str(error), 422))

        def do_POST(self):
            try:
                self._host()
                origin = self.headers.get("Origin")
                if origin and origin != "http://" + self.headers.get("Host", ""):
                    raise LedgerError("invalid_origin", "Cross-origin mutation is disabled", 403)
                if self.headers.get("Content-Type", "").split(";", 1)[0].strip() != "application/json":
                    raise LedgerError("invalid_content_type", "Send application/json", 415)
                try:
                    size = int(self.headers.get("Content-Length", "0"))
                except ValueError:
                    raise LedgerError("invalid_length", "Invalid content length")
                if size <= 0 or size > MAX_BODY:
                    raise LedgerError("body_limit", "JSON request must be 1 byte to 8 MiB", 413)
                payload = json.loads(self.rfile.read(size))
                path = urlsplit(self.path).path
                if path == "/api/decision":
                    return self._json(ledger.decide(payload), 201)
                if path == "/api/import":
                    return self._json(ledger.import_packet(payload), 201)
                raise LedgerError("not_found", "Unknown API path", 404)
            except LedgerError as error:
                self._error(error)
            except (ValueError, TypeError, OSError) as error:
                self._error(LedgerError("data_error", str(error), 422))

        def log_message(self, format_string, *args):
            # Request bodies and imported data never enter access logs.
            sys.stderr.write("%s %s\n" % (self.log_date_time_string(), format_string % args))
    return Handler


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("serve", "run", "decide", "catalog", "history", "import", "export"))
    parser.add_argument("--store", type=Path, required=True, help="Writable local session store; retained sources stay read-only")
    parser.add_argument("--package", type=Path, default=PACKAGE)
    parser.add_argument("--database", type=Path, help="Optional local joined costs.sqlite, opened read-only")
    parser.add_argument("--host", choices=("127.0.0.1", "localhost"), default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8841)
    parser.add_argument("--request", type=Path)
    parser.add_argument("--id")
    parser.add_argument("--out", type=Path, help="Optional explicit CLI export destination")
    args = parser.parse_args(argv)
    ledger = Ledger(args.package, args.store, args.database)
    if args.command in ("serve", "run"):
        server = ExclusiveHTTPServer((args.host, args.port), handler_for(ledger))
        print(json.dumps({"url": "http://" + args.host + ":" + str(server.server_port) + "/", "store": str(ledger.store.path)}), flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass
        finally:
            server.server_close()
        return 0
    if args.command in ("decide", "import"):
        if not args.request:
            parser.error("--request is required")
        result = ledger.decide(read_json(args.request)) if args.command == "decide" else ledger.import_packet(read_json(args.request))
    elif args.command == "catalog":
        result = ledger.catalog()
    elif args.command == "history":
        result = ledger.history()
    else:
        if not args.id:
            parser.error("--id is required")
        result = ledger.store.get("decisions", args.id)
    if args.out:
        args.out.write_bytes(encoded(result))
        print(json.dumps({"path": str(args.out), "id": result.get("id")}), flush=True)
    else:
        print(json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False), flush=True)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except LedgerError as error:
        print(json.dumps({"error": {"code": error.code, "message": str(error)}}), file=sys.stderr)
        raise SystemExit(2)
