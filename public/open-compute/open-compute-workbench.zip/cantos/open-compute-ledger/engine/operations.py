"""Scope portable workbench operational declarations and optional native evidence."""
from __future__ import annotations

import importlib.util
from pathlib import Path

OPERATIONS_BASIS = frozenset(("observed", "published", "modeled", "simulated", "unknown"))
DETAILS = {
    "ocl.operational-evidence/1": ("started_utc", "ended_utc", "categories"),
    "ocl.owned-loopback-summary/1": ("conditions", "executed_restarts", "planned_restarts"),
    "ocl.owned-recovery-comparison/1": ("findings",),
    "ocl.storage-integrity-native/1": ("utc", "phase", "bytes", "read_bytes", "accepted", "verdict"),
    "ocl.storage-audit-comparison/1": ("hosts",),
}


def retained_operations(package):
    snapshot = package / "inputs/controller-latest/SNAPSHOT.json"
    if not snapshot.is_file():
        return []
    path = Path(__file__).with_name("retained_operations.py")
    spec = importlib.util.spec_from_file_location("ocl_retained_operations", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.retained_operations(package)


def imported_operations(item):
    """Summarize importer-declared operation identities and point to the exact packet."""
    packet = item["packet"]
    operations = packet.get("operations")
    if not isinstance(operations, dict):
        return None
    basis = packet.get("operations_basis")
    basis = basis if isinstance(basis, dict) else {}
    entries = []
    for name, value in operations.items():
        if not isinstance(value, dict):
            continue
        declaration = basis.get(name)
        schema = value.get("schema")
        result = {"operation": name, "schema": schema if isinstance(schema, str) else None,
                  "basis": declaration if isinstance(declaration, str) and declaration in OPERATIONS_BASIS else "unknown"}
        if result["schema"] in DETAILS:
            result["details"] = {key: value[key] for key in DETAILS[result["schema"]] if key in value}
        entries.append(result)
    if not entries:
        return None
    provenance = packet["provenance"]
    return {"id": item["id"], "label": provenance.get("label", "Imported instrument result"),
            "producer": provenance["producer"], "packet_created_at": provenance["captured_at"],
            "packet_sha256": item["packet_sha256"], "verification": "operator_declaration",
            "operations": entries}
