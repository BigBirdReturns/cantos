"""Data-only comparison imports, validated by the shipped native analyzer.

Uploaded Python is evidence only. Only this package's native_maintainer is imported.
"""
import base64
import binascii
import hashlib
import importlib
import io
import json
import math
from pathlib import Path, PurePosixPath
import re
import stat
import sys
import tempfile
import zipfile

MAX_ARCHIVE = 8 * 1024 * 1024
MAX_EXPANDED = 64 * 1024 * 1024
MAX_FILES = 10000
CORE = ("verdict", "exit_code", "baseline", "candidate", "policy", "errors",
        "comparability_failures", "regressions", "changed_factors", "performance_checks")
VIEW = CORE + ("reasons", "paired_trials", "trial_schedule", "scope", "limitations", "new_inference_requests")
RESERVED = re.compile(r"^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)", re.I)


def _json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("Duplicate JSON key: " + key)
            result[key] = value
        return result
    def bad(value):
        raise ValueError("Nonfinite JSON value: " + value)
    return json.loads(raw.decode("utf-8"), object_pairs_hook=pairs, parse_constant=bad)


def _bytes(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode("utf-8")


def _sha(raw):
    return hashlib.sha256(raw).hexdigest()


def safe_path(name):
    if not isinstance(name, str) or not name or len(name) > 240 or "\\" in name or ":" in name:
        raise ValueError("Unsafe comparison archive path")
    path = PurePosixPath(name)
    if path.is_absolute() or path.as_posix() != name or any(
            p in (".", "..") or p.endswith((" ", ".")) or RESERVED.match(p)
            or any(ord(c) < 32 for c in p) or any(c in '<>"|?*' for c in p)
            for p in path.parts):
        raise ValueError("Unsafe comparison archive path: " + name)
    return name


def unpack(raw, root):
    """Validate all names, sizes and hashes before writing any member."""
    if not isinstance(raw, bytes) or not raw or len(raw) > MAX_ARCHIVE:
        raise ValueError("Comparison archive must be 1 byte to 8 MiB")
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as archive:
            infos = archive.infolist()
            if not 1 <= len(infos) <= MAX_FILES or sum(i.file_size for i in infos) > MAX_EXPANDED:
                raise ValueError("Comparison archive exceeds expanded limits")
            names, folded, content = set(), set(), {}
            for info in infos:
                name = safe_path(info.filename)
                mode = info.external_attr >> 16
                if info.is_dir() or (stat.S_IFMT(mode) not in (0, stat.S_IFREG)) or info.flag_bits & 1:
                    raise ValueError("Comparison archive permits regular unencrypted files only")
                if name in names or name.casefold() in folded:
                    raise ValueError("Duplicate or case-colliding archive path")
                names.add(name)
                folded.add(name.casefold())
                content[name] = archive.read(info)
                if len(content[name]) != info.file_size:
                    raise ValueError("Invalid archive member size")
            # Also refuse file/directory collisions, including case-insensitive hosts.
            for name in names:
                for parent in PurePosixPath(name).parents:
                    if parent.as_posix().casefold() in folded:
                        raise ValueError("Archive file/directory collision")
    except (zipfile.BadZipFile, NotImplementedError, RuntimeError) as exc:
        raise ValueError("Invalid comparison ZIP: " + str(exc)) from exc
    if "comparison.json" not in content:
        raise ValueError("Missing comparison.json")
    manifest = _json(content["comparison.json"])
    if not isinstance(manifest, dict) or manifest.get("schema") != "cantos.comparison-bundle/1":
        raise ValueError("Unsupported comparison bundle schema")
    entries = manifest.get("files")
    if not isinstance(entries, list):
        raise ValueError("Comparison files must be a manifest array")
    declared = set()
    for entry in entries:
        if not isinstance(entry, dict) or set(entry) != {"path", "sha256", "bytes"}:
            raise ValueError("Invalid comparison manifest entry")
        name = safe_path(entry["path"])
        if name == "comparison.json" or name in declared or name not in content:
            raise ValueError("Invalid comparison manifest membership")
        declared.add(name)
        if type(entry["bytes"]) is not int or entry["bytes"] != len(content[name]) or entry["sha256"] != _sha(content[name]):
            raise ValueError("Comparison manifest hash or size mismatch: " + name)
    if declared != names - {"comparison.json"}:
        raise ValueError("Comparison manifest must enumerate every evidence file")
    inputs = manifest.get("inputs")
    required = {"baseline", "candidate", "policy"}
    if not isinstance(inputs, dict) or not required <= set(inputs) or set(inputs) - required - {"grading_contract", "baseline_grades", "candidate_grades"}:
        raise ValueError("Invalid comparison input paths")
    for name in [*inputs.values(), manifest.get("original_analysis")]:
        if safe_path(name) not in declared:
            raise ValueError("Comparison input is absent from manifest")
    for name, data in content.items():
        target = root / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    return manifest


def _native():
    # The search root is trusted installed source, never the extracted archive.
    here = Path(__file__).resolve().parent
    if str(here) not in sys.path:
        sys.path.insert(0, str(here))
    module = importlib.import_module("native_maintainer.maintainer")
    if not Path(module.__file__).resolve().is_relative_to(here / "native_maintainer"):
        raise ValueError("Native analyzer did not resolve inside installed trusted source")
    return module


def _preflight_cardinality(root, inputs):
    """Bound native expected-pair construction before the analyzer materializes it."""
    common = importlib.import_module("native_maintainer.common")
    for side in ("baseline", "candidate"):
        run_path = root / inputs[side]
        run = _json(run_path.read_bytes())
        if not isinstance(run, dict) or not isinstance(run.get("protocol"), dict):
            raise ValueError(side + " comparison protocol must be an object")
        proto = common.protocol(run["protocol"])
        # Require integers in the receipt itself, without defaults or coercion.
        for field in ("trials", "repeats"):
            if type(run["protocol"].get(field)) is not int:
                raise ValueError(side + " protocol." + field + " must be an integer")
        workload = _json((run_path.parent / "workload.json").read_bytes())
        cases = workload.get("cases") if isinstance(workload, dict) else None
        observations = run.get("observations")
        if not isinstance(cases, list) or not cases or not isinstance(observations, list):
            raise ValueError(side + " comparison requires workload cases and observations arrays")
        expected = proto["trials"] * proto["repeats"] * len(cases)
        if not 1 <= expected <= 100000 or expected != len(observations):
            raise ValueError(side + " comparison observation cardinality must match trials × repeats × cases and be at most 100000")


def analyze(raw, revised_policy=None):
    with tempfile.TemporaryDirectory(prefix="cantos-comparison-") as temp:
        root = Path(temp)
        manifest = unpack(raw, root)
        inputs = manifest["inputs"]
        original_policy = _json((root / inputs["policy"]).read_bytes())
        claimed = _json((root / manifest["original_analysis"]).read_bytes())
        module = _native()
        _preflight_cardinality(root, inputs)
        selected = original_policy if revised_policy is None else revised_policy
        if not isinstance(selected, dict):
            raise ValueError("Comparison policy must be an object")
        # New policy lives outside the uploaded evidence closure.
        with tempfile.TemporaryDirectory(prefix="cantos-comparison-analysis-") as work:
            work = Path(work)
            policy = work / "policy.json"
            policy.write_bytes(_bytes(selected))
            result = module.analyze_receipts(
                root / inputs["baseline"], root / inputs["candidate"], policy, work / "analysis",
                baseline_grades=root / inputs["baseline_grades"] if inputs.get("baseline_grades") else None,
                candidate_grades=root / inputs["candidate_grades"] if inputs.get("candidate_grades") else None,
                grading_contract=root / inputs["grading_contract"] if inputs.get("grading_contract") else None)
        # The native function reports malformed data as error; that is not a
        # successfully validated comparison and cannot become a retained result.
        if not all(field in result for field in ("baseline", "candidate", "policy")):
            raise ValueError("Native evidence validation failed: " + "; ".join(result.get("reasons", [])))
        if revised_policy is None:
            for field in CORE:
                if field not in claimed or _bytes(claimed[field]) != _bytes(result[field]):
                    raise ValueError("Claimed comparison differs from native recomputation: " + field)
        native = {key: result[key] for key in VIEW if key in result}
        hashes = {side: _sha((root / inputs[side]).read_bytes()) for side in ("baseline", "candidate")}
        evidence = {"input_hashes": {name: _sha((root / path).read_bytes()) for name, path in inputs.items()},
                    "identities": {}}
        for side in ("baseline", "candidate"):
            run = _json((root / inputs[side]).read_bytes())
            evidence["identities"][side] = {key: run.get(key) for key in (
                "declared_identity", "observed_identity", "configuration", "protocol", "started_at", "ended_at",
                "observation_id", "observation_identity", "observation_key", "workload_sha256", "producer_files")}
        validation = {"basis": "current_trusted_analyzer", "analysis_producer_files": result["analysis_producer_files"],
                      "comparison_adapter_sha256": _sha(Path(__file__).read_bytes()),
                      "original_analysis_sha256": _sha((root / manifest["original_analysis"]).read_bytes()),
                      "source_difference": result.get("analysis_producer_files") != claimed.get("analysis_producer_files"),
                      "meaning": "Current shipped analyzer revalidated retained raw evidence and grades; no new observation or grader execution."}
        return native, original_policy, hashes, validation, evidence


def _decode(value):
    if not isinstance(value, str) or len(value) > ((MAX_ARCHIVE + 2) // 3) * 4:
        raise ValueError("Comparison archive exceeds encoded limit")
    try:
        return base64.b64decode(value, validate=True)
    except (ValueError, binascii.Error) as exc:
        raise ValueError("Invalid comparison archive_base64") from exc


def _response(record):
    return {**record, "bundle_url": "/api/comparison/" + record["id"] + "/bundle"}


def retain(ledger, raw, title=None, parent=None, revised_policy=None):
    if title is not None and (not isinstance(title, str) or not title.strip() or len(title) > 300):
        raise ValueError("Comparison title must be nonempty text up to 300 characters")
    native, original_policy, hashes, validation, evidence = analyze(raw, revised_policy)
    identity = _sha(_bytes({"archive_sha256": _sha(raw), "policy": native["policy"],
                           "validator": validation["analysis_producer_files"],
                           "adapter": validation["comparison_adapter_sha256"], "parent_id": parent["id"] if parent else None}))
    with ledger.store.lock:
        for record in ledger.store.items("decisions"):
            if record.get("kind") == "maintainer-comparison" and record.get("analysis_identity") == identity:
                return _response(record)
        archive = ledger.store.save("imports", {"schema": "cantos.comparison-archive/1", "kind": "comparison",
                                               "archive_sha256": _sha(raw), "archive_base64": base64.b64encode(raw).decode("ascii")})
        from datetime import datetime, timezone
        record = ledger.store.save("decisions", {
            "schema": "cantos.comparison-decision/1", "kind": "maintainer-comparison",
            "created_at": datetime.now(timezone.utc).isoformat(),
            "title": title or (parent["title"] if parent else "Retained maintainer comparison"),
            "status": native["verdict"], "native_verdict": native["verdict"], "native": native,
            "original_policy": original_policy, "post_hoc": parent is not None,
            "parent_id": parent["id"] if parent else None,
            "original_id": (parent.get("original_id") or parent["id"]) if parent else None,
            "archive_id": archive["id"], "observation_hashes": hashes, "analysis_identity": identity,
            "input_hashes": evidence["input_hashes"], "identities": evidence["identities"],
            "validation": validation,
            "what_would_change": _changes(native),
            "execution": {"inference_requests": 0, "grading_executions": 0, "retained_evidence_reused": True}})
    return _response(record)


def _changes(native):
    actions = []
    for side in ("baseline", "candidate"):
        metric = native[side]
        required = math.ceil(native["policy"]["min_" + side + "_acceptance"] * metric["total_tasks"] - 1e-12)
        if metric["accepted_tasks"] < required:
            actions.append(side.capitalize() + " accepted " + str(metric["accepted_tasks"]) + " of " +
                           str(metric["total_tasks"]) + "; the selected requirement needs at least " +
                           str(required) + ". New qualifying application evidence is needed. Prices cannot repair acceptance.")
    for reason in native.get("errors", []) + native.get("comparability_failures", []) + native.get("regressions", []):
        actions.append("Resolve the native gate: " + reason)
    return list(dict.fromkeys(actions))


def import_request(ledger, request):
    if not isinstance(request, dict) or set(request) - {"archive_base64", "title"}:
        raise ValueError("Send archive_base64 and optional title")
    title = request.get("title")
    if title is not None and (not isinstance(title, str) or not title.strip() or len(title) > 200):
        raise ValueError("Comparison title must be nonempty text up to 200 characters")
    return retain(ledger, _decode(request.get("archive_base64")), title)


def bundle(ledger, identity):
    record = ledger.store.get("decisions", identity)
    if record.get("kind") != "maintainer-comparison":
        raise ValueError("This decision is not a maintainer comparison")
    archive = ledger.store.get("imports", record["archive_id"])
    raw = _decode(archive["archive_base64"])
    if _sha(raw) != archive["archive_sha256"]:
        raise ValueError("Retained comparison archive failed identity validation")
    return raw


def reanalyze(ledger, request):
    if not isinstance(request, dict) or set(request) != {"id", "policy"}:
        raise ValueError("Send retained comparison id and complete policy")
    parent = ledger.store.get("decisions", request["id"])
    if not isinstance(request["policy"], dict):
        raise ValueError("Comparison policy must be an object")
    return retain(ledger, bundle(ledger, request["id"]), parent=parent, revised_policy=request["policy"])
