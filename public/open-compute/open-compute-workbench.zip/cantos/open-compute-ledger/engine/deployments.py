"""Bounded deployment-bundle uploads and trusted native decision reproduction."""
import base64
import binascii
from datetime import datetime, timezone
import hashlib
import importlib
import json
from pathlib import Path
import re
import sys
import uuid

ID = re.compile(r"^[0-9a-f]{32}$")


def _native(name):
    here = Path(__file__).resolve().parent
    if str(here) not in sys.path:
        sys.path.insert(0, str(here))
    module = importlib.import_module("native_maintainer." + name)
    if not Path(module.__file__).resolve().is_relative_to(here / "native_maintainer"):
        raise ValueError("Deployment analyzer must resolve inside trusted installed source")
    return module


def _encoded(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def _root(ledger, identity):
    if not isinstance(identity, str) or not ID.fullmatch(identity):
        raise ValueError("Invalid deployment upload identity")
    return ledger.store.path / "deployment-uploads" / identity


def _manifest(ledger, identity):
    root = _root(ledger, identity)
    common, transport = _native("common"), _native("deployment_bundle")
    return root, transport.validate_manifest(common.load(root / "bundle.json"))


def begin(ledger, request):
    if not isinstance(request, dict) or set(request) != {"manifest"}:
        raise ValueError("Send deployment bundle manifest")
    manifest = _native("deployment_bundle").validate_manifest(request["manifest"])
    with ledger.store.lock:
        folder = ledger.store.path / "deployment-uploads"
        folder.mkdir(exist_ok=True)
        active = [p for p in folder.iterdir() if p.is_dir() and not (p / "terminal.json").exists()]
        if len(active) >= 2:
            raise ValueError("Two deployment uploads are already active; finish or cancel one")
        identity = uuid.uuid4().hex
        root = _root(ledger, identity)
        root.mkdir()
        _native("common").write(root / "bundle.json", manifest)
    return {"upload_id": identity, "parts": len(manifest["parts"])}


def part(ledger, request):
    if not isinstance(request, dict) or set(request) != {"upload_id", "name", "base64"}:
        raise ValueError("Send upload_id, name and base64")
    with ledger.store.lock:
        root, manifest = _manifest(ledger, request["upload_id"])
        if (root / "terminal.json").exists():
            raise ValueError("Deployment upload has already ended")
        entry = next((p for p in manifest["parts"] if p["path"] == request["name"]), None)
        if entry is None:
            raise ValueError("Undeclared deployment part")
        value = request["base64"]
        if not isinstance(value, str) or len(value) > ((entry["bytes"] + 2) // 3) * 4:
            raise ValueError("Encoded deployment part exceeds declared size")
        try:
            raw = base64.b64decode(value, validate=True)
        except (ValueError, binascii.Error) as error:
            raise ValueError("Invalid deployment part encoding") from error
        if len(raw) != entry["bytes"] or hashlib.sha256(raw).hexdigest() != entry["sha256"]:
            raise ValueError("Deployment part hash or size mismatch")
        target = root / entry["path"]
        if target.exists():
            if target.read_bytes() != raw:
                raise ValueError("Existing deployment part differs")
        else:
            with target.open("xb") as stream:
                stream.write(raw)
                stream.flush()
                import os
                os.fsync(stream.fileno())
    return {"accepted": True, "name": entry["path"]}


def cancel(ledger, request):
    if not isinstance(request, dict) or set(request) != {"upload_id"}:
        raise ValueError("Send upload_id")
    with ledger.store.lock:
        root, _ = _manifest(ledger, request["upload_id"])
        if not (root / "terminal.json").exists():
            _native("common").write(root / "terminal.json", {"status": "cancelled", "retained": True})
    return {"cancelled": True, "partial_evidence_retained": True}


def finish(ledger, request):
    if not isinstance(request, dict) or set(request) - {"upload_id", "title"} or "upload_id" not in request:
        raise ValueError("Send upload_id and optional title")
    title = request.get("title", "Deployment decision")
    if not isinstance(title, str) or not title.strip() or len(title) > 300:
        raise ValueError("Deployment title must be nonempty text up to 300 characters")
    with ledger.store.lock:
        root, manifest = _manifest(ledger, request["upload_id"])
        terminal = root / "terminal.json"
        if terminal.exists():
            prior = _native("common").load(terminal)
            if prior.get("record_id"):
                return ledger.store.get("decisions", prior["record_id"])
            raise ValueError("This upload already ended; original files are retained")
        # Missing parts allow resuming this same upload identity.
        for entry in manifest["parts"]:
            if not (root / entry["path"]).is_file():
                raise ValueError("Upload missing part: " + entry["path"])
        try:
            decision = _native("job").import_job(root, root / "reproduction")
            native = decision.get("native", {})
            body = {"schema": "cantos.deployment-workbench-record/1", "kind": "deployment-decision",
                    "created_at": datetime.now(timezone.utc).isoformat(), "title": title,
                    "status": decision.get("state"), "native_verdict": native.get("verdict"), "native": native,
                    "deployment_decision": decision, "post_hoc": bool(decision.get("post_hoc")),
                    "parent_id": decision.get("parent_id"), "original_id": decision.get("original_id"),
                    "transport_id": request["upload_id"],
                    "transport_sha256": hashlib.sha256(_encoded(manifest)).hexdigest(),
                    "execution": {"inference_requests": 0, "grading_executions": 0,
                                  "retained_evidence_reused": True,
                                  "meaning": "Imported evidence re-evaluated by installed native code."}}
            record = ledger.store.save("decisions", body)
            _native("common").write(terminal, {"status": "retained", "record_id": record["id"]})
            return record
        except Exception as error:
            if not terminal.exists():
                _native("common").write(terminal, {"status": "rejected", "reason": str(error), "retained": True})
            raise


def retained(ledger, identity, name=None):
    record = ledger.store.get("decisions", identity)
    if record.get("kind") != "deployment-decision":
        raise ValueError("This is not a retained deployment decision")
    root, manifest = _manifest(ledger, record["transport_id"])
    if hashlib.sha256(_encoded(manifest)).hexdigest() != record["transport_sha256"]:
        raise ValueError("Retained deployment manifest changed")
    if name is None:
        return manifest
    entry = next((p for p in manifest["parts"] if p["path"] == name), None)
    if entry is None:
        raise ValueError("Undeclared deployment part")
    path = root / entry["path"]
    if path.stat().st_size != entry["bytes"] or _native("common").sha256_file(path) != entry["sha256"]:
        raise ValueError("Retained deployment part changed")
    return path
