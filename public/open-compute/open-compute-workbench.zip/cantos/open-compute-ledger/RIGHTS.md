# Sources and component notices

Cantos public recipient edition, November 2026. Public project material includes the Open Compute Workbench, the project-authored measurement instruments and factual projections of retained evidence. The controller source snapshot lists its owning project, original commit and file hashes. The controller repository supplied no separate top-level licence. The notices in compute/LICENSE and hot-aisle/LICENSE apply to their respective components.

The provider records preserve desk classifications, source identifiers and links. SemiAnalysis ClusterMAX review prose, original provider pages and third-party captures are excluded. The published ClusterMAX notice restricts use of its ratings in financial products without written permission. The listing and benchmark operands retain their source attribution and observation dates. Upstream models, datasets, traces and services retain their respective terms. This edition includes no weights, source reviews, credentials or private hardware inventories.

PUBLIC-SOURCES.json records original SHA-256 identities for the selected source and evidence projections. MANIFEST.json records the actual delivered files. A matching digest establishes byte identity.
