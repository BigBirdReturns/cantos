"""Task-owned loopback service availability and deliberate recovery audit.

No privileged operation, external endpoint, foreign PID, network scan or GPU.
Original raw attempts and lifecycle transitions are immutable after creation.
"""
import argparse, hashlib, json, os, pathlib, socket, subprocess, sys, time, urllib.request, urllib.error
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse,parse_qs

PAYLOAD=b"ocl-task-owned-service-v1"
DIGEST=hashlib.sha256(PAYLOAD).hexdigest()
def stable_json(obj):
    return (json.dumps(obj,sort_keys=True,separators=(",",":"),allow_nan=False)+"\n").encode()
def sha(data):return hashlib.sha256(data).hexdigest()
def durable_x(path,obj):
    data=stable_json(obj)
    with open(path,"xb") as f:
        f.write(data);f.flush();os.fsync(f.fileno())
    return sha(data)
def serve(args):
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            u=urlparse(self.path)
            if u.path!="/health":
                self.send_error(404);return
            nonce=parse_qs(u.query).get("nonce",[""])[0]
            body=stable_json({"instance":args.instance,"nonce":nonce,"payload_sha256":DIGEST,"pid":os.getpid()})
            self.send_response(200);self.send_header("Content-Type","application/json")
            self.send_header("Cache-Control","no-store");self.send_header("Content-Length",str(len(body)))
            self.end_headers();self.wfile.write(body)
        def log_message(self,fmt,*values): pass
    with ThreadingHTTPServer(("127.0.0.1",0),Handler) as server:
        durable_x(pathlib.Path(args.ready),{"instance":args.instance,"pid":os.getpid(),"port":server.server_port})
        server.serve_forever(poll_interval=.1)

def run(args):
    root=pathlib.Path(args.root)
    root.mkdir(parents=True,exist_ok=False)
    transitions=[];samples=[];children=[]
    start_clock=time.monotonic()
    def transition(kind,**kw):
        transitions.append({"kind":kind,"elapsed_s":round(time.monotonic()-start_clock,6),**kw})
    def spawn(condition,ordinal):
        inst=f"{args.run_id}:{condition}:{ordinal}"
        ready=root/(condition+"-ready-"+str(ordinal)+".json")
        log=root/(condition+"-server-"+str(ordinal)+".log")
        with open(log,"xb") as output:
            p=subprocess.Popen([sys.executable,os.path.abspath(__file__),"serve","--instance",inst,"--ready",str(ready)],
                stdout=output,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL)
        children.append(p)
        deadline=time.monotonic()+8
        while time.monotonic()<deadline:
            if p.poll() is not None:raise RuntimeError("owned server died before READY")
            if ready.exists():
                r=json.loads(ready.read_text(encoding="utf-8"))
                if r["pid"]!=p.pid or r["instance"]!=inst:raise RuntimeError("owned service identity discrepancy")
                transition("start",condition=condition,ordinal=ordinal,pid=p.pid,port=r["port"])
                return p,r
            time.sleep(.02)
        raise TimeoutError("task-owned service startup exceeded 8 seconds")
    def stop(p,condition,ordinal):
        if p is None:return
        if p.poll() is None:
            p.terminate()
            try:p.wait(timeout=5)
            except subprocess.TimeoutExpired:
                p.kill();p.wait(timeout=3)
        transition("stop",condition=condition,ordinal=ordinal,pid=p.pid,returncode=p.returncode)
    def probe(port,condition,ordinal,expected):
        nonce=str(len(samples))+":"+args.run_id
        t=time.monotonic()
        req=urllib.request.Request("http://127.0.0.1:"+str(port)+"/health?nonce="+nonce,
            headers={"Cache-Control":"no-store"})
        ok=False;err=None;got=None;status=None
        try:
            with urllib.request.urlopen(req,timeout=.7) as res:
                status=res.status
                raw=res.read(8192)
            got=json.loads(raw)
            ok=(status==200 and got.get("nonce")==nonce and got.get("instance")==expected
                and got.get("payload_sha256")==DIGEST)
            if not ok:err="identity_or_payload_mismatch"
        except Exception as e:
            err=type(e).__name__
        samples.append({"condition":condition,"ordinal":ordinal,"t_s":round(t-start_clock,6),
            "elapsed_ms":round((time.monotonic()-t)*1000,5),"accepted":ok,"status":status,
            "error":err,"pid":None if got is None else got.get("pid"),"nonce":nonce})
    conditions=["normal","restart"] if not args.reverse else ["restart","normal"]
    failure=None
    try:
        for condition in conditions:
            transition("condition_start",condition=condition)
            p,ident=spawn(condition,0);ordinal=0
            port=ident["port"];instance=ident["instance"];alive=True
            cond_start=time.monotonic();next_probe=cond_start;faults=[6.,12.,18.] if condition=="restart" else []
            fault_count=0
            while time.monotonic()-cond_start<args.seconds:
                elapsed=time.monotonic()-cond_start
                if fault_count<len(faults) and elapsed>=faults[fault_count]:
                    stop(p,condition,ordinal);alive=False
                    # Explicitly observe task-owned unavailability; no foreign service is touched.
                    for _ in range(4):
                        probe(port,condition,ordinal,instance)
                        time.sleep(.22)
                    ordinal+=1;p,ident=spawn(condition,ordinal)
                    port=ident["port"];instance=ident["instance"];alive=True
                    transition("recovered",condition=condition,ordinal=ordinal,pid=p.pid)
                    fault_count+=1
                now=time.monotonic()
                if now>=next_probe:
                    probe(port,condition,ordinal,instance)
                    next_probe=now+args.interval
                else:time.sleep(min(.02,next_probe-now))
            stop(p,condition,ordinal);transition("condition_end",condition=condition)
        if sum(t["kind"]=="recovered" for t in transitions)!=3:raise RuntimeError("not all three owned recovery trials executed")
    except BaseException as e:
        failure=type(e).__name__+": "+str(e)
        transition("failure",reason=failure)
        raise
    finally:
        for p in children:
            if p.poll() is None:
                p.terminate()
                try:p.wait(timeout=5)
                except subprocess.TimeoutExpired:p.kill();p.wait(timeout=3)
        raw={"schema":"ocl.owned-loopback-recovery/1","run_id":args.run_id,
             "host_unverified_label":args.host_label,"scope":"127.0.0.1, child process owned by this job",
             "seconds_per_condition":args.seconds,"interval_s":args.interval,
             "condition_order":conditions,"payload_sha256":DIGEST,
             "transitions":transitions,"attempts":samples,"error":failure}
        receipt_sha=durable_x(root/"raw.json",raw)
        summaries={}
        for cond in conditions:
            arr=[x for x in samples if x["condition"]==cond]
            good=sorted(x["elapsed_ms"] for x in arr if x["accepted"])
            def quantile(f):
                if not good:return None
                return good[min(len(good)-1,int((len(good)-1)*f))]
            summaries[cond]={"attempts":len(arr),"accepted":sum(x["accepted"] for x in arr),
                "failed":sum(not x["accepted"] for x in arr),
                "p50_good_ms":quantile(.5),"p95_good_ms":quantile(.95),"p99_good_ms":quantile(.99)}
        result={"schema":"ocl.owned-loopback-summary/1","raw_sha256":receipt_sha,
            "run_id":args.run_id,"conditions":summaries,
            "planned_restarts":3,"executed_restarts":sum(t["kind"]=="recovered" for t in transitions),
            "exit_success":failure is None}
        durable_x(root/"summary.json",result)
        print(json.dumps({"root":str(root),"result":result},sort_keys=True),flush=True)
def main():
    a=argparse.ArgumentParser()
    sub=a.add_subparsers(dest="mode",required=True)
    s=sub.add_parser("serve");s.add_argument("--instance",required=True);s.add_argument("--ready",required=True)
    r=sub.add_parser("run");r.add_argument("--root",required=True);r.add_argument("--run-id",required=True)
    r.add_argument("--host-label",required=True);r.add_argument("--seconds",type=float,default=26)
    r.add_argument("--interval",type=float,default=.14);r.add_argument("--reverse",action="store_true")
    args=a.parse_args()
    if args.mode=="serve":serve(args)
    else:
        if args.seconds<23 or args.seconds>180:raise ValueError("Require 23..180 seconds per condition")
        if args.interval<.05 or args.interval>.5:raise ValueError("Probe interval outside supported bounds")
        run(args)
if __name__=="__main__":main()
