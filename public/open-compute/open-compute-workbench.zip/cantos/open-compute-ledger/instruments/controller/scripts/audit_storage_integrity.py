#!/usr/bin/env python3
"""Task-owned filesystem integrity and recovery audit for an authorized host.

Two native, independent process phases: write+fsync retained bytes, then reopen
and hash in a new process. No deletion, overwrite, privilege change or fault
injection. A passing check verifies the recorded logical bytes, not physical
media persistence after power loss, cache-independent throughput or an SLA.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
from pathlib import Path
import statistics
import sys
import time
from datetime import datetime, timezone

SCHEMA = "ocl.storage-integrity-native/1"
BLOCK = 4 * 1024 * 1024

def now():
    return datetime.now(timezone.utc).isoformat()

def sha_file(path):
    h = hashlib.sha256()
    n = 0
    with path.open("rb") as f:
        while True:
            b = f.read(1024 * 1024)
            if not b:
                break
            n += len(b)
            h.update(b)
    return n, h.hexdigest()

def exclusive_json(path, obj):
    raw = (json.dumps(obj, sort_keys=True, indent=2, allow_nan=False) + "\n").encode("utf-8")
    with path.open("xb") as f:
        f.write(raw)
        f.flush()
        os.fsync(f.fileno())
    return hashlib.sha256(raw).hexdigest()

def directory_fsync(path):
    if os.name != "posix":
        return False
    fd = None
    try:
        fd = os.open(path, os.O_RDONLY)
        os.fsync(fd)
        return True
    except OSError:
        return False
    finally:
        if fd is not None:
            os.close(fd)

def phase_write(root, run_id, mib, seed):
    if not 1 <= mib <= 64:
        raise ValueError("size must be 1..64 MiB")
    if not run_id.replace("_", "").replace("-", "").isalnum() or not 8 <= len(run_id) <= 72:
        raise ValueError("invalid run identity")
    root = root.resolve(strict=True)
    free = shutil.disk_usage(root).free
    size = mib * 1024 * 1024
    if free < size + 128 * 1024 * 1024:
        raise RuntimeError("insufficient scratch free space")
    folder = root / run_id
    folder.mkdir(exist_ok=False)
    target = folder / "evidence.bin"
    journal = folder / "write-journal.jsonl"
    hash_total = hashlib.sha256()
    samples = []
    count = 0
    with target.open("xb") as f, journal.open("xb") as evidence:
        offset = 0
        while offset < size:
            n = min(BLOCK, size - offset)
            data = hashlib.shake_256((str(seed) + ":" + str(offset)).encode()).digest(n)
            hash_total.update(data)
            start = time.monotonic_ns()
            count += f.write(data)
            f.flush()
            os.fsync(f.fileno())
            elapsed = (time.monotonic_ns() - start) / 1e6
            record = {"block_index": len(samples), "bytes": n, "write_fsync_ms": round(elapsed, 6)}
            samples.append(record)
            evidence.write((json.dumps(record, sort_keys=True) + "\n").encode("utf-8"))
            evidence.flush()
            os.fsync(evidence.fileno())
            offset += n
    payload = {
        "schema": SCHEMA, "phase": "write", "utc": now(), "run_id": run_id,
        "host": os.uname().nodename if hasattr(os, "uname") else os.environ.get("COMPUTERNAME"),
        "source": "deterministic SHAKE256 block stream, digest retained, source input seed explicit",
        "seed": seed, "bytes": count, "blocks": len(samples), "sha256": hash_total.hexdigest(),
        "write_fsync_samples": samples,
        "median_write_fsync_ms": statistics.median(x["write_fsync_ms"] for x in samples),
        "max_write_fsync_ms": max(x["write_fsync_ms"] for x in samples),
        "free_bytes_before": free, "filesystem_device": os.stat(root).st_dev,
        "journal_sha256": sha_file(journal)[1],
        "limitations": [
            "Write+fsync on an authorized task-owned file; filesystem and storage cache may acknowledge without physical media power-loss durability.",
            "Small deterministic bounded sample; not sustained device throughput or an external provider SLA.",
            "Includes current host and filesystem effects; no isolation from foreign disk I/O is asserted.",
            "No facility power, operating cost, tenancy uptime, encryption or disaster recovery proof."
        ]
    }
    digest = exclusive_json(folder / "write-receipt.json", payload)
    directory_fsync(folder)
    directory_fsync(root)
    return {"phase": "write", "run_id": run_id, "sha256": payload["sha256"], "receipt_sha256": digest, "bytes": count}

def phase_verify(root, run_id, verification_id):
    root = root.resolve(strict=True)
    if not run_id.replace("_", "").replace("-", "").isalnum() or not 8 <= len(run_id) <= 72:
        raise ValueError("unsafe run identity")
    if not verification_id.replace("_", "").replace("-", "").isalnum() or not 4 <= len(verification_id) <= 64:
        raise ValueError("unsafe verification identity")
    folder = (root / run_id).resolve(strict=True)
    if folder.parent != root:
        raise ValueError("unsafe directory")
    receipt = folder / ("verify-" + verification_id + ".json")
    if receipt.exists():
        raise FileExistsError("immutable prior verification")
    original = folder / "write-receipt.json"
    obj = json.loads(original.read_text(encoding="utf-8"))
    if obj.get("schema") != SCHEMA or obj.get("run_id") != run_id:
        raise ValueError("wrong source receipt schema or identity")
    start = time.monotonic_ns()
    bytes_read, actual = sha_file(folder / "evidence.bin")
    elapsed = (time.monotonic_ns() - start) / 1e6
    accepted = bytes_read == obj["bytes"] and actual == obj["sha256"]
    result = {
        "schema": SCHEMA, "phase": "verify", "utc": now(), "run_id": run_id,
        "verification_id": verification_id, "original_receipt_sha256": sha_file(original)[1],
        "source_bytes": obj["bytes"], "read_bytes": bytes_read,
        "expected_sha256": obj["sha256"], "observed_sha256": actual,
        "accepted": accepted, "elapsed_read_hash_ms": round(elapsed, 6),
        "verdict": "reopened_source_bytes_verified" if accepted else "source_bytes_mismatch",
        "limitations": [
            "Distinct native process and fresh file open, but OS cache not cleared; wall-clock read/hash includes CPU digest time.",
            "No power interruption, crash injection, storage redundancy or provider uptime evidence."
        ]
    }
    digest = exclusive_json(receipt, result)
    directory_fsync(folder)
    return {"phase": "verify", "run_id": run_id, "verification_id": verification_id,
            "accepted": accepted, "receipt_sha256": digest, "elapsed_ms": result["elapsed_read_hash_ms"]}

def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("phase", choices=("write", "verify"))
    p.add_argument("--root", required=True, type=Path)
    p.add_argument("--run-id", required=True)
    p.add_argument("--mib", type=int, default=16)
    p.add_argument("--seed", type=int, default=1729)
    p.add_argument("--verification-id", default="native_b")
    a = p.parse_args(argv)
    if a.phase == "write":
        result = phase_write(a.root, a.run_id, a.mib, a.seed)
    else:
        result = phase_verify(a.root, a.run_id, a.verification_id)
    print(json.dumps(result, sort_keys=True))
    return 0 if result.get("accepted", True) else 2

if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError, RuntimeError, KeyError, TypeError, json.JSONDecodeError) as ex:
        print(json.dumps({"phase": "error", "type": type(ex).__name__, "message": str(ex)}), file=sys.stderr)
        sys.exit(3)
