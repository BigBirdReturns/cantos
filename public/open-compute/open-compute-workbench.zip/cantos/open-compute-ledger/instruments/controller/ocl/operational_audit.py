"""Bounded, self-owned local operational audit. No external network scanning or service disruption."""
from __future__ import annotations
import argparse, hashlib, http.server, json, os, pathlib, platform, re
import shutil, socket, stat, subprocess, sys, tempfile, threading, time
import urllib.request
from datetime import datetime, timezone

SCHEMA = "ocl.operational-evidence/1"
CATEGORIES = ("security","lifecycle","orchestration","storage","networking",
              "reliability","monitoring","pricing","partnerships","availability")
def utc():
    return datetime.now(timezone.utc).isoformat().replace("+00:00","Z")
def percentile(values,q):
    if not values: return None
    s=sorted(values)
    return s[min(len(s)-1,max(0,round((len(s)-1)*q)))]
def stats(values):
    return {"count":len(values),"min":min(values) if values else None,
            "median":percentile(values,.5),"p95":percentile(values,.95),
            "max":max(values) if values else None}
class Handler(http.server.BaseHTTPRequestHandler):
    protocol_version="HTTP/1.1"
    def do_GET(self):
        body=b'{"healthy":true}'
        if self.path != "/health":
            self.send_error(404); return
        self.send_response(200)
        self.send_header("Content-Type","application/json")
        self.send_header("Content-Length",str(len(body)))
        self.end_headers()
        self.wfile.write(body)
    def log_message(self,*_): pass
def health(url,timeout=2):
    begin=time.perf_counter()
    req=urllib.request.Request(url,headers={"Connection":"close"})
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(req,timeout=timeout) as response:
        data=response.read(1024)
        if response.status!=200 or data!=b'{"healthy":true}': raise ValueError("invalid task-owned health response")
    return (time.perf_counter()-begin)*1000
def service_cycle(samples):
    begin=time.perf_counter()
    server=http.server.ThreadingHTTPServer(("127.0.0.1",0),Handler)
    server.daemon_threads=True
    thread=threading.Thread(target=server.serve_forever,kwargs={"poll_interval":.01},daemon=True)
    thread.start()
    startup=(time.perf_counter()-begin)*1000
    address="http://127.0.0.1:"+str(server.server_address[1])+"/health"
    latencies=[];errors=[]
    try:
        for i in range(samples):
            try:latencies.append(health(address))
            except Exception as e:errors.append({"request_index":i,"kind":type(e).__name__})
    finally:
        start=time.perf_counter()
        server.shutdown();server.server_close()
        thread.join(timeout=2)
        stop=(time.perf_counter()-start)*1000
    return {"startup_ms":startup,"shutdown_ms":stop,"requests_attempted":samples,
            "requests_successful":len(latencies),"failures":errors,
            "health_latency_ms":stats(latencies),"worker_stopped":not thread.is_alive()}
def task_owned_storage(scratch,trials,size):
    duration_write=[];duration_read=[];failures=[];digest=hashlib.sha256()
    seed=hashlib.sha256(b"OCL-task-owned-operational-audit").digest()
    payload=(seed*((size+31)//32))[:size]
    expected=hashlib.sha256(payload).digest()
    for i in range(trials):
        p=scratch/("sample-%03d.bin"%i)
        try:
            begin=time.perf_counter()
            with p.open("xb") as f:
                f.write(payload);f.flush();os.fsync(f.fileno())
            duration_write.append((time.perf_counter()-begin)*1000)
            begin=time.perf_counter()
            with p.open("rb") as f:observed=f.read()
            duration_read.append((time.perf_counter()-begin)*1000)
            if hashlib.sha256(observed).digest()!=expected:raise ValueError("read-after-write checksum mismatch")
            digest.update(observed)
        except Exception as e:failures.append({"trial":i,"kind":type(e).__name__})
        finally:
            if p.exists():p.unlink()
    return {"trials":trials,"bytes_per_trial":size,
            "verified_samples":trials-len(failures),
            "durable_write_ms":stats(duration_write),"cached_read_ms":stats(duration_read),
            "verified_data_sha256":digest.hexdigest(),"failures":failures,
            "qualification":"Buffered file fsync and read-after-write on task-owned scratch; cached reads possible; no provider IOPS, durability or production SLA claim"}
def task_owned_process(trials):
    observations=[];failures=[]
    for i in range(trials):
        begin=time.perf_counter()
        try:
            cp=subprocess.run([sys.executable,"-c","print('OCL_TASK_OWNED_READY')"],
                              capture_output=True,text=True,timeout=7)
            elapsed=(time.perf_counter()-begin)*1000
            if cp.returncode!=0 or cp.stdout.strip()!="OCL_TASK_OWNED_READY":
                raise RuntimeError("child completion mismatch")
            observations.append(elapsed)
        except Exception as e:failures.append({"trial":i,"kind":type(e).__name__})
    return {"trials":trials,"successful_child_exits":len(observations),
            "spawn_to_exit_ms":stats(observations),"failures":failures,
            "qualification":"Finite ephemeral task-owned Python process launch and natural exit; not orchestration or production recovery"}
def run(scratch,label,trials=6,storage_bytes=1048576):
    if not re.fullmatch(r"[A-Za-z0-9_-]{3,40}",label):raise ValueError("invalid label")
    if type(trials) is not int or not 1<=trials<=20:raise ValueError("invalid trials")
    if type(storage_bytes) is not int or not 4096<=storage_bytes<=4*1024*1024:
        raise ValueError("storage bytes must be 4KiB to 4MiB")
    root=pathlib.Path(scratch)
    root.mkdir(parents=True,exist_ok=True)
    if not root.is_dir() or root.is_symlink():raise ValueError("unsafe scratch")
    source_sha=hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
    began=utc();start=time.monotonic()
    with tempfile.TemporaryDirectory(prefix="ocl-owned-audit-",dir=root) as dirname:
        isolated=pathlib.Path(dirname)
        mode=stat.S_IMODE(isolated.stat().st_mode)
        disk=shutil.disk_usage(isolated)
        store=task_owned_storage(isolated,trials,storage_bytes)
        lifecycle=task_owned_process(trials)
        first=service_cycle(trials*3)
        second=service_cycle(trials*3)
    finished=utc()
    service_success=first["requests_successful"]+second["requests_successful"]
    service_attempted=first["requests_attempted"]+second["requests_attempted"]
    results={
        "storage":{"evidence":"observed_local","scope":"isolated_task_scratch","data":store},
        "networking":{"evidence":"observed_local","scope":"127.0.0.1_ephemeral_HTTP_only",
                      "data":{"rounds":[first,second],"attempts":service_attempted,
                              "successes":service_success,"failure_count":service_attempted-service_success}},
        "lifecycle":{"evidence":"observed_local","scope":"task_owned_process_and_HTTP_service",
                     "data":{"process":lifecycle,"http_restarts":2,
                             "owned_server_threads_stopped":first["worker_stopped"] and second["worker_stopped"]}},
        "reliability":{"evidence":"observed_local","scope":"finite_local_probe_only",
                       "data":{"health_successes":service_success,"health_attempts":service_attempted,
                               "recovery_after_task_owned_shutdown":second["requests_successful"]>0}},
        "availability":{"evidence":"observed_local","scope":"two_short_ephemeral_probe_windows",
                        "data":{"successful":service_success,"attempted":service_attempted,
                                "continuous_uptime_percent":None}},
        "security":{"evidence":"observed_local" if os.name=="posix" else "unknown",
                    "scope":"owned_temporary_directory_mode_only",
                    "data":{"posix_mode_octal":oct(mode) if os.name=="posix" else None,
                            "world_readable":bool(mode&stat.S_IROTH) if os.name=="posix" else None,
                            "cloud_security_posture":None}},
        "monitoring":{"evidence":"observed_local","scope":"local_host_capacity_snapshot",
                      "data":{"free_scratch_bytes":disk.free,"total_scratch_bytes":disk.total,
                              "provider_monitoring_coverage":None}},
        "orchestration":{"evidence":"unknown","scope":"no_external_orchestrator_test","data":None},
        "pricing":{"evidence":"unknown","scope":"no_spending_or_rate_verification","data":None},
        "partnerships":{"evidence":"unknown","scope":"no_external_provider_data","data":None}
    }
    if set(results)!=set(CATEGORIES):raise RuntimeError("category mismatch")
    return {"schema":SCHEMA,"label":label,"started_utc":began,"ended_utc":finished,
            "duration_s":time.monotonic()-start,
            "probe_source_sha256":source_sha,"platform":platform.system(),
            "python":platform.python_version(),
            "status":"observed_local_partial",
            "raw_evidence":{"storage_errors":len(store["failures"]),
                            "child_errors":len(lifecycle["failures"]),
                            "service_errors":service_attempted-service_success},
            "categories":results,
            "limitations":["Task-owned loopback and scratch measurements only; no WAN or commercial-cloud provider audited.",
                           "No provider ranking, uptime SLA, persistent reliability, external pricing or facility energy established.",
                           "Cross-host latency and storage rates are influenced by OS, hardware, caching and concurrent workloads.",
                           "This artifact excludes personal paths, hostnames, credentials and unique device identifiers."]}
def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scratch",required=True)
    parser.add_argument("--out",required=True)
    parser.add_argument("--label",required=True)
    parser.add_argument("--trials",type=int,default=6)
    parser.add_argument("--storage-bytes",type=int,default=1048576)
    a=parser.parse_args(argv)
    output=pathlib.Path(a.out)
    if output.exists():raise FileExistsError(str(output))
    result=run(a.scratch,a.label,a.trials,a.storage_bytes)
    output.parent.mkdir(parents=True,exist_ok=True)
    with output.open("x",encoding="utf-8",newline="\n") as f:
        json.dump(result,f,indent=2,sort_keys=True,allow_nan=False);f.write("\n")
    print(json.dumps({"result":str(output),"sha256":hashlib.sha256(output.read_bytes()).hexdigest(),
                      "probe_source_sha256":result["probe_source_sha256"],
                      "successes":result["categories"]["networking"]["data"]["successes"],
                      "attempts":result["categories"]["networking"]["data"]["attempts"],
                      "duration_s":result["duration_s"]},sort_keys=True))
if __name__=="__main__": main()
