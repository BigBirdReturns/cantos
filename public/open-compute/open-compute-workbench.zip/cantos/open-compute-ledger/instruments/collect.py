#!/usr/bin/env python3
"""Collect or import an Open Compute Ledger instrument packet using existing owners.

Every invocation writes a new directory. Historical receipts are copied exactly.
Useful-work inference occurs only with an explicitly supplied endpoint and model.
"""
from __future__ import annotations
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys
import time
import uuid

HERE = Path(__file__).resolve().parent
CONTROLLER = HERE / "controller"
sys.path.insert(0, str(CONTROLLER))
SCHEMA = "ocl.instrument-packet/1"

def now():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))

def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    data = (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + "\n").encode()
    with path.open("xb") as handle:
        handle.write(data)
    return sha(data)

def number(value, label):
    if type(value) not in (int, float) or not math.isfinite(value) or value < 0:
        raise ValueError(label + " must be finite and nonnegative")
    return value

def finances(path):
    if path is None:
        return {"costs": [], "energy": [], "source": None}
    raw = Path(path).read_bytes()
    obj = json.loads(raw.decode("utf-8-sig"))
    if set(obj) - {"schema", "costs", "energy", "notes"}:
        raise ValueError("unknown financial-input fields")
    for kind in ("costs", "energy"):
        if not isinstance(obj.get(kind, []), list):
            raise ValueError(kind + " must be a list")
        for entry in obj.get(kind, []):
            if not isinstance(entry, dict):
                raise ValueError("financial entry must be an object")
            for field in ("value", "unit", "scope", "source", "basis"):
                if field not in entry:
                    raise ValueError("missing financial entry " + field)
            number(entry["value"], "financial value")
            if entry["basis"] not in ("observed", "modeled", "published"):
                raise ValueError("basis must be observed, modeled or published")
            if not all(isinstance(entry[k], str) and entry[k].strip() for k in ("unit", "scope", "source")):
                raise ValueError("unit, scope and source must be nonempty")
            if kind == "costs" and entry["unit"] != "USD":
                raise ValueError("cost unit must be USD for this packet version")
            if kind == "energy" and entry["unit"] not in ("Wh", "kWh", "J"):
                raise ValueError("energy unit must be Wh, kWh or J")
    return {"costs": obj.get("costs", []), "energy": obj.get("energy", []),
            "source": {"path": str(path), "sha256": sha(raw),
                       "verification": "operator-supplied source declaration; no invoice or meter attestation inferred"},
            "notes": obj.get("notes")}

def command(root, key, argv, timeout, failures):
    started = now()
    clock = time.monotonic()
    try:
        result = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                timeout=timeout, stdin=subprocess.DEVNULL)
        out, err, code = result.stdout, result.stderr, result.returncode
        error = None
    except (OSError, subprocess.TimeoutExpired) as exc:
        out, err, code = getattr(exc, "stdout", None) or b"", getattr(exc, "stderr", None) or b"", None
        if isinstance(out, str): out = out.encode()
        if isinstance(err, str): err = err.encode()
        error = type(exc).__name__ + ": " + str(exc)
    logs = root / "logs"
    logs.mkdir(exist_ok=True)
    (logs / (key + ".stdout")).write_bytes(out)
    (logs / (key + ".stderr")).write_bytes(err)
    receipt = {"key": key, "argv": [str(x) for x in argv], "started_at": started,
               "elapsed_s": time.monotonic() - clock, "returncode": code, "error": error,
               "stdout": "logs/" + key + ".stdout", "stderr": "logs/" + key + ".stderr"}
    write_json(logs / (key + ".json"), receipt)
    if code != 0:
        failures.append({"stage": key, "returncode": code, "error": error,
                         "receipt": "logs/" + key + ".json"})
    return receipt

def inventory(root, failures):
    disk = shutil.disk_usage(root)
    result = {"schema": "ocl.local-inventory/1", "captured_at": now(),
              "source": "stdlib platform and capacity queries",
              "os": platform.system(), "os_release": platform.release(),
              "machine_architecture": platform.machine(), "logical_cpu_count": os.cpu_count(),
              "python": platform.python_version(), "scratch_bytes_total": disk.total,
              "scratch_bytes_free": disk.free, "workload_isolated": False,
              "limits": ["Capacity snapshot only; no serving throughput or provider attestation."]}
    gpu_cli = shutil.which("nvidia-smi")
    if gpu_cli:
        rec = command(root, "inventory-nvidia", [gpu_cli,
            "--query-gpu=uuid,name,driver_version,memory.total,pci.bus_id,pstate,power.draw",
            "--format=csv"], 15, failures)
        result["nvidia_query"] = rec
    if sys.platform.startswith("linux") and shutil.which("bash"):
        fingerprint = HERE.parent.parent / "hot-aisle/campaign/shop-eval/probe/fingerprint.sh"
        if fingerprint.exists():
            rec = command(root, "inventory-native-linux", [shutil.which("bash"), str(fingerprint),
                           "auto", str(root / "native-inventory")], 60, failures)
            result["native_fingerprint"] = rec
    write_json(root / "raw" / "inventory.json", result)
    return result

def copy_receipt(path, root, stem):
    source = Path(path).resolve(strict=True)
    raw = source.read_bytes()
    obj = json.loads(raw.decode("utf-8-sig"))
    dest = root / "raw" / (stem + ".json")
    dest.parent.mkdir(parents=True, exist_ok=True)
    with dest.open("xb") as handle:
        handle.write(raw)
    return obj, {"source": str(source), "source_sha256": sha(raw),
                 "path": dest.relative_to(root).as_posix(), "bytes": len(raw),
                 "mode": "retained byte-exact receipt; original observation dates unchanged"}

def normalize_work(receipt, configuration, useful_work_basis="unknown"):
    if receipt.get("schema") != "ocl.run/1":
        raise ValueError("useful-work receipt must use existing ocl.run/1 schema")
    observations = receipt["observations"]
    expected = receipt["workload"]["expected_tasks"]
    if type(expected) is not int or expected < len(observations):
        raise ValueError("invalid expected task count")
    identities = [(o["task_id"], o["repetition"]) for o in observations]
    if len(set(identities)) != len(identities):
        raise ValueError("duplicate retained task identity")
    if any(type(o.get("accepted")) is not bool for o in observations):
        raise ValueError("accepted must be an explicit boolean")
    accepted = sum(o["accepted"] for o in observations)
    correct = sum(o.get("checks", {}).get("exact_expected") is True for o in observations)
    completed = sum(any(a.get("stage") == "final" and a.get("error") is None
                        for a in o.get("attempts", [])) for o in observations)
    attempts = [a for o in observations for a in o.get("attempts", [])]
    tokens = [a.get("output_tokens") for a in attempts]
    fixture = receipt["workload"]["fixture_sha256"]
    if not re.fullmatch("[0-9a-f]{64}", fixture):
        raise ValueError("invalid fixture identity")
    provenance = receipt.get("provenance", {})
    cfg = dict(configuration)
    cfg.setdefault("id", "native-" + receipt["run_id"][:20])
    cfg.setdefault("label", provenance.get("model", "Explicit native configuration"))
    for field, source in [("model", "model"), ("runtime", "runtime"), ("precision", "precision"),
                          ("accelerator", "hardware")]:
        cfg.setdefault(field, provenance.get(source))
    workload = {"id": "lookup-analysis-micro-suite/1:" + fixture,
                "label": "Exact two-turn lookup and data analysis", "kind": "synthetic",
                "identity": fixture, "seed": receipt["workload"].get("seed"),
                "acceptance_definition": "Existing ocl.exact-json/1: exact lookup request, valid final JSON and exact independently computed expected result; all task and HTTP failures retained",
                "limits": receipt.get("limitations", [])}
    return {"configuration": cfg, "workload": workload, "useful_work_basis": useful_work_basis,
            "acceptance": {"scheduled": expected, "sent": sum(bool(o.get("attempts")) for o in observations),
                           "completed": completed, "correct": correct, "accepted": accepted,
                           "failed": expected - accepted},
            "metrics": {"window_s": receipt.get("duration_s"), "http_attempts": len(attempts),
                        "output_tokens": sum(tokens) if all(type(t) is int for t in tokens) else None,
                        "ttft_p95_s": None, "e2e_p95_s": percentile([o["duration_s"] for o in observations], .95),
                        "board_energy_wh": None},
            "task_failures": dict(Counter(o.get("error") or "unaccepted_without_error"
                                         for o in observations if not o["accepted"]))}

def percentile(values, q):
    if not values: return None
    seq = sorted(values)
    return seq[min(len(seq) - 1, int((len(seq) - 1) * q))]

def run_operations(root, mode, label, run_id, failures):
    if mode == "none":
        return {}
    raw = root / "raw"
    scratch = root / "scratch"
    scratch.mkdir()
    output = {}
    args = [sys.executable, "-B", str(CONTROLLER / "ocl/operational_audit.py"),
            "--scratch", str(scratch), "--out", str(raw / "operations.json"),
            "--label", label, "--trials", "3"]
    command(root, "operations-basic", args, 60, failures)
    if (raw / "operations.json").exists():
        output["local_operations"] = read_json(raw / "operations.json")
    if mode == "full":
        storage_root = scratch / "storage"
        storage_root.mkdir()
        script = CONTROLLER / "scripts/audit_storage_integrity.py"
        for phase in ("write", "verify"):
            command(root, "storage-" + phase, [sys.executable, "-B", str(script), phase,
                "--root", str(storage_root), "--run-id", run_id, "--mib", "4",
                "--verification-id", "independent_process"], 30, failures)
        folder = storage_root / run_id
        for stem, filename in [("storage_write", "write-receipt.json"),
                               ("storage_verify", "verify-independent_process.json")]:
            if (folder / filename).exists():
                output[stem] = read_json(folder / filename)
        recovery_root = root / "recovery"
        command(root, "service-recovery", [sys.executable, "-B",
            str(CONTROLLER / "scripts/audit_owned_loopback_recovery.py"), "run",
            "--root", str(recovery_root), "--run-id", run_id, "--host-label", label,
            "--seconds", "23", "--interval", ".14"], 150, failures)
        if (recovery_root / "summary.json").exists():
            output["service_recovery"] = read_json(recovery_root / "summary.json")
            output["service_recovery_raw_path"] = "recovery/raw.json"
    return output

def file_manifest(root):
    return [{"path": p.relative_to(root).as_posix(), "sha256": sha(p.read_bytes()),
             "bytes": p.stat().st_size} for p in sorted(root.rglob("*"))
            if p.is_file() and p.name != "packet.json"]

def collect(args):
    config = read_json(args.configuration) if args.configuration else {}
    if not isinstance(config, dict): raise ValueError("configuration must be an object")
    money = finances(args.financials)
    if args.mode == "collect":
        if bool(args.endpoint) != bool(args.model):
            raise ValueError("--endpoint and --model must be supplied together")
        if args.endpoint:
            from ocl.runner import endpoint
            endpoint(args.endpoint, args.allow_remote)
    label = args.label
    if not re.fullmatch("[A-Za-z0-9_-]{3,40}", label):
        raise ValueError("label must contain 3..40 letters, digits, underscores or hyphens")
    run_id = args.run_id or ("ocl_" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S") + "_" + uuid.uuid4().hex[:8])
    if not re.fullmatch("[A-Za-z0-9_-]{8,72}", run_id): raise ValueError("invalid run ID")
    root = Path(args.out).resolve()
    root.mkdir(parents=True, exist_ok=False)
    (root / "raw").mkdir()
    failures = []
    captured_at = now()
    packet = {"schema": SCHEMA, "packet_id": run_id, "status": "running",
              "provenance": {"producer": "Open Compute Ledger unified instrument",
                             "label": label, "captured_at": captured_at, "mode": args.mode,
                             "source_sha256": sha(Path(__file__).read_bytes()),
                             "source_snapshot": read_json(CONTROLLER / "SNAPSHOT.json")},
              "configuration": config or {"id": label, "label": label},
              "host_inventory": None, "operations": {}, "useful_work": None,
              "workload": None, "acceptance": {}, "metrics": {}, "useful_work_basis": "unknown",
              "costs": money["costs"], "energy": money["energy"],
              "financial_source": money["source"], "failures": failures,
              "coverage": {}, "files": []}
    write_json(root / "plan.json", {"schema": "ocl.instrument-plan/1", "run_id": run_id,
               "mode": args.mode, "captured_at": captured_at, "label": label,
               "operations": getattr(args, "operations", None),
               "endpoint": getattr(args, "endpoint", None), "model": getattr(args, "model", None),
               "configuration": config, "financial_source": money["source"]})
    if args.financials:
        shutil.copyfile(args.financials, root / "raw" / "financial-inputs.json")
    try:
        if args.mode == "collect":
            packet["host_inventory"] = inventory(root, failures)
            packet["operations"] = run_operations(root, args.operations, label, run_id, failures)
            packet["operations_basis"] = {key: "observed" for key, obj in packet["operations"].items()
                                          if isinstance(obj, dict)}
            if args.endpoint:
                from ocl.runner import run_suite
                receipt = run_suite(args.endpoint, args.model, root / "raw" / "useful-work.json",
                    repeats=args.repeats, seed=args.seed, timeout=args.timeout,
                    max_tokens=args.max_tokens, concurrency=args.concurrency,
                    allow_remote=args.allow_remote, provenance={"hardware": config.get("accelerator"),
                    "model": args.model, "runtime": config.get("runtime"),
                    "precision": config.get("precision")},
                    extra_body=({"chat_template_kwargs": {"enable_thinking": False}}
                                if args.disable_thinking_template else None))
                packet["useful_work"] = receipt
                packet.update(normalize_work(receipt, config, "observed"))
        else:
            sources = []
            if args.receipt:
                receipt, source = copy_receipt(args.receipt, root, "useful-work")
                sources.append(source)
                packet["useful_work"] = receipt
                packet.update(normalize_work(receipt, config, args.useful_work_basis))
            if args.inventory:
                packet["host_inventory"], source = copy_receipt(args.inventory, root, "inventory")
                sources.append(source)
            for index, filename in enumerate(args.operation or []):
                obj, source = copy_receipt(filename, root, "operation-" + str(index))
                sources.append(source)
                packet["operations"][str(index)] = obj
            packet["provenance"]["retained_sources"] = sources
        packet["status"] = "partial_failure" if failures else "collected"
    except Exception as exc:
        failures.append({"stage": "instrument", "error": type(exc).__name__ + ": " + str(exc)})
        packet["status"] = "partial_failure"
    finally:
        packet["coverage"] = {
            "inventory": "observed_local_snapshot" if packet["host_inventory"] is not None else "not_collected",
            "operations": "scoped_original_receipts" if packet["operations"] else "not_collected",
            "useful_work": "explicit_exact_synthetic_grading" if packet["useful_work"] else "not_collected",
            "financials": "operator_supplied_with_evidence_basis" if money["costs"] or money["energy"] else "unknown",
            "external_provider_conformance": "not_established",
            "note": "Collection time is not the observation time of imported receipts. No accepted work is inferred from HTTP completion."}
        packet["provenance"]["completed_at"] = now()
        packet["files"] = file_manifest(root)
        write_json(root / "packet.json", packet)
    print(json.dumps({"packet": str(root / "packet.json"), "status": packet["status"],
                      "accepted": packet["acceptance"].get("accepted"),
                      "failures": len(failures), "files": len(packet["files"])}))
    return 2 if failures else 0

def collect_network(args):
    """Health-only explicit remote acquisition, separate from model collection."""
    from ocl import network_health as network
    config = network.strict(Path(args.config).read_bytes())
    if set(config) != {"network_target", "network_protocol"}:
        raise ValueError("Expected network_target and network_protocol only")
    expected, settings = network.target(config["network_target"]), network.protocol(config["network_protocol"])
    if args.authorize_target != network.sha(network.canonical(expected)):
        raise ValueError("Explicit exact network target authorization is required")
    root = Path(args.out).resolve()
    root.mkdir(parents=True, exist_ok=False)
    (root / "network").mkdir()
    packet = {"schema": SCHEMA, "packet_id": "network_" + uuid.uuid4().hex, "status": "running",
        "provenance": {"producer": "Pinned Open Compute health-only collector", "mode": "network-health",
            "captured_at": now(), "source_sha256": sha(Path(__file__).read_bytes()),
            "network_module_sha256": sha(Path(network.__file__).read_bytes())},
        "operations": {}, "useful_work": None, "useful_work_basis": "unknown", "files": [], "failures": []}
    write_json(root / "network/config.json", config)
    try:
        with (root / "network/attempt-events.jsonl").open("xb", buffering=0) as journal:
            def retain(event):
                journal.write(network.canonical(event) + b"\n")
                os.fsync(journal.fileno())
            raw = network.acquire(expected, settings, args.authorize_target, on_event=retain)
        write_json(root / "network/raw.json", raw)
        summary = network.verify(raw, expected, settings, producer_sha256=packet["provenance"]["network_module_sha256"])
        write_json(root / "network/summary.json", summary)
        packet["operations"]["owned_network"] = summary
        packet["status"] = "collected"
    except BaseException as error:
        packet["status"] = "partial_failure"
        packet["failures"].append({"stage": "network-health", "error": type(error).__name__ + ": " + str(error)[:300]})
        raise
    finally:
        packet["provenance"]["completed_at"] = now()
        packet["files"] = file_manifest(root)
        write_json(root / "packet.json", packet)
    print(json.dumps({"packet": str(root / "packet.json"), "scope": summary["scope"],
                      "attempts": summary["attempts"], "failure_count": summary["failure_count"]}))
    return 0


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="mode", required=True)
    network = sub.add_parser("network-health", help="bounded authorized named TLS health route only; no inference")
    network.add_argument("--config", required=True)
    network.add_argument("--authorize-target", required=True)
    network.add_argument("--out", required=True)
    for name in ("collect", "ingest"):
        p = sub.add_parser(name)
        p.add_argument("--out", required=True, help="New immutable result directory")
        p.add_argument("--label", required=True)
        p.add_argument("--run-id")
        p.add_argument("--configuration", help="JSON configuration identity")
        p.add_argument("--financials", help="Sourced costs/energy JSON; omitted values remain unknown")
        if name == "collect":
            p.add_argument("--operations", choices=("none", "basic", "full"), default="full")
            p.add_argument("--endpoint")
            p.add_argument("--model")
            p.add_argument("--allow-remote", action="store_true")
            p.add_argument("--repeats", type=int, default=1)
            p.add_argument("--seed", type=int, default=1729)
            p.add_argument("--concurrency", type=int, default=1)
            p.add_argument("--timeout", type=float, default=15)
            p.add_argument("--max-tokens", type=int, default=256)
            p.add_argument("--disable-thinking-template", action="store_true")
        else:
            p.add_argument("--receipt", help="Existing ocl.run/1 useful-work receipt")
            p.add_argument("--useful-work-basis", choices=("observed", "published", "modeled", "unknown"), default="unknown", help="Source basis of useful work; omitted legacy/undeclared imports remain unknown")
            p.add_argument("--inventory", help="Existing inventory JSON")
            p.add_argument("--operation", action="append", help="Existing operational receipt; repeatable")
    args = parser.parse_args(argv)
    if args.mode == "network-health":
        return collect_network(args)
    if args.mode == "ingest" and not (args.receipt or args.operation or args.inventory):
        parser.error("ingest requires a receipt, inventory or operation")
    return collect(args)

if __name__ == "__main__":
    raise SystemExit(main())
