# Unified instrument and portable result packet

Run from the Cantos repository root with Python 3.10 or later. The command uses the existing OCL collectors and exact evaluator. It writes a new result directory and preserves logs, original receipts, failed attempts and source hashes. It neither starts a GPU server nor installs dependencies.

## Collect on the machine running this command

```sh
python -B open-compute-ledger/instruments/collect.py collect --out /your/new-result-directory --label my-host
```

The default full collection records a host snapshot, a bounded local service/process/storage check, a 4 MiB write with fsync followed by a separate-process hash readback, and three deliberate restarts of its own loopback service. The recovery collector runs two 23-second conditions. It touches only its new output directory and its own child services/processes. Existing services remain outside its scope. Linux also uses the existing inventory probe when Bash is available; NVIDIA inventory uses an installed nvidia-smi. Missing tools remain unknown.

Use `--operations basic` for only the existing small local operations collector, or `--operations none` for inventory. The collectors preserve their scope: loopback reachability, logical byte integrity and controlled child recovery do not establish a cloud SLA or physical power-loss durability.

## Run accepted useful work on an already serving endpoint

```sh
python -B open-compute-ledger/instruments/collect.py collect --out /your/new-model-run --label my-serving-stack --operations basic --endpoint http://127.0.0.1:8000 --model ACTUAL_SERVED_MODEL --configuration /your/configuration.json --financials /your/observed-inputs.json
```

The endpoint and model are explicit. A non-loopback endpoint additionally requires `--allow-remote`; the wrapper creates no accounts, rentals or serving processes. Existing OCL_API_KEY authentication is consumed from the process environment and never retained in the packet. Optional `--disable-thinking-template` passes the existing Qwen-compatible enable_thinking=false option. Exact seed, concurrency, repeats, request timeout and max tokens are CLI arguments. Defaults are seed 1729, concurrency 1, one repeat, 15-second request timeout and 256 max tokens.

This uses the existing synthetic two-turn lookup/data-analysis suite and `ocl.exact-json/1` evaluator. Requests remain nonstreamed, so TTFT stays unknown. Successful HTTP completion never becomes accepted work. Model/runtime/precision/GPU identity can be declared in the configuration file:

```json
{"id":"my-serving-stack","label":"My serving configuration","provider":"my-estate","model":"ACTUAL_SERVED_MODEL","runtime":"ACTUAL_RUNTIME","precision":"ACTUAL_PRECISION","accelerator":"ACTUAL_ACCELERATOR"}
```

These are operator declarations. The packet preserves native inventory and source hashes separately.

## Reuse existing measurements

```sh
python -B open-compute-ledger/instruments/collect.py ingest --out /your/new-import --label retained-run --receipt /your/existing-ocl-run.json
python -B open-compute-ledger/instruments/collect.py ingest --out /your/new-operations-import --label retained-operations --operation /your/storage-comparison.json --operation /your/recovery-comparison.json
```

The first command accepts an existing `ocl.run/1` receipt, copies its exact bytes and projects its explicit acceptance fields. It performs no inference or grading. Optional `--inventory`, repeated `--operation`, configuration and financial inputs preserve independent evidence. Import time does not renew the original observation dates. The operations-only packet carries no useful-work acceptance count.

## Cost and energy inputs

`--financials` reads a JSON object with `costs` and `energy` arrays. Each entry requires `value`, `unit`, `scope`, `source` and `basis`. Cost unit is USD. Energy unit is Wh, kWh or J. Basis is observed, modeled or published. Values must be finite and nonnegative. Use scope `complete_run` only for a cost total that includes the entire named run; retain component scopes for partial values. Energy scopes should identify board, host or facility and the measurement interval. A board measurement remains a board measurement.

The financial input and its hash remain in the packet. The declaration of an invoice, meter or source is operator supplied; no independent accounting attestation is inferred. Omitted quantities remain unknown. The empty template is `financial-inputs.example.json`; enter real sourced values or explicitly labeled assumptions.

## Useful-work evidence classification

The optional top-level `useful_work_basis` is one of `observed`, `published`, `modeled` or `unknown`. New endpoint collection sets `observed` only after an actual native useful-work receipt exists. Inventory-only packets remain `unknown` for useful work. Receipt ingestion accepts `--useful-work-basis`; its default is `unknown`, because a file format and SHA256 alone do not establish how its result was obtained. Select `published` for imported published results and `modeled` for explicit scenarios.

Older packets without this field continue to import and retain their counts, with useful-work basis `unknown`. The direct measured-provider filter admits imported useful work only when its declared basis is `observed`. A declaration preserves source attribution; it does not independently authenticate the source or establish broader provider operations. Cost and energy keep their separate entry-level basis.

The public example in examples/run3-mi300x.packet.json carries the retained cloud measurement under its published basis.
