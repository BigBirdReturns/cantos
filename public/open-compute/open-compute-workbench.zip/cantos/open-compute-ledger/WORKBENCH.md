# Open Compute Workbench

From the extracted cantos directory, run `python -B open-compute-ledger/run.py --open` with Python 3.10 or later. On Windows, start-workbench.cmd in the open-compute-ledger directory runs the same program. The local address is http://127.0.0.1:8841/. Ctrl+C stops the service. The launcher stores your editions in local application data, or use `--store ./my-decisions` to choose a folder.

Compare Run 3 configurations under Accepted work. Set a minimum percentage or first-token deadline, then change a quoted hourly rate under Cost assumptions and compare again. History retains each decision, its assumptions and excluded configurations. Export downloads the selected edition's JSON. Token economics compares matching published throughput and price observations within the retained shortlist. A carried listing is a scenario based on historical supply. Add `--database PATH` to use your own compatible joined costs.sqlite through the native market-query owner.

In Collect & import choose examples/run3-mi300x.packet.json from the open-compute-ledger directory, then import. This is the existing MI300X arm projected into the portable schema. Its workload appears as an imported comparison, labelled as published evidence. Reimporting identical bytes returns the same record. Original capture time and the later grading basis appear in the provenance. Publication does not add an independent replication.

For new evidence, the command `python -B open-compute-ledger/instruments/collect.py collect --out ./my-result --label my-host --operations none` collects inventory on your own machine into a new folder. Local inventory can contain machine identifiers. Read instruments/INSTRUMENT-PACKET.md for receipt ingestion, optional accepted-work collection and bounded operational checks. Money, energy and acceptance keep separate evidence classes.

The evidence report opens directly from index.html in this directory. The table distinguishes common and original grades. See RIGHTS.md and PUBLIC-SOURCES.json for component notices and source identities.

## Operational evidence

Run the owned local operations collector from the extracted cantos directory:

    python -B open-compute-ledger/instruments/collect.py collect --out ./my-operations --label my-host --operations basic

In **Collect & import**, import `my-operations/packet.json` and open it under
**Operational evidence**. The workbench shows its declared scope and the exact
retained packet. The JSON endpoint is `GET /api/operations`. CLI access uses
`python -B open-compute-ledger/engine/engine.py operations --store SESSION_STORE`.
This edition accepts owned and attributed operational receipts. It ships without
the private owner observation closure. Finite local probes leave commercial
provider conformance, external network and uptime claims unknown.

## Review a serving change

Start the workbench and select **Open the real vLLM experiment**. The first view
revalidates 192 retained requests and source-bound application grades: 21/96
accepted on each side, incomparable under the original 80% requirement. No
inference or uploaded code executes. Import one comparison ZIP exported with
`maintainer.py export-comparison --analysis ANALYSIS --out comparison.zip`.

Native pass/regression/incomparable/error is authoritative. Policy reanalysis
keeps the original capture and creates a permanently labelled post-hoc history
entry. Export the analysis JSON for that edition and the original evidence ZIP
separately. Price assumptions remain modeled; actual cost and whole-system energy
remain unknown. The catalog is separately available for scoped configuration
screening. Broader application, operational and economic coverage remains open.
