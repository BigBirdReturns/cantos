"""Public API / release-log recovery. Bulk files always go to --output-dir.

InferenceX API observations are a distinct, curated projection, not recovered
Actions ZIPs. Original dates and DB IDs survive inherited chart snapshots.
MLPerf uses the existing LoadGen adapter; unsupported/invalid logs stay refused.
"""
import argparse
import collections
import datetime as dt
import gzip
import contextlib
import io
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
import time
import urllib.error
import urllib.parse
import urllib.request

import importer

API = 'https://inferencex.semianalysis.com/api/v1/benchmarks/history'


@contextlib.contextmanager
def gztext(path):
    with open(path, 'wb') as raw, gzip.GzipFile(filename='', fileobj=raw, mode='wb', mtime=0) as zipped:
        with io.TextIOWrapper(zipped, encoding='utf-8', newline='\n') as text:
            yield text


def save(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, allow_nan=False) + '\n', encoding='utf-8', newline='\n')


def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 22), b''):
            h.update(chunk)
    return h.hexdigest()


def pointer(path, rows=None, **extra):
    return dict(path=str(Path(path).resolve()), bytes=Path(path).stat().st_size,
                sha256=sha(path), rows=rows, **extra)


def get(url, path):
    """Resumable exact-response cache; no credentials; bounded requests/backoff."""
    path = Path(path)
    meta = path.with_suffix(path.suffix + '.receipt.json')
    if path.exists() and meta.exists():
        receipt = json.loads(meta.read_text())
        if receipt['url'] != url or receipt['sha256'] != sha(path):
            raise ValueError('cache identity mismatch: ' + str(path))
        return path.read_bytes(), receipt
    req = urllib.request.Request(url, headers={'User-Agent': 'Cantos-public-history/1'})
    for attempt in range(3):
        try:
            with urllib.request.urlopen(req, timeout=90) as response:
                raw = response.read(512 * 1024 * 1024 + 1)
                if len(raw) > 512 * 1024 * 1024:
                    raise ValueError('response exceeds 512 MiB')
                receipt = {'url': url, 'retrieved_at': dt.datetime.now(dt.timezone.utc).isoformat(),
                           'status': response.status, 'sha256': importer.digest(raw), 'bytes': len(raw),
                           'headers': {k: v for k, v in response.headers.items()
                                       if k.lower() in ('date', 'etag', 'last-modified', 'x-ratelimit-remaining', 'x-ratelimit-reset')}}
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(raw)
            save(meta, receipt)
            time.sleep(0.5)
            return raw, receipt
        except urllib.error.HTTPError as e:
            save(meta.with_suffix('.error.json'), {'url': url, 'status': e.code,
                 'retrieved_at': dt.datetime.now(dt.timezone.utc).isoformat()})
            if e.code not in (429, 502, 503, 504) or attempt == 2:
                raise
            delay = int(e.headers.get('Retry-After', 5 * (attempt + 1)))
            if delay > 60:
                raise RuntimeError(f'rate limited; retry after {delay}s') from e
            time.sleep(delay)


def api_observations(src, receipt, index):
    """Keep API projection identity distinct from artifact identity, with no fake pin."""
    entry = dict(source='inferencex-api', url=receipt['url'], revision='API-response-sha256:' + receipt['sha256'],
                 retrieved_at=receipt['retrieved_at'], observed_at=src['date'])
    base = importer.base_record(entry, b'', index, receipt['sha256'], False)
    run = re.search(r'/runs/(\d+)', src.get('run_url') or '')
    base['provenance'].update(sha256=receipt['sha256'], upstream_observation_id=str(src['id']),
                             workflow_run_id=int(run[1]) if run else None, run_url=src.get('run_url'),
                             artifact_id=None, date_basis='API original observation date; not curve_date')
    base.update(hardware=importer.hardware(src['hardware']), model=src['model'],
                model_class=importer.model_class(src['model']), precision=importer.precision(src['precision']),
                precision_detail=src['precision'], framework=src['framework'], config=src,
                gpus=None, gpu_count_rule='API topology unverified; metrics already per GPU',
                data_kind='public-database-projection', outcome='reported',
                workload={'input_tokens': src.get('isl'), 'output_tokens': src.get('osl'),
                          'concurrency': src.get('conc'), 'scenario': src['benchmark_type'],
                          'dataset': 'UNVERIFIED', 'request_rate': None})
    base['warnings'] = ['Curated public API history, not raw Actions artifact; ingestion may omit failures.',
                        'Original observation date retained independently of inherited chart curve_date.',
                        'No useful-work, latency qualification, invoice or measured utilization claim.']
    names = {'output_tput_per_gpu': ('output_throughput_per_gpu', 'tokens/s/GPU'),
             'tput_per_gpu': ('total_token_throughput_per_gpu', 'tokens/s/GPU'),
             'input_tput_per_gpu': ('input_throughput_per_gpu', 'tokens/s/GPU')}
    # Latencies retained too, without turning interpolated dashboard curves into measurements.
    for metric in ('ttft', 'e2el', 'itl', 'tpot'):
        for stat in ('mean', 'median', 'p90', 'p95', 'p99'):
            names[stat + '_' + metric] = (stat + '_' + metric + '_ms', 'ms')
    for key, (name, units) in names.items():
        value = src['metrics'].get(key)
        if value is None:
            continue
        r = dict(base, metric={'name': name, 'value': importer.number(value) * (1000 if units == 'ms' else 1), 'units': units})
        # Retrieval time / response order / chart snapshot are not observation identity.
        r['id'] = importer.digest(json.dumps(['inferencex-api', str(src['id']), name, value], sort_keys=True).encode())
        yield r


def inferencex_api(root, upstream):
    root = Path(root)
    models_path = Path(upstream) / 'packages/constants/src/models.ts'
    text = models_path.read_text(encoding='utf-8').split('export const DB_MODEL_TO_DISPLAY', 1)[1].split('};', 1)[0]
    models = sorted(set(re.findall(r"^\s*(?:'[^']+'|[\w.]+): '([^']+)'", text, re.M)))
    if not models:
        raise ValueError('no model catalog found')
    revision = subprocess.check_output(['git', '-C', str(upstream), 'rev-parse', 'HEAD'], text=True).strip()
    summary = {'source': API, 'catalog_revision': revision, 'models': models, 'queries': [], 'errors': [],
               'deduplication': 'upstream DB observation ID + metric name + value; curve copies discarded; artifacts remain separate',
               'scope': 'all catalog models, three documented fixed shapes, all agentic history; curated successful ingests, not complete raw artifacts'}
    out = root / 'inferencex-api.jsonl.gz'
    out.parent.mkdir(parents=True, exist_ok=True)
    seen, observations, dates, source_ids = set(), 0, set(), set()
    with gztext(out) as f:
        for model in models:
            for shape in [(1024, 1024), (1024, 8192), (8192, 1024), None]:
                params = {'model': model}
                params.update({'isl': shape[0], 'osl': shape[1]} if shape else {'benchmarkType': 'agentic_traces'})
                url = API + '?' + urllib.parse.urlencode(params)
                path = root / 'raw' / (importer.digest(url.encode())[:20] + '.json')
                try:
                    raw, receipt = get(url, path)
                    rows = json.loads(raw)
                    if not isinstance(rows, list):
                        raise ValueError('API did not return a list')
                    summary['queries'].append(dict(receipt, returned_rows=len(rows), path=str(path.resolve())))
                    for i, src in enumerate(rows):
                        for r in api_observations(src, receipt, i):
                            if r['id'] in seen:
                                continue
                            seen.add(r['id'])
                            source_ids.add(str(src['id']))
                            dates.add(src['date'])
                            f.write(json.dumps(r, separators=(',', ':'), allow_nan=False) + '\n')
                            observations += 1
                    print(model, shape, len(rows), 'returned;', observations, 'metrics retained', flush=True)
                except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError) as e:
                    summary['errors'].append({'url': url, 'error': str(e)})
                    print('FAILED', url, str(e), flush=True)
    summary.update(output=pointer(out, observations), unique_source_rows=len(source_ids),
                   date_range=[min(dates), max(dates)] if dates else [], returned_rows=sum(x['returned_rows'] for x in summary['queries']))
    save(root / 'SUMMARY.json', summary)
    return summary


def mlperf(root, release, archive, upstream):
    root = Path(root); root.mkdir(parents=True, exist_ok=True)
    revision = subprocess.check_output(['git', '-C', str(upstream), 'rev-parse', 'HEAD'], text=True).strip()
    base = f'https://raw.githubusercontent.com/mlcommons/inference_results_{release}/{revision}/'
    summary_path = root / f'mlperf-{release}-SUMMARY.json'
    prior = json.loads(summary_path.read_text()) if summary_path.exists() else {}
    now = prior.get('retrieved_at') or dt.datetime.now(dt.timezone.utc).isoformat()
    summary = dict(release=release, revision=revision, retrieved_at=now, archive=pointer(archive),
                   performance_logs=0, imported_logs=0, metric_observations=0, refused=[])
    manifest = []
    out = root / f'mlperf-{release}.jsonl.gz'
    with tarfile.open(archive) as tar, gztext(out) as f:
        members = {m.name: m for m in tar if m.isfile()}
        for name in sorted(members):
            if not re.match(r'^(closed|open|network)/[^/]+/results/[^/]+/[^/]+/[^/]+/performance/run_\d+/mlperf_log_summary.txt$', name):
                continue
            summary['performance_logs'] += 1
            parts = name.split('/')
            div, submitter, _, system, model, scenario = parts[:6]
            system_path = f'{div}/{submitter}/systems/{system}.json'
            raw = tar.extractfile(members[name]).read()
            system_raw = tar.extractfile(members[system_path]).read() if system_path in members else b'{}'
            system_obj = json.loads(system_raw)
            measurement_prefix = f'{div}/{submitter}/measurements/{system}/{model}/{scenario}/'
            measurement_files = [n for n in members if n.startswith(measurement_prefix) and n.endswith('.json')]
            evidence = [{'url': base+system_path, 'sha256': importer.digest(system_raw)}] if system_path in members else []
            measurements = []
            for n in measurement_files:
                b = tar.extractfile(members[n]).read()
                measurements.append(json.loads(b))
                evidence.append({'url': base+n, 'sha256': importer.digest(b)})
            try:
                gpus = importer.count(system_obj['accelerators_per_node'], True) * importer.count(system_obj['number_of_nodes'], True)
            except (KeyError, ValueError, TypeError):
                gpus = None
            md = dict(hardware=system_obj.get('accelerator_model_name', 'UNVERIFIED'), gpus=gpus,
                      model=model, precision=next((m.get('weight_data_types') for m in measurements if m.get('weight_data_types')), 'UNVERIFIED'),
                      framework=system_obj.get('framework', 'UNVERIFIED'))
            entry = dict(source='mlperf', url=base+name, revision=revision, retrieved_at=now, observed_at=None,
                         sha256=importer.digest(raw), metadata=md, metadata_evidence=evidence)
            manifest.append(dict(entry, path=name))
            try:
                rows = importer.mlperf(entry, raw, importer.digest(revision.encode()), False)
                for r in rows:
                    r['provenance'].update(release=release, path=name, systems_json_url=base+system_path,
                                           systems_json_sha256=importer.digest(system_raw))
                    r['config'].update(systems_json=system_obj, measurement_jsons=measurements)
                    # Release/commit timestamps do not supply a measurement day.
                    r['warnings'].append('Measurement date unknown: excluded from exact-date price join.')
                    f.write(json.dumps(r, separators=(',', ':'), allow_nan=False) + '\n')
                summary['metric_observations'] += len(rows)
                summary['imported_logs'] += 1
            except (ValueError, TypeError, KeyError) as e:
                summary['refused'].append({'path': name, 'sha256': entry['sha256'], 'reason': str(e)})
    save(root / f'mlperf-{release}-manifest.json', {'files': manifest})
    summary['output'] = pointer(out, summary['metric_observations'])
    save(root / f'mlperf-{release}-SUMMARY.json', summary)
    print(json.dumps({k:v for k,v in summary.items() if k != 'refused'}), flush=True)
    return summary


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('source', choices=['inferencex-api', 'mlperf'])
    p.add_argument('--output-dir', type=Path, required=True)
    p.add_argument('--upstream', type=Path, required=True)
    p.add_argument('--release')
    p.add_argument('--archive', type=Path)
    a = p.parse_args()
    if a.source == 'inferencex-api':
        inferencex_api(a.output_dir, a.upstream)
    else:
        mlperf(a.output_dir, a.release, a.archive, a.upstream)


if __name__ == '__main__':
    main()
