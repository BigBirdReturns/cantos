"""Rank three distinct accelerator/provider pairs with prices on two as-of dates.

Performance is drawn only from the preceding 60 inclusive calendar days. The
same selected model/precision/workload cohort is compared 90 days earlier.
This is a retrospective deployment-cost envelope, not a matched performance
trend or a claim that today's historical export was available at the old date.
"""
import argparse
import collections
import datetime as dt
import json
from pathlib import Path
import sqlite3

from history_findings import write_csv
from public_history import save, pointer

MIN_POINTS=20
MIN_DAYS=3
MIN_RUNS=3
MIN_ACCELERATORS=2
PAIR_POINTS=5
PAIR_DAYS=2
PAIR_RUNS=2
COHORT_FIELDS=('model','precision','scenario','input_tokens','output_tokens')
MODEL_LABELS=json.loads((Path(__file__).parent/'model-labels-20261117.json').read_text())['labels']
METHOD=(
 'Each as-of date uses its own inclusive trailing 60 days and exact-date price rows. '
 'A priced observation is one logical InferenceX point with at least one screened price on the as-of date. '
 'No future benchmark dates. Source-date alternatives count once; lowest output throughput of retained in-window '
 'alternatives is used. Exclude failed/nonpositive, inferred-output, cross-source-disagreement, unknown precision '
 'and unknown workflow-ID points. Enough: >=20 logical points, >=3 source dates, >=3 workflow runs, '
 '>=2 priced accelerator families, and >=3 eligible accelerator/provider pairs. Each pair requires >=5 '
 'logical points on >=2 source dates from >=2 workflow runs. Select each model\'s eligible cohort with the '
 'most logical points at the latest date (stable lexicographic ties); hold that precision/scenario/nominal '
 'input/output cohort fixed for the earlier date. All eligible cohorts are also supplied. '
 'Prices: positive USD on-demand full-instance catalog listings only; exclude explicit unavailable, '
 'GPU-only host-excluded, unverified historical AWS components and AWS-source prices below $0.10/GPU-hour. '
 'Take the minimum regional/product/source listing per accelerator/provider, preserving its price ID and provenance. '
 'Label carried catalog state and repeat rankings without it. Minimize cost over the screened benchmark configs '
 'at 100% utilization, billing both prefill/decode pools. No latency, accuracy, provider-performance, memory, '
 'interconnect or availability qualification. Agentic trace membership/lengths are not matched; that cohort is '
 'an observed envelope only. Prices are retrospective listings, not quotes or invoices.')


def screened_price(r,allow_carry=True):
    raw=json.loads(r['row_json'])
    available=str(raw.get('available','unknown')).strip().lower()
    return (r['usd_per_gpu_hour']>0 and r['price_component']=='catalog_instance'
        and available not in ('false','0','no','unavailable','out_of_stock','out of stock')
        and not (r['provider']=='aws' and r['source']=='aws' and r['usd_per_gpu_hour']<0.1)
        and (allow_carry or r['price_coverage']!='carried_forward_catalog_state'))


def cohort(r):return tuple(r[k] for k in COHORT_FIELDS)


def stats(points):
    return dict(logical_points=len(points),source_dates=len({r['date'] for r in points}),
        workflow_runs=len({json.loads(r['identity_json'])['workflow_run_id'] for r in points}),
        accelerators=len({r['accelerator'] for r in points}))


def enough(s,pairs):
    return (s['logical_points']>=MIN_POINTS and s['source_dates']>=MIN_DAYS and s['workflow_runs']>=MIN_RUNS
        and s['accelerators']>=MIN_ACCELERATORS and pairs>=3)


def pair_enough(points):
    s=stats(points)
    return s['logical_points']>=PAIR_POINTS and s['source_dates']>=PAIR_DAYS and s['workflow_runs']>=PAIR_RUNS


def snapshot(db,as_of,allow_carry=True,limit=3):
    start=(dt.date.fromisoformat(as_of)-dt.timedelta(days=59)).isoformat()
    floors={};price_count=0
    for r in db.execute('SELECT * FROM prices WHERE date=?',(as_of,)):
        r=dict(r)
        if not screened_price(r,allow_carry):continue
        price_count+=1;key=(r['accelerator'],r['provider'])
        if key not in floors or (r['usd_per_gpu_hour'],r['price_id'])<(floors[key]['usd_per_gpu_hour'],floors[key]['price_id']):floors[key]=r
    priced_acc={k[0] for k in floors}
    points={};excluded=collections.Counter();all_cohorts=set()
    for r in db.execute('SELECT * FROM benchmarks WHERE date BETWEEN ? AND ? ORDER BY cost_observation_id',(start,as_of)):
        r=dict(r);all_cohorts.add(cohort(r));ident=json.loads(r['identity_json'])
        reason=None
        if r['cross_source_disagreement']:reason='cross_source_disagreement'
        elif r['output_basis'].startswith('inferred'):reason='inferred_output'
        elif not ident.get('workflow_run_id'):reason='unknown_workflow'
        elif r['precision'].lower() in ('','unverified','unknown'):reason='unknown_precision'
        elif r['accelerator'] not in priced_acc:reason='no_screened_asof_price'
        if reason:excluded[reason]+=1;continue
        # One point regardless of number of source dates/throughput versions.
        key=r['run_id'];previous=points.get(key)
        if previous is None or (r['output_tps'],r['date'],r['cost_observation_id'])<(previous['output_tps'],previous['date'],previous['cost_observation_id']):points[key]=r
    groups=collections.defaultdict(list)
    for r in points.values():groups[cohort(r)].append(r)
    coverage=[];rankings={}
    for key in sorted(all_cohorts,key=str):
        pp=groups[key];ss=stats(pp);candidates=[]
        for (acc,provider),price in sorted(floors.items()):
            bb=[r for r in pp if r['accelerator']==acc]
            if not pair_enough(bb):continue
            best=min(bb,key=lambda r:(price['usd_per_gpu_hour']/r['output_tps'],r['cost_observation_id']))
            rawprice=json.loads(price['row_json']);ident=json.loads(best['identity_json'])
            pre,dec=ident.get('num_prefill_gpu'),ident.get('num_decode_gpu')
            split=bool(ident.get('disagg') and pre and dec and
                ((ident.get('prefill_num_workers',0)>0 and ident.get('decode_num_workers',0)>0) or pre!=dec))
            allocated=pre+dec if split else dec
            candidates.append(dict(as_of=as_of,window_start=start,**dict(zip(COHORT_FIELDS,key)),
                model_display_name=MODEL_LABELS.get(key[0],key[0]),
                accelerator=acc,provider=provider,usd_per_million_output_tokens=price['usd_per_gpu_hour']*1e6/(3600*best['output_tps']),
                benchmark_date=best['date'],benchmark_age_days=(dt.date.fromisoformat(as_of)-dt.date.fromisoformat(best['date'])).days,
                benchmark_date_basis=best['date_basis'],workflow_run_id=ident['workflow_run_id'],logical_point_id=best['run_id'],
                cost_observation_id=best['cost_observation_id'],framework=best['framework'],concurrency=best['concurrency'],
                benchmark_allocated_gpus=allocated,prefill_gpus=pre,decode_gpus=dec,disaggregated=split,
                spec_method=best['spec_method'],output_tokens_per_second_per_gpu=best['output_tps'],output_basis=best['output_basis'],
                benchmark_configuration=json.dumps(ident,sort_keys=True,separators=(',',':')),
                benchmark_provenance=best['source_refs_json'],price_id=price['price_id'],price_date=as_of,
                usd_per_gpu_hour=price['usd_per_gpu_hour'],price_source=price['source'],price_component=price['price_component'],
                price_coverage=price['price_coverage'],price_carried_forward=price['price_coverage']=='carried_forward_catalog_state',
                carry_forward_days=price['carry_forward_days'],source_change_time=price['source_change_time'],
                price_gpu_count=price['gpu_count'],price_variant=price['variant'],price_region=price['region'],
                price_instance_type=price['instance_type'],listed_available=rawprice.get('available'),price_provenance=price['provenance_json'],
                pair_logical_points=len(bb),pair_workflow_runs=stats(bb)['workflow_runs'],pair_source_dates=stats(bb)['source_dates'],
                cohort_logical_points=ss['logical_points'],cohort_workflow_runs=ss['workflow_runs'],cohort_source_dates=ss['source_dates'],
                utilization_assumed=1.0,accounting_basis='USD on-demand public full-instance listing; not expenditure',
                cost_date_basis='as-of price applied to prior-60-day benchmark; not a same-day historical join',
                configuration_limit='accelerator family only; provider allocation/throughput unverified; no latency or quality gate'))
        candidates.sort(key=lambda r:(r['usd_per_million_output_tokens'],r['accelerator'],r['provider']))
        eligible=enough(ss,len(candidates))
        coverage.append(dict(as_of=as_of,window_start=start,**dict(zip(COHORT_FIELDS,key)),**ss,
            eligible_pairs=len(candidates),eligible=eligible))
        if eligible:
            rankings[key]=[dict(r,rank=i+1) for i,r in enumerate(candidates[:limit])]
    return dict(coverage=coverage,rankings=rankings,screened_prices=price_count,pair_floors=len(floors),excluded=dict(excluded))


def render_table(rows,selected,latest,earlier,status):
    lines=['Decision table: USD per million reported output tokens at 100% utilization.',
        'Latest '+latest+'; comparison '+earlier+'. Each date uses its own prior 60 days.',METHOD,'',
        'Each line pairs the same model/cohort/rank across dates; ranks may name different hardware.',
        'Full topology, workflow, source URLs, price IDs and carry age are in top-three.csv and EVIDENCE.json.','']
    for key in sorted(selected,key=str):
        lines.append('MODEL '+MODEL_LABELS.get(key[0],key[0])+' ['+key[0]+'] | '+str(dict(zip(COHORT_FIELDS[1:],key[1:]))))
        for rank in (1,2,3):
            cols=[]
            for day in (latest,earlier):
                rr=[r for r in rows if cohort(r)==key and r['as_of']==day and r['rank']==rank]
                if not rr:cols.append(day+': insufficient coverage');continue
                r=rr[0]
                cols.append(f"{day}: #{rank} {r['accelerator']}/{r['provider']} ${r['usd_per_million_output_tokens']:.6f}; "
                    f"{r['framework']} GPUs={r['benchmark_allocated_gpus']} conc={r['concurrency']} spec={r['spec_method']}; benchmark {r['benchmark_date']}; "
                    f"${r['usd_per_gpu_hour']:.4f}/GPU-hour via {r['price_source']}; carry={r['price_carried_forward']} "
                    f"days={r['carry_forward_days']}")
            lines.append(' | '.join(cols))
        lines.append('')
    return '\n'.join(lines)+'\n'


def build(database,output,as_of=None):
    output.mkdir(parents=True,exist_ok=True)
    db=sqlite3.connect(database.resolve().as_uri()+'?mode=ro',uri=True);db.row_factory=sqlite3.Row
    latest=as_of or db.execute('SELECT max(date) FROM prices').fetchone()[0]
    earlier=(dt.date.fromisoformat(latest)-dt.timedelta(days=90)).isoformat()
    current=snapshot(db,latest);prior=snapshot(db,earlier)
    selected={}
    for row in sorted(current['coverage'],key=lambda r:(-r['logical_points'],str(cohort(r)))):
        if row['eligible']:selected.setdefault(row['model'],cohort(row))
    chosen=set(selected.values());main=[];allrows=[];status=[]
    for day,data in ((latest,current),(earlier,prior)):
        for key,rr in data['rankings'].items():
            allrows.extend(rr)
            if key in chosen:main.extend(rr)
        for key in sorted(chosen,key=str):
            r=next((r for r in data['coverage'] if cohort(r)==key),None)
            status.append(dict(as_of=day,**dict(zip(COHORT_FIELDS,key)),
                status='ranked' if key in data['rankings'] else 'insufficient_coverage',coverage=r))
    fresh=[]
    for day in (latest,earlier):
        data=snapshot(db,day,False)
        for key in chosen:fresh.extend(data['rankings'].get(key,[]))
    write_csv(output/'top-three.csv',main);write_csv(output/'all-cohorts-top-three.csv',allrows)
    write_csv(output/'top-three-no-carry.csv',fresh)
    write_csv(output/'cohort-coverage.csv',current['coverage']+prior['coverage'])
    save(output/'EVIDENCE.json',dict(method=METHOD,rows=main,no_carry_rows=fresh,status=status))
    (output/'DECISION-TABLE.txt').write_text(render_table(main,chosen,latest,earlier,status),encoding='utf-8')
    summary=dict(latest=latest,earlier=earlier,window_days=60,comparison_days=90,method=METHOD,
        models=sorted(selected),selected_cohorts=[dict(zip(COHORT_FIELDS,k)) for k in sorted(chosen,key=str)],
        top_three_rows=len(main),latest_rows=sum(r['as_of']==latest for r in main),earlier_rows=sum(r['as_of']==earlier for r in main),
        all_cohort_rows=len(allrows),no_carry_rows=len(fresh),status=status,
        snapshots={day:{k:v for k,v in s.items() if k not in ('rankings','coverage')} for day,s in ((latest,current),(earlier,prior))},
        input_database=str(database.resolve()))
    save(output/'SUMMARY.json',summary);db.close()
    print(json.dumps({k:summary[k] for k in ('latest','earlier','models','latest_rows','earlier_rows','no_carry_rows')}),flush=True)
    return summary


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--database',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--as-of')
    a=p.parse_args();build(a.database,a.output,a.as_of)
