"""Auditable tables of price/throughput envelopes and matched changes.

Each winning row is an actual joined_costs row. The envelope optimizes across
tested configs without a latency target and never asserts provider performance.
Source alternatives are retained in the full table, but disputed runs and
inferred output are excluded from the primary ranking.
"""
import argparse
import csv
import json
from pathlib import Path
import sqlite3
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'backfill'))
from public_history import save


def write_csv(path,rows):
    if not rows:return
    with path.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def build(database,output):
    output.mkdir(parents=True,exist_ok=True)
    db=sqlite3.connect(database);db.row_factory=sqlite3.Row
    db.execute('PRAGMA temp_store=MEMORY')
    # Reduce only for analysis. Full listing-level price and cost tables survive.
    db.executescript('''
      CREATE TEMP TABLE provider_day_unfiltered AS
      SELECT * FROM (
        SELECT price_id,date,accelerator,provider,source,usd_per_gpu_hour,price_coverage,carry_forward_days,
               row_number() OVER (PARTITION BY date,accelerator,provider ORDER BY usd_per_gpu_hour,price_id) AS rn
        FROM prices WHERE price_component!='accelerator_only_host_excluded') WHERE rn=1;
      CREATE TEMP TABLE provider_day_floor AS
      SELECT * FROM (
        SELECT price_id,date,accelerator,provider,source,usd_per_gpu_hour,price_coverage,carry_forward_days,
               row_number() OVER (PARTITION BY date,accelerator,provider ORDER BY usd_per_gpu_hour,price_id) AS rn
        FROM prices WHERE price_component='catalog_instance'
          AND NOT (provider='aws' AND source='aws' AND usd_per_gpu_hour<0.10)
          AND coalesce(json_extract(row_json,'$.available'),'unknown') NOT IN ('False',0)) WHERE rn=1;
      CREATE INDEX provider_floor_match ON provider_day_floor(date,accelerator);
    ''')
    predicate="""b.scenario='single_turn' AND b.input_tokens=1024 AND b.output_tokens=1024
      AND b.cross_source_disagreement=0 AND b.output_basis NOT LIKE 'inferred%'
      AND ((b.model='dsr1' AND b.precision='fp8') OR (b.model='gptoss120b' AND b.precision='fp4')
       OR (b.model='llama70b' AND b.precision='fp8'))"""
    price_coverage=[dict(r) for r in db.execute('''
      SELECT provider,accelerator,source,price_component,min(date) first_date,max(date) last_date,
        count(DISTINCT date) represented_days,count(*) listing_alternatives,
        count(DISTINCT CASE WHEN price_coverage!='carried_forward_catalog_state' THEN date END) observed_or_file_changed_days,
        sum(price_coverage='carried_forward_catalog_state') carried_forward_rows
      FROM prices GROUP BY provider,accelerator,source,price_component
      ORDER BY provider,accelerator,source,price_component''')]
    write_csv(output/'price-coverage.csv',price_coverage)
    cohort_coverage=[dict(r) for r in db.execute(f'''
      SELECT b.model,b.precision,substr(b.date,1,7) month,b.accelerator,
        count(*) eligible_cost_observations,count(DISTINCT b.run_id) logical_points,
        sum(EXISTS (SELECT 1 FROM provider_day_floor p WHERE p.date=b.date AND p.accelerator=b.accelerator)) priced_cost_observations
      FROM benchmarks b WHERE {predicate}
      GROUP BY b.model,b.precision,substr(b.date,1,7),b.accelerator
      ORDER BY b.model,month,b.accelerator''')]
    write_csv(output/'model-month-coverage.csv',cohort_coverage)
    sql=f'''SELECT * FROM (
        SELECT b.model,b.precision,substr(b.date,1,7) month,b.date,b.accelerator,p.provider,p.source,
          b.cost_observation_id,b.run_id,p.price_id,b.framework,b.concurrency,b.output_tps,
          p.usd_per_gpu_hour,p.price_coverage,p.carry_forward_days,
          p.usd_per_gpu_hour*1000000.0/(3600*b.output_tps) cost,
          row_number() OVER (PARTITION BY b.model,b.precision,substr(b.date,1,7)
            ORDER BY p.usd_per_gpu_hour/b.output_tps,b.cost_observation_id,p.price_id) rn
        FROM benchmarks b JOIN provider_day_floor p USING(date,accelerator) WHERE {predicate})
        WHERE rn=1 ORDER BY model,month'''
    monthly=[dict(r) for r in db.execute(sql)]
    for r in monthly:
        r['join_id']=r['cost_observation_id']+':'+r['price_id']
        n=db.execute(f'''SELECT count(DISTINCT b.cost_observation_id),count(DISTINCT b.accelerator),count(DISTINCT p.provider)
            FROM benchmarks b JOIN provider_day_floor p USING(date,accelerator)
            WHERE {predicate} AND b.model=? AND substr(b.date,1,7)=?''',(r['model'],r['month'])).fetchone()
        r.update(month_cost_observations=n[0],month_accelerators=n[1],month_providers=n[2])
    write_csv(output/'model-month-cheapest.csv',monthly)
    unfiltered=[dict(r) for r in db.execute(sql.replace('JOIN provider_day_floor','JOIN provider_day_unfiltered'))]
    write_csv(output/'model-month-cheapest-unfiltered.csv',unfiltered)
    # Same calculation but fresh catalog-file changes/OCP days only; demonstrates
    # how the carry-forward restriction changes price coverage and winners.
    freshsql=sql.replace('WHERE '+predicate, "WHERE p.price_coverage!='carried_forward_catalog_state' AND "+predicate)
    fresh=[dict(r) for r in db.execute(freshsql)]
    write_csv(output/'model-month-cheapest-no-carry.csv',fresh)
    # Provider spread is min listing per provider, not repeated region-weighted
    # prices; keep both the min and max provider operands and their source IDs.
    spread=[dict(r) for r in db.execute('''
      SELECT date,accelerator,count(*) providers,min(usd_per_gpu_hour) min_price,
        max(usd_per_gpu_hour) max_price,max(usd_per_gpu_hour)/min(usd_per_gpu_hour) ratio
      FROM provider_day_floor GROUP BY date,accelerator HAVING count(*)>=3
      ORDER BY date,accelerator''')]
    write_csv(output/'provider-day-spread.csv',spread)
    # Matched series: identical declared configuration excluding run/date/image.
    # Each observation gets that provider's floor on the same day. Restrict to
    # the three model/precision/shape cohorts, source disagreement-free.
    candidates=db.execute(f'''
      SELECT b.model,b.precision,b.accelerator,b.framework,b.concurrency,b.date,
        b.cost_observation_id,b.output_tps,b.identity_json,
        p.provider,p.source,p.price_id,p.usd_per_gpu_hour,p.price_coverage
      FROM benchmarks b JOIN provider_day_floor p USING(date,accelerator)
      WHERE {predicate} ORDER BY b.date,b.cost_observation_id''')
    groups={}
    for r in candidates:
        r=dict(r)
        identity=json.loads(r['identity_json']);identity.pop('workflow_run_id',None)
        key=(json.dumps(identity,sort_keys=True),r['provider'])
        if key not in groups:groups[key]=[r,r]
        else:groups[key][1]=r
    changes=[]
    for group in groups.values():
        first,last=group[0],group[-1]
        if first['date'][:7]==last['date'][:7]:continue
        throughput=last['output_tps']/first['output_tps'];price=last['usd_per_gpu_hour']/first['usd_per_gpu_hour']
        changes.append(dict(model=first['model'],precision=first['precision'],accelerator=first['accelerator'],
            provider=first['provider'],framework=first['framework'],concurrency=first['concurrency'],
            first_date=first['date'],last_date=last['date'],first_throughput=first['output_tps'],last_throughput=last['output_tps'],
            first_price=first['usd_per_gpu_hour'],last_price=last['usd_per_gpu_hour'],
            throughput_ratio=throughput,price_ratio=price,cost_ratio=price/throughput,
            first_price_source=first['source'],last_price_source=last['source'],
            first_coverage=first['price_coverage'],last_coverage=last['price_coverage'],
            first_join_id=first['cost_observation_id']+':'+first['price_id'],
            last_join_id=last['cost_observation_id']+':'+last['price_id']))
    changes.sort(key=lambda r:(r['model'],r['accelerator'],r['provider'],r['concurrency']))
    write_csv(output/'matched-configuration-changes.csv',changes)
    summary=dict(monthly_winners=len(monthly),monthly_winners_without_carry=len(fresh),
        price_coverage_groups=len(price_coverage),model_month_coverage_groups=len(cohort_coverage),
        provider_day_spreads=len(spread),matched_configuration_changes=len(changes),
        method='Three model/precision cohorts, single_turn nominal ISL=OSL=1024; 100% utilization; '
            'direct output/GPU throughput, no source-disagreement points. Min listed complete-instance '
            'price/GPU from each provider, excluding explicit out-of-stock, the historical AWS archive with unverified price components, and suspect AWS-source prices below $0.10/GPU-hour '
            '(original values and unfiltered winners retained); no latency/SLA/correctness gate. Same-day only, '
            'explicit catalog carry-forward included and separately excluded in a second table. '
            'Monthly winners optimize framework, topology and concurrency, so trends are observed envelopes, '
            'not controlled hardware improvements. Matched changes keep declared config but not runtime image fixed. '
            'No marketplace stock or multi-GPU allocation suitability is established.')
    save(output/'SUMMARY.json',summary)
    write_five_findings(db,output,monthly,changes,spread,summary['method'])
    db.commit();db.close()
    print(json.dumps(summary),flush=True)
    return summary


def write_five_findings(db,output,monthly,changes,spread,method):
    """Select named cohort endpoints and two counterexamples, retaining operands."""
    def joined(jid):
        bid,pid=jid.split(':')
        r=db.execute('SELECT * FROM joined_costs WHERE cost_observation_id=? AND price_id=?',(bid,pid)).fetchone()
        if not r:raise ValueError('finding no longer addresses a joined row')
        return dict(r)
    figures=[]
    labels={'gptoss120b':'gpt-oss-120b FP4','dsr1':'DeepSeek-R1-0528 FP8','llama70b':'Llama-3.3-70B-Instruct FP8'}
    for model in ('gptoss120b','dsr1','llama70b'):
        rr=[r for r in monthly if r['model']==model]
        first,last=rr[0],rr[-1]
        if first['month']==last['month']:
            text=f"{labels[model]}: cheapest joined cohort point ${first['cost']:.6f}/million output tokens, {first['accelerator']} / {first['provider']} on {first['date']}. Only {first['month']} has a priced 1,024/1,024 FP8 cohort; no later trend is supported."
        else:
            pct=(last['cost']/first['cost']-1)*100
            text=f"{labels[model]}: monthly minimum ${first['cost']:.6f} ({first['date']}, {first['accelerator']} / {first['provider']}) to ${last['cost']:.6f} ({last['date']}, {last['accelerator']} / {last['provider']}), {pct:+.2f}%."
            text+=f" Cohort coverage changes from {first['month_cost_observations']} priced cost observations / {first['month_accelerators']} accelerators to {last['month_cost_observations']} / {last['month_accelerators']}; this is a changing tested envelope, not a hardware trend."
        figures.append(dict(number=len(figures)+1,text=text,basis=method,table_rows=[first,last],joined_rows=[joined(r['join_id']) for r in {first['join_id']:first,last['join_id']:last}.values()]))
    last=next(r for r in reversed(spread) if r['accelerator']=='H100')
    offers=[dict(r) for r in db.execute('SELECT * FROM provider_day_floor WHERE date=? AND accelerator=? ORDER BY usd_per_gpu_hour,provider,price_id',(last['date'],'H100'))]
    low,high=offers[0],offers[-1]
    text=f"H100 on {last['date']}: provider minimum listings span ${low['usd_per_gpu_hour']:.2f}/GPU-hour ({low['provider']}) to ${high['usd_per_gpu_hour']:.2f} ({high['provider']}), {last['ratio']:.2f}x across {last['providers']} providers. Both endpoints are {low['price_coverage']} / {high['price_coverage']}; this is catalog history, not verified current quotes."
    figures.append(dict(number=4,text=text,table_row=last,offers=offers,
        endpoint_prices=[dict(db.execute('SELECT * FROM prices WHERE price_id=?',(r['price_id'],)).fetchone()) for r in (low,high)]))
    # Fixed explicit selectors make the counterexamples stable and reviewable.
    offset=next(r for r in changes if r['model']=='dsr1' and r['provider']=='verda' and r['accelerator']=='B300' and r['concurrency']==4 and r['last_date']=='2026-05-22')
    stable=next(r for r in changes if r['model']=='dsr1' and r['provider']=='nebius' and r['accelerator']=='B300' and r['concurrency']==64 and r['last_date']=='2026-05-22')
    def pct(v):return (v-1)*100
    text=f"DeepSeek-R1-0528 FP8 / B300 / SGLang, {offset['first_date']} to {offset['last_date']}: Verda at concurrency 4 gains {pct(offset['throughput_ratio']):.2f}% throughput, but its listed floor rises {pct(offset['price_ratio']):.2f}% (${offset['first_price']:.3f} to ${offset['last_price']:.3f}), increasing token cost {pct(offset['cost_ratio']):.2f}%. Nebius at concurrency 64 gains {pct(stable['throughput_ratio']):.2f}% throughput with an unchanged ${stable['first_price']:.2f} price, lowering token cost {-pct(stable['cost_ratio']):.2f}%. Same declared configuration within each pair; runtime images and listing shapes may change."
    figures.append(dict(number=5,text=text,basis=method,table_rows=[offset,stable],
        joined_rows=[joined(r[k]) for r in (offset,stable) for k in ('first_join_id','last_join_id')]))
    save(output/'FINDING-EVIDENCE.json',figures)
    (output/'FINDINGS.txt').write_text('Five findings; USD and 100% utilization. All prices are public listings, not invoices.\n'
        'Fixed-shape figures use nominal 1,024 input / 1,024 output tokens and the stated precision. No latency/quality gate; provider throughput portability and allocation suitability unverified.\n\n'
        +'\n\n'.join(str(f['number'])+'. '+f['text'] for f in figures)
        +'\n\nEvery operand and joined row is in FINDING-EVIDENCE.json. Full history and all alternative prices remain in costs.sqlite and joined-costs.csv.gz.\n',encoding='utf-8')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--database',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();build(a.database,a.output)
