# Shared operations, retained for the next request

The floor improves by class, not by user. `work.py` supplies one execution and
reuse path for nine existing deterministic operations and two maintainer
operations. `maintainer-observe` explicitly collects a new streamed observation
from a configured endpoint; `maintainer-compare` applies acceptance, latency and
cost policy to retained observations. A different operator or provider uses the
same adapters. Source owners retain their evidence and acceptance rules.

## Maintain an inference implementation with retained observations

The [native maintainer instrument](../compute/maintainer/README.md) compares a
baseline and a candidate against the same explicit workload and measurement
protocol. Second Run executes each selected observation, retains its complete
receipt and raw stream artifacts, and connects those observations to the native
comparison. This path measures the configured endpoints; it does not provision
them or start a serving process.

Configure `compute/maintainer/examples/spec.json`, its workload and its policy for
the two endpoints you operate. Pin the implementation revision, model revision
and hash, tokenizer revision, hardware identity, precision, context, settings and
any implementation files that distinguish the candidate. Then run:

```sh
python -B integration/work.py --request integration/examples/maintainer-work.json --store /your/retained/maintainer --require-maintainer-pass
```

The request contains two `maintainer-observe` tasks and one `maintainer-compare`
task. The comparison's `baseline` and `candidate` fields use `{"task":"ID"}` to
select earlier successful observation tasks from that invocation. They can also
name retained observation result files or native `run.json` receipts. A failed,
held or missing observation holds the dependent comparison while other independent
tasks continue. The original nine operations and retained Research Desk procedure
bindings retain their existing behavior; a Research Desk binding authorizes only
its existing deterministic classes.

| Change | Baseline observation | Candidate observation | Comparison |
|---|---|---|---|
| Empty result store | Collect and retain | Collect and retain | Calculate |
| Same declared inputs and observation epoch | Reuse original | Reuse original | Reuse original |
| Price, acceptance policy or external grade evidence only | Reuse original | Reuse original | Recalculate from retained responses |
| Candidate implementation bytes or selected configuration | Reuse original | Collect and retain changed candidate | Recalculate |
| Shared workload or measurement protocol | Collect and retain | Collect and retain | Recalculate |
| Explicit new observation epoch | Collect and retain | Collect and retain | Recalculate |

Each observation key includes its selected arm's canonical configuration, exact
workload bytes, declared implementation file bytes, collection protocol, producer
modules, adapter, runner and Python runtime. The other arm and the policy file
are excluded from that observation key. The comparison key includes both terminal
receipts, every raw artifact in their closures, the policy and its procedure
bytes. The native instrument preserves observed server/model identity separately
from declared configuration and issues its own comparability verdict.

A reused observation is labelled `retained-observation` and carries its original
`observed_at` and observation ID. `new_observations` and `model_calls` count only
work performed by the current invocation. An executed observation reports the
native instrument's actual HTTP inference request count. `gpu_runs` remains null
for remote observations because an HTTP endpoint does not establish physical GPU
execution. Reuse and deterministic comparison report zero new inference calls.

To explicitly collect another measurement under unchanged declared settings:

```sh
python -B integration/work.py --request integration/examples/maintainer-work.json --store /your/retained/maintainer --fresh --require-maintainer-pass
```

`--fresh` assigns a new observation epoch and writes the complete effective
request to `STORE/requests/` before any inference. The invocation receipt records
`request_record` and `fresh_observation_id`. A chosen ID makes reconnection
explicit: `--fresh experiment-20261118-b` creates that epoch once; repeating the
same ID recovers its existing observation instead of presenting it as new work.
Use a new ID when another measurement is intended. Changing selected dependencies
creates a different observation key even within the same named experiment.

Second Run claims an observation key exclusively before contacting its endpoint.
A concurrent request or interrupted attempt without a terminal result holds and
points to the retained claim and artifact directory. Inspect that attempt before
selecting a new observation epoch. Complete result envelopes publish atomically
without replacing an earlier record. Raw artifacts and terminal receipts are
checksum-verified on every reuse; damage holds the result and its dependent
comparison while preserving the original files.

External application grading stays with the configured grader. For externally
graded workloads, the comparison accepts optional `baseline_grades` and
`candidate_grades` paths. Their native validation pins the exact observation,
workload and response bytes and checks the grader artifact closure. Adding or
changing grading evidence recalculates the comparison, with zero new inference.
Ungraded application outcomes retain the native instrument's unresolved verdict.
When a grader or normalization implementation changes, prepare independently
bound grades for both retained arms under one [explicit grading contract](../compute/maintainer/EVALPLUS-BRIDGE.md#regrade-an-unchanged-capture-with-a-new-pinned-grader).
Add `"grading_contract": "path/to/regrade.json"` and both grade receipt paths
to the `maintainer-compare` task. The contract and grade bytes affect only this
comparison's key. Using one graded arm or incompatible contracts returns the
native incomparable verdict. Keep the collection specification, archived workload
and original analysis with their original identities.

The run-level `executed` or `reused` status describes procedure execution. Read
`native_verdict` and `verdict_receipt` for the maintainer decision. With
`--require-maintainer-pass`, the command exits 0 for pass, 1 for regression, 2 for
incomparable evidence and 3 for instrument error or a held/missing comparison.
Without that flag, the runner retains its established execution-status convention.

The compact maintainer kit contains these two adapters and their native source
closure. `--catalog` marks each adapter's availability; the nine older operations
remain available from a complete Cantos checkout. The integration acceptance
suite uses a labelled local SSE fixture to count actual HTTP requests and prove
no-change reuse, price-only recalculation, candidate-byte invalidation, explicit
fresh collection, artifact-damage refusal and concurrent-epoch exclusion:

```sh
python -B -m unittest discover -s integration/tests -p test_maintainer_work.py -v
```

That suite qualifies the runner and stream protocol. Actual workload/model/hardware
claims belong to the separate native observation receipts and their grading.

## Start from the local record

```powershell
python -B integration/work.py --catalog
```

This prints the task classes, required artifact shapes, adapter coordinates and
execution command. A new process needs the request file and result-store address;
it does not need the earlier conversation. `tasks[].result` in each run receipt
points to the native output. Inspect its limits and unresolved work as well as the
outer `executed` or `reused` status.

On this estate, ongoing results are retained under the project home at
`../sessions/shared-work/`, outside the published checkout. Qualification uses
`<scratch>/Runs/` or `<scratch>/Temp/`. `<scratch>` is a local scratch directory. Scratch qualification is not durable
operating custody. A store is explicitly selected on each invocation; another
operator can keep the same format under their own custody.

From the repository root on this estate:

```powershell
python -B integration/work.py --request integration/examples/work.json --store <scratch>/Runs/shared-work
```

Run it again with the same store. On an empty store, the shipped example executes
six tasks. The second request reuses six checked results. Each invocation prints
its per-task status and writes a new run receipt. Result files contain the native
outputs, dependency hashes and semantic parameters; source files are read only.
The original local qualification used Python 3.13.15 and Node 24.19.0.
The previous public release at f29ee3fd3bfb3a5240fa3280d7f2f4ed6ba7747e
subsequently passed Cantos qualification run 44214791217 with Python 3.12 and
Node 22. The maintainer recipient jobs separately qualify Python 3.10 on Linux
and Python 3.12 on Windows for the exact candidate source. Other
operators can use an appropriate writable result directory on their own machines.

| Task class | Existing owner | Example and retained boundary |
|---|---|---|
| `provider-intake` | Campaign provider staging and target arithmetic | Two staged offers through the same adapter. Quotation, unit, retrieval date and unresolved fields survive. A modeled target is conditional on retained performance, not a provider measurement or verified rental. |
| `benchmark-import` | Campaign offline backfill importer | Five committed InferenceX fixtures: six source rows, 80 observations. Native IDs, provenance and fixture flags survive. Importing does not repeat a benchmark. |
| `run-recompute` | Run 3 recovery, grader join and deadline buckets | Retained A/T0 replay: 8,622 scheduled, 8,622 completed, 4,336 accepted. This rejoins retained EvalPlus results and recomputes acceptance; it does not execute EvalPlus or rent a GPU. |
| `run-diagnose` | Run 3 recovery, grader join and shelf consistency checks, plus static inspection | Same retained arm: the owner's recomputation runs first, then correct-but-late requests are partitioned into dispatch (`send_ts - scheduled_ts`), send-to-first (`first_token_ts - send_ts`), both and combined segments against the same one-second rule, and every delivered solution is classified as correct, syntax-valid but grade-failing, syntax-invalid, or a never-sent placeholder, by dataset and `ast` error family. Nothing generated is executed, sanitized or repaired. Categories are observations of retained bytes, not proof of repairability or of a provider, GPU or client cause. |
| `output-contract` | Retained Run 3 input and native grading layout | Selects candidate substrings for syntax-invalid responses, preserves raw output and baseline grading, and emits separately materializable grader input. Parsing is not correctness; no generated code is executed and no new accepted count is asserted. |
| `source-correction` | Research Desk event and dependency machinery | The shipped synthetic worked-history packet receives an explicitly illustrative correction. Its successor makes affected work stale and preserves historical reports. No human review or standing is granted. |
| `record-change` | Workload runner revalidation | The shipped synthetic workload record gets a price scenario. The owner recalculates economics, leaves performance intact and requires no execution. |
| `tier-plan` | Campaign Tier-Bench bridge and WATERLINE | A supplied Knot plus native evidence summary and ladder produce model/seat plans with source bases, wall clock, costs and missing measurements retained. This is a planning computation, not new model capability evidence or execution authority. |
| `pool-purchase` | Provider staging pool owner (`hot-aisle/campaign/providers/pool.py`) | `examples/pool.json`: five illustrative members against the staged offers. Whole-unit packing (each unit billed until its last member ends, or its stated minimum), a per-unit schedule, exact-decimal charges rounded per unit to cents and split by GPU-hours with largest-remainder cents that sum exactly to the bill, per-member standalone comparison against both the cheapest listed offer and the cheapest offer with no hold, coalition and break-even utilization. Holds on the pool offer and on each reference travel into a labelled conclusion. List-price arithmetic; not a quote, availability check or co-op agreement; `bindable_at_list` and `execution_authority` stay false. |

To diagnose the committed retained arm instead of only recomputing it:

```powershell
python -B integration/work.py --request integration/examples/diagnose.json --store <scratch>/Runs/shared-work
```

Point the same request shape at any other retained arm directory, from any provider,
to obtain the same partition and classes with the same stated limits. The diagnosis of
Hot Aisle baseline 1 (4,274 accepted) reproduced N01's retained figures exactly: 71 late
= 42 send-to-first only, 9 dispatch only, 1 both, 19 combined; 2,437 syntax-invalid and
1,836 syntax-valid grade failures; four never-sent MBPP placeholders excluded from parsing.

The larger local archive has a separate request:

```powershell
python -B integration/work.py --request integration/examples/archive-local.json --store <scratch>/Runs/shared-work
```

That request requires the already-retained `backfill/data-raw` archive, which is
excluded from Git. The local verification processed 100 artifacts, 198 source
rows and 3,620 observations. A clean checkout uses the smaller committed example;
the runner never fetches the missing archive automatically.

## Change an input, preserve what still holds

Tasks use `id`, `task_class` and `source`; source paths are relative to the request
file, or absolute. An optional `actor` labels the request in its execution receipt.
It is descriptive metadata, not authenticated identity or institutional standing.
Changing the task ID, actor or file location while retaining identical bytes does
not change the computation key.

To exercise economic reuse, add this field to the first provider task:

```json
"price_scenario": {"rate_usd_per_gpu_hour": 2.0}
```

With the initial six results retained, this executes one changed calculation and
reuses the other five, including the unchanged 4,336 accepted count. The original
quoted rate, native provider row and previous result file remain intact. Omitting
`offer_id` files the whole supplied staging file; it does not qualify availability.

For a reproducible supply check, add `"availability_review":
{"as_of":"2026-09-27T00:00:00Z","max_age_hours":24}` to a provider-intake task.
The timestamp and caller-selected window enter the computation key. A dated
`available` observation outside that window, an unavailable observation or an
unknown observation produces a placement hold; the conditional price target
remains visible. Without an explicit review, availability age is not assessed
and placement is held. Even an observation within the window is only a listing
snapshot: `rentable_now` remains false until a current offer, account access,
full billing and successful provisioning are checked. The runner does not fetch
a new quote or infer a universal freshness window.

To ingest an explicitly collected Vast.ai Search Offers response, retain its raw
JSON body as a local file and supply that file as `source`. Add
`"marketplace_snapshot": {"source_url":"https://console.vast.ai/api/v0/bundles",
"captured_at":"<timezone-aware capture timestamp>",
"evidence_class":"official_api_response"}`. The separate collection step uses
Vast's documented authenticated POST; `work.py` never contacts the marketplace.
The adapter accepts the documented `offers` array (or the documentation's
single-object example), preserves the raw snapshot hash and exact provider offer
ID, and maps `search.gpuCostPerHour` as USD compute per offer-hour divided by
`num_gpus`. It keeps `storage_cost` in USD/GB/month and the separate bandwidth
USD/TB fields; `search.totalHour` is retained as advertised metadata, not a
qualified bill. Capture time is caller-declared and does not prove a provider
quote or account access. A listing always carries a placement hold and
`rentable_now: false`, including an apparently fresh available listing.

For parser qualification, the official [Search Offers response example](https://docs.vast.ai/api-reference/search/search-offers)
can use `evidence_class: "official_documentation_sample"` with that page as
`source_url`. Its fictional machine, price and advertised availability remain a
sample: availability is unobserved and no modeled target is produced. Neither
source class is an obtained rental or a reservation. The API's Authorization
header is mandatory; the sample cannot substitute for a live response.

The existing record-change owner also accepts `gates`, `requirements`, `traffic`,
`runtime` and `evaluator` changes. Its result distinguishes recalculation,
reassessment of retained outputs and a minimal new execution plan. This runner
returns that plan; execution and authorization remain with the workload runner.
When a change requires execution, the proposed native job now retains simultaneous
price, gate and acceptance-requirement changes, including a requested quality gate.
It contains only the requested cells and clears a historical primary cell when
that cell is absent from the proposed rerun.
Source corrections use a record ID and a bounded patch through Research Desk.
Their event actor identifies this deterministic procedure; the separate run
receipt records the caller label. Reusing a calculation does not create a second
review, author or correction event.

## Why a result may be reused

The key includes task class, semantic arguments, Python/Node runtime versions and
the bytes of every declared input and native procedure, including this runner.
Missing optional retrieval sidecars have an explicit identity; adding one changes
the key. Fresh worker processes load source rather than old bytecode and check
dependencies before and after execution. A cache hit verifies the retained
result checksum and rechecks the current dependencies.

Hash equality identifies the same declared computation. It does not authenticate
the producer, establish source truth, renew an observation date or grant Canon
standing. Reuse is deliberately conservative: changing an unrelated row in a
shared provider file invalidates that file's operations too. This implementation
does not claim field-level dependency precision for every source format.

Byte identity also includes text serialization. The local verification records two
existing CRLF inputs whose Git blobs use LF. Both hashes are retained in its report;
a differently serialized checkout recalculates those operations instead of reusing
the old result. Neither the input files nor the earlier results were rewritten.

Results and invocation receipts are append-only. A damaged cache entry is held
with a reason; it is not silently repaired or overwritten. Missing evidence,
unsupported task classes, misspelled change fields and disagreements between a
retained grading mask and its underlying results hold that task. Other independent
tasks continue. Use a new store to recompute after investigating damaged cache
data; the original remains available for inspection.

An `executed` task can still contain native unresolved fields or applicability
holds. That status means the procedure ran, not that its conclusions were accepted.

## Bring model and seat evidence into the same reuse path

A `tier-plan` task names a retained Knot JSON and a directory produced by the
existing `hot-aisle/campaign/tierbench-bridge/import_tierbench.py`:

```json
{
  "tasks": [{
    "id": "next-estate-plan",
    "task_class": "tier-plan",
    "source": "knot.json",
    "evidence": "tier-evidence"
  }]
}
```

`tier-evidence` must contain native `tierbench-summary.json` and
`tier-ladder.json`. Optional `seats`, `availability` and `local_models` paths
replace the native owners' defaults. Every supplied file and both planners enter
the computation identity. Changing one of those inputs recalculates that plan;
it does not invalidate an independent retained-run recomputation. Missing files
hold the task, and identical evidence copied to a new location can be reused.

The adapter calls the native planner and retains its entire result. The native
`chosen_tier` is an evidence-based model candidate; even `chosen_mode: full`
does not mean its projected wall time meets the deadline. The retained Run 3
example uses a declared analogy to one historical T1 task: its API projection
takes 21,570.5 seconds against a 5,400-second deadline at concurrency one. The
open-weight tier remains unmeasured. These are useful remaining measurement and
placement questions, not an authorized route.

The native result now also contains `plan.placement` and a placement verdict on
each grid row. These join full model-evidence coverage to projected deadline,
budget and evaluator-role constraints. Read `plan.placement.chosen_tier` for the
lowest ladder-ranked modeled-feasible candidate; it may be null while the
historical evidence-only `chosen_tier` remains populated. Unknown cost/time,
partial class coverage and unmeasured fabric timing remain unresolved. Native
refusals and cost bases survive. An API concurrency scenario can change the
projected verdict but does not measure parallel throughput or grant execution
authority. The bridge's `--require-placement` CLI flag supplies a nonzero exit
when a modeled placement is required and none exists. Shared work status still
means the deterministic computation ran, not that placement passed.

`TIER-VERIFICATION.json` records this join using 52 retained Tier-Bench call rows
and nine operator-diagnostic aggregates, excluding synthetic route receipts.
It also records cold execution, reuse by another caller and a changed seat-price
scenario beside the untouched 4,336 accepted requests. Dates and evidence bases
remain historical; this does not run rolling frontier tests or refresh offers.

Live Tier-Bench intake must resolve its current authority before use. During this
join, the resolver's pinned commit and checkout HEAD differed. The already-retained
excerpts remain usable as historical inputs; this adapter does not silently select
another checkout or reclassify those excerpts as current measurements.

## Optional supply-to-placement join

`tier-plan` accepts `supply` with a retained provider JSONL `source`, optional
native `availability_review`, and exact `bindings` keyed by seat ID:

```json
"supply": {
  "source": "live-hotaisle.jsonl",
  "availability_review": {"as_of": "2026-09-27T00:00:00Z", "max_age_hours": 24},
  "bindings": {
    "hotaisle-mi300x-1x-enc1": {
      "provider_id": "hotaisle", "offer_id": "hotaisle-mi300x-1",
      "seat_sku": "vm-mi300x-1x", "seat_gpu": "AMD Instinct MI300X VF",
      "offer_gpu": "MI300X"
    }
  }
}
```

The adapter executes the existing offline provider-intake operation, retaining its
full output and declaring its code, source and reference dependencies. The native
tier owner checks exact IDs, explicit SKU/GPU labels, provider, GPU count, region
and price agreement. Bindings declare correspondence; they do not authenticate
hardware identity. Unknown IDs or mismatches remain held. No matching by display
name or automatic GPU-name normalization occurs.

`plan.supply.seat_reviews` carries native availability reviews and holds. Each grid
row's `supply_eligibility` evaluates the same cheapest-or-fastest candidate used by
modeled placement. `listing_eligible` means only that the declared correspondence,
price and native intake checks pass at the explicit review time.
`modeled_and_listing_eligible` additionally requires modeled feasibility. API,
subscription and unmapped seats remain unassessed by this GPU-offer join. No
alternative seat is selected. Existing `placement` facts and arithmetic are intact.

Even a passing listing leaves `ready`, `reserved` and `execution_authorized` false.
Account access, provisioning, complete billing terms and evaluator readiness are
not established. Without `supply`, existing output is unchanged. Changing source
bytes, review time/window or bindings invalidates this task's reuse; identical
relocated bytes reuse the result. Reuse never fetches or renews an observation.

## Qualification

```powershell
python -B -m unittest discover -s integration/tests -p "test_task_*.py" -v
python -B -m unittest discover -s integration/tests -p "test_work.py" -v
python -B -m unittest discover -s integration/tests -p "test_task_diagnose.py" -v
```

The tests cover cross-operator reuse, relocated evidence, selective price changes,
new retrieval receipts, corrupt caches, missing evidence, inconsistent grading,
native runtime/evaluator revalidation and preserved correction history. They
exercise actual owners, with mutations confined to disposable copies.

The workload owner's unsupported-change no-op was also fixed: an unknown change
now refuses instead of returning an empty set of conclusions. Generated desk and
browser projections carry the same fix.

`WORK-VERIFICATION.json` records the concrete local handoff. Its real retained
evidence and synthetic change examples are identified separately. These operations
make no model calls and run no new GPU work. That establishes reuse of these
deterministic procedures; it does not qualify general task decomposition, batching,
warm placement, unattended provisioning or cross-domain adoption.


## Four-lane local integration, 27 September 2026

The shared catalog now includes run-diagnose and pool-purchase, plus explicit
provider availability review and buyer placement constraints. Original source
owners and evidence classes remain unchanged. Pooling is staged-price arithmetic;
arithmetic_no_worse describes the modeled member comparison only. bindable_at_list
remains false even for an apparently available source row: current supply,
account eligibility, full billing terms, a reservation and purchase authority are
not established by this operation. Historical and synthetic examples remain so.
This integration is a local candidate; it activates no execution or publication.

## Second four-lane integration

The output-contract candidate has a separate task and materializer:
`python -B integration/work.py --request integration/examples/contract.json --store <store>`.
`python -B integration/task_contract.py materialize <result.json> <arm> <new-directory>`
retains source mapping and candidate lineage in the existing grader-input layout. It
performs no grading; original acceptance and deadlines remain unchanged. Some retained
candidates are partial or comment-only, so syntax improvement never means useful completion.

Provider intake also accepts explicit retained Vast Search Offers snapshots. Collection
is separate and the documentation sample remains fictional: no available capacity or
modeled price target follows from it. A tier-plan supply argument can pass the same
marketplace_snapshot descriptor to that native intake; it preserves every hold and
requires explicit seat/offer bindings before any listing-eligibility conclusion.

Pool charges now release each modeled unit at its own last completion, reconcile integer
cents across member shares, and preserve standalone-reference qualifications. Per-unit
rounding differences are reported separately from usage and idle charges. Status words
in pool conclusions concern arithmetic qualifications, never verified capacity or approval.
This remains a locally qualified candidate, without production activation or a rental.

## Controller reconciliation, 28 September 2026 UTC

Two local Round 2 candidates carried complementary controller repairs. The current r2-integration preserves per-unit rounding separately from idle cost and also inherits the earlier candidate-export checksum/dependency checks and conditional/modeled_no_worse labels. Both original candidate refs and their observations remain historical. Export verifies the current computation before writing grader input; candidate parsing remains distinct from correctness and deadlines.

## Supply qualification shared by intake, pooling and placement

`pool-purchase` now consumes its `offers` through the existing provider-intake operation. Optional `availability_review` and `marketplace_snapshot` arguments have exactly the intake semantics above. All native source dependencies and review parameters enter the pool computation key. Supply holds bind to exact unique offer IDs and reach both pooled-offer and standalone-reference comparisons. `standalone_unqualified` means no holds under this declared review, not authenticated or reserved supply. The direct `pool.py` CLI remains a list-arithmetic interface without intake review; use `work.py` for the joined path.

Malformed, absent or future availability timestamps are per-offer `invalid_observation` holds retaining the original row and exact error. A defect in one availability observation no longer stops inspection of other offers. Request-time syntax, monetary units, duplicate identities and structural validation remain strict. These changes neither move a future date into the present nor infer that a timestamp denotes a forward reservation. Fictional documentation snapshots remain inspectable in the intake and are excluded from pool price arithmetic.

Qualification exercised the complete retained catalog and a linked five-task request: intake, pool, placement, independent benchmark import, and the new 4,274-accepted baseline recomputation. A fresh process reused all five. Explicitly synthetic availability and price interventions changed the same source for intake/pool/placement, recalculated those three tasks and reused the two independent results. All three consumers returned identical native intake values. Availability changed listing eligibility; changing the offer price changed the standalone comparison and caused the planner to demand explicit repricing, preserving its original model arithmetic. No reservation or performance improvement followed from either intervention.

Native regression: `python -B integration/tests/test_task_pool_supply.py -v`. Retained request files and controller assertions live in the project session's `continuation-20260928/pool-supply/linked-verification/`. Use a separate store for a new cold run. This is local software qualification over historical material and labeled scenarios, with zero inference, purchase or deployment.

## Retained judgment procedure handoff

A request can select a specific claim or conclusion in an existing Research Desk
packet instead of reconstructing its native task arguments:

```json
{"tasks":[{"id":"this-invocation","from_record":{
  "source":"workspace.json","record_id":"assess-retained-offer","revision":2
}}]}
```

The record's `data.work` contains exactly `task` and `computation_key`. `task` is
one of the nine existing deterministic operations, without caller `id` or `actor`.
The key comes from that exact native operation's description or completed result;
it pins declared input bytes, procedure code, semantic parameters and runtime.
The record's summary/rationale and native dependency pins retain why this is the
chosen operation. A caller explicitly selecting a draft record permits only the
existing local investigation, not an accepted review or an external action.

The existing `change_owner.cjs` bridge loads the unchanged ResearchCore owner that
the packet declares (`research_owner.py`: a 1.0.0 journal keeps the script embedded in
`research-desk/app.html`, so earlier identities are unchanged; a 1.0.1 or 1.0.2 journal
is read by `app/source/research-core.js`, which replays all three). The chosen owner's
bytes are pinned before and after resolution. The bridge then
verifies the original packet by native replay, checks the requested current
revision and dependency closure, and retains the native review state. It creates
no review event. A blocked or superseded judgment stops that task; unrelated tasks
continue. No shelf card, narrative source, arbitrary shell command or nested
record reference becomes an executable task through this entry.

The worker checks the declared native computation key before executing or reading
its cache. It checks the Research Desk packet and reader again after completion.
The invocation retains the exact judgment, rationale, source packet hash, native
dependency verdict and review state alongside the normal result. The calculation
identity remains owned by its existing operation: the same task invoked directly
or through a valid judgment reuses the same native result.

Relative task paths inside a record resolve beside its packet. Optional caller
`inputs` can relocate existing path arguments (`source`, `evidence`, `seats`,
`availability`, `local_models`, `offers`); identical bytes still need the same
computation key. This is not permission to change the task's meaning. Missing
files, changed input bytes, changed procedure/runtime, stale record pins or a
superseded target stop use of that binding. New inputs require an explicit
successor judgment and newly described native computation. No automatic repinning
or class-general capability inference is implemented.

Numbers in a retained task are compared as the journal keeps them: a JSON journal
stores `2.0` as `2`, and the Python identity treats `2.0` and `2` as different declared
computations. A key computed from `2.0` therefore does not bind to the retained task,
and the request is held (`test_task_research_handoff_102.py`). Write scenario numbers
in the record as JSON keeps them.

Native qualification runs three council-linked operations: retained provider
intake, diagnosis of historical A/T0 and imported benchmark artifacts. A fresh
process reuses all three. A controller exit after the first completed operation
leaves its result usable; restart reuses that result and performs the remaining
two. An explicitly synthetic source correction blocks only the dependent judgment
while the other two procedures reuse their results. This tests process loss
between operations, not failure during a write or an external transaction.

Research Desk remains byte-identical. The packets contain draft candidate
judgments and no fabricated accepted reviews. This new request entry does not
implement natural-language intent matching, cloud execution or autonomous
judgment renewal. `python -B -m unittest discover -s integration/tests -p
"test_task_research_handoff.py" -v` covers the new native handoff and stale-source
boundary. Expanded mutation/relocation test writing was refused; those additional
assertions were not executed and no alternate write mechanism was used.
