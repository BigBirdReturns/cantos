"""Cantos maintainer instrument."""
