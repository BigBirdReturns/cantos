# Chapek seat record: the executable handover

This folder is the whole handover. Nothing in it needs the preparer's machine. It is published as a zip linked from the page at https://bigbirdreturns.github.io/cantos/compute/chapek/ (the link is on the first screen, under "What you can do next").

- `Cantos-Chapek-Seat.html`: the page. Open it in any current browser, offline. It shows the recommendation in use, what changed since it was written, the native work already performed, what is still open and what to do next. It executes only the record rules and the pricing engine embedded in it; it never runs the native procedures.
- `Cantos-Chapek-Seat.packet.json`: the same record as a file (hash in `MANIFEST.json`).
- `inputs/`: the exact bytes the retained procedures were computed from (Chapek's list-price rows; the synthetic workload record, which says it is synthetic).
- `requests/`: the runs that produced the retained work, the saved refusal (`06-from-record.json`), the rebinding run after the runner repair (`08-rebind-after-repair.json`), the next action (`07-next-from-package.json`) and a request that selects every retained procedure through its record (`09-verify-all-procedures.json`).
- `store/`: the runner's append-only results and receipts, including the bindings that the repair superseded.
- `next.py`: the entry point. `MANIFEST.json`: every file's SHA-256, the download URL, and the exact runner bytes this package was qualified against.

## Run the next action

You need Python 3.12+ and Node 22+, and a checkout of the Cantos repository (`https://github.com/BigBirdReturns/cantos.git`) whose five runner files hash as `MANIFEST.json` lists. They were last changed at the commit `MANIFEST.json` names as `runner_last_changed` and are unchanged through the commit it names as `commit`.

```bash
python next.py --checkout /path/to/cantos --store store
python next.py --checkout /path/to/cantos --request requests/09-verify-all-procedures.json
```

The first runs four tasks: the declared re-pricing task; the same task selected through its record (packet checksum, record revision, dependency state and expected key are checked before and after); the Run 3 recomputation selected through its record with its source resolved against the checkout; and the model-change revalidation selected through its record. The second selects all eight retained procedures through their records. Use `--store fresh` to recompute instead of reuse, and `--dry-run` to see the resolved request first.

## What the runner will refuse, and why that is right

A changed byte in an input changes the key, so the runner recomputes instead of reusing. A corrupt retained result is held, not repaired. A record that was tampered with, a superseded revision, or a procedure whose inputs have a later version is refused by the judgment handoff with its reason. A later change to the runner's own files changes the keys of the operations they take part in: direct requests recompute, and record-bound requests are held with "binding differs" until a successor binding is appended, which is exactly what this record did after the runner repair (see the three procedures with a `previous_binding`). None of these is a bug to work around; each is the record protecting the next reader.

## What this is not

List prices, not quotes. A synthetic workload, not a measurement. Nothing here measures a Chapek node, qualifies a customer, authenticates a tenant or authorizes an external action. The recommendation in the record, and whether to accept Chapek's twelve-month term at all, are deliberately left for the next reader to decide.
