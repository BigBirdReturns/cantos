#!/usr/bin/env python3
"""Run the next supported action from this delivered package.

Usage:  python next.py --checkout <path to a Cantos checkout whose runner files hash as MANIFEST.json lists>
                       [--store store] [--request requests/07-next-from-package.json] [--dry-run]
        python next.py --checkout <checkout> --request requests/09-verify-all-procedures.json   # every retained procedure

What it does, and only this:
  1. checks that the record (Cantos-Chapek-Seat.packet.json) hashes as MANIFEST.json says;
  2. checks that the checkout carries integration/work.py and the judgment-handoff owner selector;
  3. resolves the one checkout-relative input (the Run 3 arm) by replacing "<checkout>/" in the request;
  4. writes the resolved request beside the others and calls the checkout's integration/work.py.
It calls no model, rents nothing and contacts nobody. Reuse means an identical declared computation,
not source truth, availability or acceptance. Standard library only.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding='utf-8', errors='replace')
        except (AttributeError, ValueError):
            pass
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--checkout', required=True, help='Cantos checkout whose runner files hash as MANIFEST.json lists (see its prerequisites)')
    ap.add_argument('--store', default='store', help='result store (default: the delivered store; a new folder recomputes)')
    ap.add_argument('--request', default='requests/07-next-from-package.json')
    ap.add_argument('--dry-run', action='store_true', help='write the resolved request and print the command without running it')
    args = ap.parse_args()

    manifest = json.loads((HERE / 'MANIFEST.json').read_text(encoding='utf-8'))
    record = HERE / 'Cantos-Chapek-Seat.packet.json'
    listed = manifest['files'].get('Cantos-Chapek-Seat.packet.json', {}).get('sha256')
    if sha256(record) != listed:
        sys.exit('The record file does not hash as MANIFEST.json says; do not run against an altered record.')
    packet = json.loads(record.read_text(encoding='utf-8'))
    if packet.get('sha256') != manifest['record_sha256']:
        sys.exit('The record envelope does not carry the workspace checksum MANIFEST.json names.')

    checkout = Path(args.checkout).resolve()
    runner = checkout / 'integration' / 'work.py'
    selector = checkout / 'integration' / 'research_owner.py'
    if not runner.is_file():
        sys.exit('No integration/work.py under ' + str(checkout))
    if not selector.is_file():
        sys.exit('This checkout predates the judgment-handoff repair (integration/research_owner.py); use commit '
                 + manifest['checkout']['commit'] + ' or later.')
    pins = manifest['checkout']['pins']
    drift = {name: p for name, p in (('work', runner), ('research_owner', selector),
             ('change_owner', checkout / 'integration' / 'change_owner.cjs'),
             ('research_handoff', checkout / 'integration' / 'research_handoff.py'))
             if sha256(p) != pins[name]}
    if drift:
        print('Note: these runner files differ from the bytes this package was qualified against: '
              + ', '.join(sorted(drift)) + ' (qualified at commit ' + manifest['checkout'].get('runner_last_changed', manifest['checkout']['commit'])
              + '). Where their bytes enter a computation key, direct requests are recomputed and record-bound '
              'requests are held with "binding differs" until a successor binding is appended to the record. '
              'That hold is the record protecting you, not an error to bypass.')

    request_path = (HERE / args.request).resolve()
    request = json.loads(request_path.read_text(encoding='utf-8'))
    resolved = json.loads(json.dumps(request).replace('<checkout>/', checkout.as_posix().rstrip('/') + '/'))
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    out = request_path.with_name(request_path.stem + '.resolved-' + stamp + '.json')
    out.write_text(json.dumps(resolved, indent=2) + '\n', encoding='utf-8')
    store = (HERE / args.store).resolve()
    cmd = [sys.executable, '-B', str(runner), '--request', str(out), '--store', str(store)]
    print('Resolved request: ' + str(out))
    print('Command: ' + ' '.join(cmd))
    if args.dry_run:
        return 0
    completed = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8')
    sys.stdout.write(completed.stdout)
    if completed.stderr.strip():
        sys.stderr.write(completed.stderr)
    try:
        receipt = json.loads(completed.stdout)
        print('Summary: ' + json.dumps(receipt['summary']) + ' · receipt ' + receipt['receipt'])
        for task in receipt['tasks']:
            line = '  ' + task['id'] + ': ' + task['status']
            if task['status'] == 'held':
                line += ' · ' + task['reason']
            else:
                line += ' · key ' + task['key'][:12] + '… · result ' + task['value_sha256'][:12] + '…'
                if 'knowledge' in task:
                    k = task['knowledge']
                    line += ' · record ' + k['record']['id'] + ' r' + str(k['record']['revision']) + ' via ' + k['research_core_path']
            print(line)
    except (ValueError, KeyError):
        pass
    return completed.returncode


if __name__ == '__main__':
    raise SystemExit(main())
