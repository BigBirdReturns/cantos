# Source-bound EvalPlus grading

The bridge accepts a retained maintainer run, the exact fixed reference file, and a trusted normalizer whose SHA256 appears in every case's grader identity. `prepare` emits one solution for every observation, including transport failures. It never runs generated solutions. For this experiment the normalizer unwraps one whole-response Python fence or returns the raw response unchanged; it never repairs code. Both EvalPlus base and plus checks must pass, and a failed stream stays rejected even if its partial text happens to pass tests.

```
python3 -B evalplus_bridge.py prepare --instrument source --run vllm-capture/baseline/run.json --reference humaneval-reference.jsonl --normalizer normalize.py --out grade-baseline-prepared
```

Run the existing pinned image, with an absolute writable prepared directory mounted at `/work`. `UID` and `GID` below mean the numeric current user's identity. The root filesystem is read-only, the container has no network, capabilities are dropped, no-new-privileges is set, and generated Python executes only inside this bounded container. Preserve stdout/stderr as `evalplus.log` and record the command and exit status. Use a distinct container name per arm.

```
docker run --rm --name cantos-evalplus-baseline-20261118 \
  --network none --read-only --cap-drop ALL --security-opt no-new-privileges \
  --pids-limit 512 --memory 8g --cpus 4 --user UID:GID \
  --tmpfs /tmp:rw,exec,size=2g -e HOME=/tmp -e XDG_CACHE_HOME=/tmp/cache \
  -e HUMANEVAL_OVERRIDE_PATH=/work/humaneval-reference.jsonl \
  -v ABSOLUTE_PREPARED_DIR:/work -w /work --entrypoint /bin/sh \
  sha256:803e956852925ff35f8d7a9f55a97fbcfad09a8dfa77a439f5b2ac537702563d \
  -ec 'python -c '\''import importlib.metadata as m; assert m.version("evalplus")=="0.3.1"'\''; evalplus.evaluate --dataset humaneval --samples humaneval.jsonl --parallel 4 --min-time-limit 1 --gt-time-limit-factor 4'
```

```
python3 -B evalplus_bridge.py bind --instrument source --run vllm-capture/baseline/run.json --prepared grade-baseline-prepared --results grade-baseline-prepared/humaneval_eval_results.json --log grade-baseline-prepared/evalplus.log --out grade-baseline
python3 -B source/maintainer.py analyze --baseline vllm-capture/baseline/run.json --candidate vllm-capture/candidate/run.json --baseline-grades grade-baseline/grades.json --candidate-grades grade-candidate/grades.json --policy policy-vllm.json --out vllm-graded-analysis
```

Repeat prepare/container/bind for the candidate. Binding verifies the retained run and workload hashes, each raw response SHA, the normalizer and reference hashes, evaluator reference MD5, exact normalized solution strings, complete per-task result coverage and trial/repetition identities. It copies the grading inputs, mapping, full evaluator output, log, source run and bridge into the receipt's hash closure. Missing grades, incomplete coverage, changed responses or mismatched solutions raise errors rather than assigning acceptance. The raw streaming run and its own evidence closure remain the primary observation record. This task selected 32 fixed evenly spaced HumanEval+ cases before capture; that selection supports a scoped comparison rather than a full 164-case score.

The bridge currently supports single-step HumanEval tasks and rejects multi-step cases explicitly. Its criterion is fixed to `humanevalplus-v0.1.10-base-and-plus-chat-complete-code-v1` and the pinned EvalPlus 0.3.1 image above. `--instrument source` selects the frozen maintainer source in this session; in the public layout the bridge defaults to its sibling maintainer package. Both prepare and bind invoke that instrument's full raw-stream receipt validator, pin its Python source files, and bind recomputes normalization directly from every exact retained response. Reference MD5 is recomputed from the pinned bytes and the copied workload is verified again before binding.
