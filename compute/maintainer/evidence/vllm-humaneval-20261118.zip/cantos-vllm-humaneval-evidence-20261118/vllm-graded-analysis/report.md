# Cantos maintainer verdict

**INCOMPARABLE**

- baseline acceptance is insufficient to establish a usable reference
- candidate acceptance falls below requirement

| Metric | Baseline | Candidate |
| --- | ---: | ---: |
| total_tasks | 96 | 96 |
| accepted_tasks | 21 | 21 |
| acceptance_rate | 0.21875 | 0.21875 |
| p95_latency_s | 6.493971993913874 | 6.359379586996511 |
| p95_ttft_s | 0.12201439891941845 | 0.12477405113168061 |
| accepted_per_s | 0.20309334417508806 | 0.19801036570765806 |
| peak_request_concurrency | 4 | 4 |
| cost_per_accepted | 0.0 | 0.0 |

## Evidence scope

- This verdict covers the supplied workload, serving endpoints and policy only.
- Declared weights, hardware, tokenizer and server flags are operator declarations; HTTP probes do not attest them.
- Repeated cases are correlated. Trial ranges describe variation and are not a population confidence guarantee.
- TTFT measures first visible content at the client, including network and queueing; content chunks are not tokens.
- Token counts come from server usage. The instrument does not manufacture per-token timings, power or GPU run counts.
- No request retries. Transport and incomplete stream failures are retained and force an error verdict.
- Server cache state, co-tenancy, thermals and load require operator controls and declared identity settings.
