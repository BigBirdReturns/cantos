"""Verify portable empirical evidence and reanalyze without inference."""
import hashlib,json,pathlib,subprocess,sys,tempfile
root=pathlib.Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text())
seen=set()
for entry in manifest['files']:
 rel=pathlib.PurePosixPath(entry['path'])
 if rel.is_absolute() or '..' in rel.parts or str(rel) in seen:raise ValueError('unsafe or duplicate manifest path')
 seen.add(str(rel));p=root/rel
 if not p.is_file() or p.stat().st_size!=entry['bytes'] or hashlib.sha256(p.read_bytes()).hexdigest()!=entry['sha256']:raise ValueError('artifact mismatch: '+str(rel))
sys.path.insert(0,str(root/'analyzer'))
from maintainer import validate_receipt
for name in ('vllm-capture/baseline/run.json','vllm-capture/candidate/run.json','vllm-offline-candidate/run.json'):validate_receipt(root/name)
for arm in ('baseline','candidate'):
 g=json.loads((root/('grade-'+arm)/'grades.json').read_text())
 assert len(g['results'])==96 and sum(x['accepted'] for x in g['results'])==21
with tempfile.TemporaryDirectory(prefix='cantos-empirical-reanalysis-') as tmp:
 out=pathlib.Path(tmp)/'analysis'
 cmd=[sys.executable,'-B',str(root/'analyzer/maintainer.py'),'analyze','--baseline',str(root/'vllm-capture/baseline/run.json'),'--candidate',str(root/'vllm-capture/candidate/run.json'),'--baseline-grades',str(root/'grade-baseline/grades.json'),'--candidate-grades',str(root/'grade-candidate/grades.json'),'--policy',str(root/'policy-vllm.json'),'--out',str(out)]
 r=subprocess.run(cmd,check=False)
 assert r.returncode==2,'original policy must reject insufficient acceptance'
 report=(out/'report.md').read_text()
 assert '| cost_per_accepted | unpriced | unpriced |' in report
 print(json.dumps({'status':'verified','files':len(seen),'baseline_accepted':21,'candidate_accepted':21,'observations_per_arm':96,'verdict':'incomparable','price_status':'unpriced','inference_requests_executed_by_verifier':0}))
