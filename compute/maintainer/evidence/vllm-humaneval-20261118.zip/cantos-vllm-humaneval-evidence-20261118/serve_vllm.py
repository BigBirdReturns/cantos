"""Own finite vLLM service pair under the installed W03 TierDesk resource class."""
import fcntl,hashlib,json,os,pathlib,signal,socket,subprocess,threading,time,urllib.request
ROOT=pathlib.Path('/mnt/w03data/Incoming/DataArray/Projects/Products/Cantos/sessions/maintainer-empirical-20261118')
OUT=ROOT/'vllm-serving'
REG=pathlib.Path('/home/jonathan/.local/state/tierdesk/gpu-reservations.json')
UUID='GPU-64559d3d-dd59-05ac-1531-88ac32ddc58b'
OWNER='cantos-maintainer-vllm-20261118a'
MODEL=pathlib.Path('/srv/w03/scratch/vllm-independent-20261116/model')
PYTHON='/srv/w03/scratch/vllm-independent-20261116/.venv/bin/python'
MAX_SECONDS=2000
stop=threading.Event();processes=[];claimed=False
state={'schema':'cantos.empirical.serving/1','owner':OWNER,'status':'preflight','started_epoch':time.time(),
       'gpu_uuid':UUID,'thermal_stop_c':80,'max_seconds':MAX_SECONDS,
       'design':'Same GPU, same model, both endpoints resident; baseline prefix caching disabled, candidate enabled. Matched arm trials alternate active endpoint.',
       'energy_scope':'GPU0 board power telemetry only, includes both resident server copies; excludes CPU, facility and unrelated GPU1.'}
def sha(p):
 h=hashlib.sha256()
 with pathlib.Path(p).open('rb') as f:
  for b in iter(lambda:f.read(8<<20),b''):h.update(b)
 return h.hexdigest()
def save():
 p=OUT/'status.json';t=p.with_suffix('.tmp');t.write_text(json.dumps(state,indent=2,sort_keys=True)+'\n');t.replace(p)
def gpu():
 x=subprocess.check_output(['nvidia-smi','--id='+UUID,'--query-gpu=uuid,power.draw,memory.used,utilization.gpu,temperature.gpu,power.limit','--format=csv,noheader,nounits'],text=True,timeout=8).strip().split(',')
 assert x[0].strip()==UUID
 return {'epoch':time.time(),'monotonic_s':time.monotonic(),'uuid':UUID,'watts':float(x[1]),'memory_mib':float(x[2]),'util_pct':float(x[3]),'temperature_c':float(x[4]),'power_limit_w':float(x[5])}
def lease(action):
 global claimed
 with REG.with_suffix('.lock').open('a') as f:
  fcntl.flock(f,fcntl.LOCK_EX);d=json.loads(REG.read_text()) if REG.exists() else {}
  if action=='claim':
   if float(d.get(UUID,{}).get('expires_epoch',0))>time.time():raise RuntimeError('active foreign GPU lease')
   g=gpu()
   if g['memory_mib']>512 or g['util_pct']>5 or g['temperature_c']>=65:raise RuntimeError('GPU not idle/cool')
   d[UUID]={'owner':OWNER,'reason':'Finite vLLM source-bound HumanEval cache comparison','claimed_epoch':time.time(),'expires_epoch':time.time()+MAX_SECONDS+60};state['admission']=g
  elif d.get(UUID,{}).get('owner')==OWNER:d.pop(UUID)
  t=REG.with_name(OWNER+'-lease.tmp');t.write_text(json.dumps(d,indent=2)+'\n');t.replace(REG)
  if action=='claim':
   assert json.loads(REG.read_text()).get(UUID,{}).get('owner')==OWNER;claimed=True
def meter():
 with (OUT/'board-samples.jsonl').open('a',buffering=1) as f:
  while not stop.is_set():
   try:
    s=gpu();f.write(json.dumps(s,sort_keys=True)+'\n')
    if s['temperature_c']>=80:state['stop_reason']='thermal threshold';stop.set()
    if json.loads(REG.read_text()).get(UUID,{}).get('owner')!=OWNER:state['stop_reason']='GPU lease changed';stop.set()
   except Exception as e:state['stop_reason']='telemetry or lease failure '+repr(e);stop.set()
   stop.wait(.5)
def get(port,path):
 with urllib.request.urlopen(f'http://127.0.0.1:{port}{path}',timeout=3) as r:return r.read()
def main():
 OUT.mkdir(exist_ok=False);save()
 try:
  for port in (19581,19582):
   with socket.socket() as s:s.bind(('127.0.0.1',port))
  state['model_sha256']=sha(MODEL/'model.safetensors')
  if state['model_sha256']!='f47f71177f32bcd101b7573ec9171e6a57f4f4d31148d38e382306f42996874b':raise RuntimeError('model hash mismatch')
  state['model_files']=[{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(MODEL.iterdir()) if p.is_file() and p.name!='model.safetensors']
  state['cgroup']=pathlib.Path('/proc/self/cgroup').read_text()
  state['runtime_versions']=subprocess.check_output([PYTHON,'-c','import json,platform,importlib.metadata as m; print(json.dumps({"python":platform.python_version(),"vllm":m.version("vllm"),"torch":m.version("torch")}))'],text=True).strip()
  lease('claim');threading.Thread(target=meter,daemon=True).start()
  env={**os.environ,'CUDA_VISIBLE_DEVICES':UUID,'VLLM_WORKER_MULTIPROC_METHOD':'spawn','PYTHONUNBUFFERED':'1','OMP_NUM_THREADS':'2','MKL_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'1','NUMEXPR_NUM_THREADS':'1'}
  for arm,cache,port in [('baseline',False,19581),('candidate',True,19582)]:
   cmd=[PYTHON,'-m','vllm.entrypoints.openai.api_server','--model',str(MODEL),'--served-model-name','qwen3-06b','--host','127.0.0.1','--port',str(port),'--dtype','float16','--max-model-len','4096','--enforce-eager','--gpu-memory-utilization','0.2','--max-num-seqs','4','--enable-prefix-caching' if cache else '--disable-prefix-caching']
   log=(OUT/(arm+'-server.log')).open('wb');p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True);processes.append((arm,port,p))
   state[arm]={'pid':p.pid,'command':cmd,'port':port,'prefix_cache':cache};state['status']='starting-'+arm;save();deadline=time.monotonic()+240
   while time.monotonic()<deadline and not stop.is_set():
    if p.poll() is not None:raise RuntimeError(arm+' startup exit '+str(p.returncode))
    try:
     get(port,'/health');(OUT/(arm+'-models.json')).write_bytes(get(port,'/v1/models'));break
    except Exception:pass
    stop.wait(2)
   else:raise RuntimeError(arm+' health deadline or resource stop')
  state['status']='ready';state['ready_epoch']=time.time();save();print('READY',json.dumps(state),flush=True)
  while not stop.wait(1):
   if (ROOT/'STOP-VLLM').exists():state['stop_reason']='requested owned cleanup';break
   if time.time()-state['started_epoch']>=MAX_SECONDS:state['stop_reason']='finite deadline';break
   if any(p.poll() is not None for _,_,p in processes):raise RuntimeError('owned service exited')
  state['status']='stopped'
 except Exception as e:state.update(status='failed',error=repr(e));print('FAIL',repr(e),flush=True)
 finally:
  stop.set()
  for arm,port,p in processes:
   try:(OUT/(arm+'-metrics-final.txt')).write_bytes(get(port,'/metrics'))
   except Exception:pass
   if p.poll() is None:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=12)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
   state[arm]['exit_code']=p.poll()
  if claimed:lease('release')
  state['terminal_epoch']=time.time();state['final_gpu']=gpu();save();print('TERMINAL',json.dumps(state),flush=True)
 return int(state['status']=='failed')
if __name__=='__main__':
 for sig in (signal.SIGTERM,signal.SIGINT):signal.signal(sig,lambda *_:stop.set())
 raise SystemExit(main())

