# Cantos maintainer verdict

**INCOMPARABLE**

- external application outcomes remain ungraded
- baseline acceptance is insufficient to establish a usable reference
- unmeasured paired trial metric: p95_latency_s
- unmeasured paired trial metric: p95_ttft_s
- unmeasured paired trial metric: accepted_per_s
- candidate acceptance falls below requirement

| Metric | Baseline | Candidate |
| --- | ---: | ---: |
| total_tasks | 96 | 96 |
| accepted_tasks | 0 | 0 |
| acceptance_rate | 0.0 | 0.0 |
| p95_latency_s | None | None |
| p95_ttft_s | None | None |
| accepted_per_s | 0.0 | 0.0 |
| peak_request_concurrency | 4 | 4 |
| cost_per_accepted | None | None |

## Evidence scope

- This verdict covers the supplied workload, serving endpoints and policy only.
- Declared weights, hardware, tokenizer and server flags are operator declarations; HTTP probes do not attest them.
- Repeated cases are correlated. Trial ranges describe variation and are not a population confidence guarantee.
- TTFT measures first visible content at the client, including network and queueing; content chunks are not tokens.
- Token counts come from server usage. The instrument does not manufacture per-token timings, power or GPU run counts.
- No request retries. Transport and incomplete stream failures are retained and force an error verdict.
- Server cache state, co-tenancy, thermals and load require operator controls and declared identity settings.
