# Qwen3-Coder 30B operating-envelope failure

Both sustained serving attempts reached the experiment's unchanged 80°C guard before completing the planned paired comparison. Each completed its first baseline pass across all 32 predetermined HumanEval tasks. The pinned EvalPlus oracle accepted 31/32 responses in each completed baseline pass. The partial candidate samples accepted 17/18 and 9/9 respectively; the thermal stop censored those samples, so their fractions do not estimate full-workload acceptance. Neither attempt produced a complete native run receipt or a qualified serving recommendation.

| Observed property | GPU1 attempt | GPU0 attempt |
| --- | --- | --- |
| Existing power cap | 260 W | 200 W |
| Admission temperature | 44°C | 47°C |
| Recorded peak temperature | 80°C | 80°C |
| Maximum telemetry sampling gap | 0.8159624762 s | 0.5612744899 s |
| Persisted baseline observations / retained streams | 32 / 32 | 32 / 32 |
| Persisted candidate observations / retained streams | 18 / 19 | 9 / 9 |
| Accepted baseline responses | 31/32 | 31/32 |
| Accepted candidate responses, censored subset | 17/18 | 9/9 |
| Collector terminal code | -15, terminated by owned guard | -15, terminated by owned guard |

GPU1 is `GPU-c3b25970-4ab3-f2ae-5157-1598a46fc778`; GPU0 is `GPU-64559d3d-dd59-05ac-1531-88ac32ddc58b`. Both are Quadro RTX 8000 devices. The existing power caps and installed W03 TierDesk class, 16 GiB memory, 200% CPU and 128 tasks, remained unchanged. Temperature between retained samples is unknown. Shared host conditions and the different devices/caps prevent interpreting these attempts as a controlled causal comparison of power limits.

## Fixed workload, source and protocol

The selection rule preceded generation: numerically sort all 164 HumanEval tasks and choose indices `floor(i*164/32)` for `i=0..31`. The selection manifest, exact prompts and selected HumanEvalPlus v0.1.10 reference are included. Each attempt planned three paired trials, one repetition, client concurrency 4, seed 1729, temperature 0, max_tokens 1024 and timeout 120 seconds. Baseline offered one serving slot; candidate offered four, with 4,096 context per slot. Both endpoint copies occupied the same selected GPU, prompt cache was disabled, and all other declared settings matched. The original 80% acceptance floor and minimum three trials remain in `policy-llama.json`.

The model was the already owned Qwen3-Coder-30B-A3B-Instruct Q4_K_M GGUF, 18,556,689,568 bytes, SHA256 `fadc3e5f8d42bf7e894a785b05082e47daee4df26680389817e2093056f088ad`. The clean llama.cpp source commit was `a518119d30cade6260f7494120863428a3fe8ee5`, archived with SHA256 `427412b86e185a5c7489a11fce96b0366211adbde83422e9b6d16740cc60e209`. The isolated build used CUDA 13.4, GNU 15.2, target sm75 and CMake 4.1.3. The initial build compiled the CUDA/model libraries and then failed optional embedded UI asset validation. The documented API-only configuration, `LLAMA_USE_PREBUILT_UI=OFF` and `LLAMA_BUILD_UI=OFF`, completed successfully. The binary and each loaded runtime library are hash-pinned in the serving receipts; source, build and runtime identities remain distinct.

The 0.6B vLLM comparison used different model precision, runtime and generation limits. These 30B partial outcomes therefore support their own application and operating observations, not a controlled performance or acceptance improvement claim over that separate experiment.

## Completed-response grading and missing observations

`partial-grade-prepared/grades.json` uses the distinct schema `cantos.empirical.partial-grades/1`. It grades all 91 persisted completed observation rows, preserving each row's original task, arm, trial, raw stream hash, response hash, normalizer and exact prepared solution. The checker re-parses the retained SSE bytes and joins those exact solutions to the EvalPlus result. Acceptance requires a valid completed capture and both base and plus tests passing. The container image is pinned to `sha256:803e956852925ff35f8d7a9f55a97fbcfad09a8dfa77a439f5b2ac537702563d`, with EvalPlus 0.3.1, no network, read-only root, dropped capabilities, no new privileges, 8 GiB memory, four CPUs and the retained minimum/factor time limits. The prior exact-reference canonical canary passed all 32 solutions; its evidence is included.

The extra GPU1 candidate stream has no corresponding persisted observation row. It remains in the archive and is explicitly ungraded. Retained streams establish at least 92 actual HTTP response records; termination can leave additional in-flight requests without durable records. The total number of initiated requests is therefore unknown. Planned requests, missing completions and missing trials carry no invented outcomes. No `run.json` was synthesized and the incomplete observations were never passed off as a completed maintainer comparison.

## Guard and cleanup

`STRONG-OPERATING-ENVELOPE.json` records exact admission, capture, first guard and terminal times, sample counts, maximum gaps, source pins and partial counts. `strong-cleanup-proof.json` independently checks that all six owned PIDs were absent, all four owned loopback ports refused connections, and neither lease remained. The observed devices were idle afterward with their original caps. The first outer wrapper exited 0 after its guard stop; its explicit thermal reason and terminated collector determine its failed operating outcome. The GPU0 wrapper correctly propagated exit 3. No foreign jobs or settings were modified.

The raw board samples retain power observations but this export makes no facility-energy, full-cost or cost-per-accepted-work claim. Prices remain unknown. A new sustained test requires a consequential changed operating condition and an explicit new protocol; the current evidence ends at these two guarded failures.

## Offline verification and source boundaries

Run `python3 -B verify.py` from the extracted directory. It checks every file against the manifest, re-parses the raw streams, rebinds every reported grade to its exact response and verifies the retained thermal and cleanup evidence. It performs no inference and does not execute generated code. The original Docker grading invocation, prepared samples, image identity, complete results and logs remain inspectable; rerunning the grader requires the declared image and sandbox settings.

The archive contains the complete compact raw capture, telemetry, grading and source receipt closure. It excludes model weights, runtime binaries, compiler installations and container layers; their exact hashes remain recorded and their native copies remain in the owning session. The Python source carries its MIT license. HumanEval and EvalPlus reference/evaluator material retain their own supplied MIT and Apache 2.0 notices. The optional UI failure log and subsequent successful API-only build receipts remain separate. Native absolute paths identify historical custody; the verifier uses paths relative to this extracted archive.
