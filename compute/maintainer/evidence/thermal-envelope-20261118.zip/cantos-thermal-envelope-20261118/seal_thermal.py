"""Seal the two stopped serving attempts and grade already completed responses only."""
import collections, datetime, hashlib, importlib.util, json, os, pathlib, shutil, socket, subprocess, sys, time
ROOT = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "analyzer"))
from streaming import parse_capture
from owner_ocl.runner import _strict_loads
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def load(p): return _strict_loads(pathlib.Path(p).read_text())
def write(p, v): pathlib.Path(p).write_text(json.dumps(v, indent=2, sort_keys=True) + "\n")
def artifact(p): return {"path":str(p.relative_to(ROOT)), "bytes":p.stat().st_size, "sha256":sha(p)}
def utc(t): return datetime.datetime.fromtimestamp(t, datetime.timezone.utc).isoformat()
specs = {"llama":"spec-llama.json", "llama-gpu0":"spec-llama-gpu0.json"}
jobs = {"llama":"cantos-empirical-llama-capture-20261118b", "llama-gpu0":"cantos-empirical-llama-gpu0-capture-20261118a"}
workload = load(ROOT / "workload.json")
assert sha(ROOT / "workload.json") == "29d2ccc7d2a987436dfab6990d38585f481c0f73e1b4a6774467fcb4a1940b70"
assert sha(ROOT / "humaneval-reference.jsonl") == "bf1d4a46ad8ac2c3082e7fe273ebeadd1eca561182ebaef6b0976ac8d9ed1d93"
assert sha(ROOT / "normalize.py") == "de8bd9e76891348f2f48f5451fff446561b0740c625a62bc095104c451b92391"
ns = importlib.util.spec_from_file_location("pinned_normalizer", ROOT / "normalize.py")
normalizer = importlib.util.module_from_spec(ns); ns.loader.exec_module(normalizer)
cases = {c["id"]:c for c in workload["cases"]}
image_id = "sha256:803e956852925ff35f8d7a9f55a97fbcfad09a8dfa77a439f5b2ac537702563d"
prepared = ROOT / "partial-grade-prepared"; prepared.mkdir(exist_ok=False)
for name in ["humaneval-reference.jsonl", "normalize.py", "workload.json"]:
    shutil.copy2(ROOT / name, prepared / name)
records, summaries, referenced_raw, task_counts = [], [], set(), collections.Counter()
def checked_observation(stem, arm, index, obs):
    folder = ROOT / (stem + "-capture") / arm
    assert len(obs["attempts"]) == 1
    attempt = obs["attempts"][0]
    path = (folder / attempt["raw_path"]).resolve()
    assert path.is_relative_to(folder.resolve())
    raw = load(path)
    parsed = parse_capture(raw)
    for field in ["response_text","response_sha256","error","transport_error","stream_error","finish_reason","stream_done"]:
        assert parsed[field] == attempt[field], (str(path), field)
    case = cases[obs["task_id"]]
    assert workload["cases"][obs["case_index"]]["id"] == obs["task_id"]
    spec = load(ROOT / specs[stem]); proto = spec["protocol"]
    expected_request = dict(model=spec[arm]["model"], messages=case["messages"], temperature=0,
        seed=proto["seed"], max_tokens=proto["max_tokens"], stream=True, stream_options={"include_usage":True}, **proto["extra_body"])
    assert raw["request"] == expected_request
    assert obs["trial"] == 0 and obs["repetition"] == 0 and not obs["warmup"]
    eligible = obs["accepted"] is None and parsed["error"] is None and parsed["finish_reason"] != "length"
    solution = normalizer.normalize(parsed["response_text"])
    return path, parsed, solution, eligible
for stem in specs:
    state = load(ROOT / (stem + "-serving/status.json"))
    samples = [_strict_loads(s) for s in (ROOT / (stem + "-serving/board-samples.jsonl")).read_text().splitlines()]
    assert state["stop_reason"] == "thermal threshold" and state["capture_exit_code"] == -15
    assert all(x["uuid"] == state["gpu_uuid"] for x in samples)
    cap = state["admission"]["power_limit_w"]
    assert all(x["power_limit_w"] == cap for x in samples)
    guard = next(x for x in samples if x["temperature_c"] >= 80)
    arms = {}
    for arm in ["baseline", "candidate"]:
        folder = ROOT / (stem + "-capture") / arm
        assert not (folder / "run.json").exists()
        observations = [_strict_loads(s) for s in (folder / "observations.jsonl").read_text().splitlines()]
        for index, obs in sorted(enumerate(observations), key=lambda pair:pair[1]["case_index"]):
            path, parsed, solution, eligible = checked_observation(stem, arm, index, obs)
            referenced_raw.add(str(path.relative_to(ROOT)))
            task_id = obs["task_id"]
            row = dict(attempt=stem, arm=arm, task_id=task_id, trial=obs["trial"], repetition=obs["repetition"],
                       observation_index=index, observation_file=str((folder/"observations.jsonl").relative_to(ROOT)),
                       observation_file_sha256=sha(folder/"observations.jsonl"),
                       raw_path=str(path.relative_to(ROOT)), raw_sha256=sha(path),
                       response_sha256=parsed["response_sha256"], solution_sha256=hashlib.sha256(solution.encode()).hexdigest(),
                       task_solution_index=task_counts[task_id], capture_eligible=eligible)
            task_counts[task_id] += 1; records.append((row, solution))
        raw_paths = sorted((folder/"raw").rglob("*.json"))
        parsed_counts = collections.Counter()
        for path in raw_paths:
            parsed = parse_capture(load(path))
            parsed_counts["valid_completed_stream" if parsed["error"] is None and parsed["stream_done"] else "stream_error"] += 1
        arms[arm] = dict(persisted_observations=len(observations), retained_stream_records=len(raw_paths),
                        stream_parse_counts=dict(parsed_counts), unique_observed_tasks=len({o["task_id"] for o in observations}),
                        observation_file_sha256=sha(folder/"observations.jsonl"), complete_run_receipt=False,
                        server_pid=state[arm]["pid"], server_exit_code=state[arm]["exit_code"])
    summaries.append(dict(attempt=stem, job=jobs[stem], gpu_uuid=state["gpu_uuid"], existing_power_limit_w=cap,
                          admission=state["admission"], capture_started_at=utc(state["capture_started_epoch"]),
                          capture_started_epoch=state["capture_started_epoch"], first_guard_at=utc(guard["epoch"]),
                          first_guard_epoch=guard["epoch"], capture_to_guard_seconds=guard["epoch"]-state["capture_started_epoch"],
                          cleanup_terminal_at=utc(state["terminal_epoch"]), cleanup_terminal_epoch=state["terminal_epoch"],
                          guard_to_cleanup_seconds=state["terminal_epoch"]-guard["epoch"],
                          recorded_peak_temperature_c=max(x["temperature_c"] for x in samples), samples=len(samples),
                          maximum_sampling_gap_seconds=max(b["monotonic_s"]-a["monotonic_s"] for a,b in zip(samples,samples[1:])),
                          capture_exit_code=state["capture_exit_code"], outer_job_exit_code=0 if stem=="llama" else 3,
                          model_sha256=state["model_sha256"], runtime_source_commit=state["source_commit"],
                          runtime_files=state["runtime_files"], capture_pid=state["capture_pid"],
                          status_sha256=sha(ROOT/(stem+"-serving/status.json")), arms=arms))
samples = [{"task_id":m["task_id"],"solution":s} for m,s in records]
(prepared/"humaneval.jsonl").write_text("".join(json.dumps(s)+"\n" for s in samples))
write(prepared/"mapping.json",[m for m,s in records])
image_meta = json.loads(subprocess.check_output(["docker","image","inspect",image_id],text=True))[0]
assert image_meta["Id"] == image_id
write(prepared/"grader-image.json",{k:image_meta.get(k) for k in ["Id","RepoTags","RepoDigests","Created"]})
cmd=["docker","run","--rm","--name","cantos-partial-evalplus-20261118","--network","none","--read-only",
     "--cap-drop","ALL","--security-opt","no-new-privileges","--pids-limit","512","--memory","8g","--cpus","4",
     "--user","1000:1000","--tmpfs","/tmp:rw,exec,size=2g","-e","HOME=/tmp","-e","XDG_CACHE_HOME=/tmp/cache",
     "-e","HUMANEVAL_OVERRIDE_PATH=/work/humaneval-reference.jsonl","-v",str(prepared)+":/work","-w","/work",
     "--entrypoint","/bin/sh",image_id,"-ec",
     'python -c \'import importlib.metadata as m; assert m.version("evalplus")=="0.3.1"\'; evalplus.evaluate --dataset humaneval --samples humaneval.jsonl --parallel 4 --min-time-limit 1 --gt-time-limit-factor 4']
invocation={"command":cmd,"started_epoch":time.time(),"source_sha256":sha(__file__),"samples_sha256":sha(prepared/"humaneval.jsonl")}
write(prepared/"grader-command.json",invocation)
with (prepared/"evalplus.log").open("wb") as log: proc=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=300)
invocation.update(exit_code=proc.returncode,ended_epoch=time.time());write(prepared/"grader-command.json",invocation)
assert proc.returncode==0,proc.returncode
results=load(prepared/"humaneval_eval_results.json")
assert results["hash"]==hashlib.md5((prepared/"humaneval-reference.jsonl").read_bytes()).hexdigest()
assert set(results["eval"])==set(task_counts)
assert all(len(results["eval"][task])==n for task,n in task_counts.items())
grades=[]
for row, solution in records:
    obs = [_strict_loads(s) for s in (ROOT/row["observation_file"]).read_text().splitlines()][row["observation_index"]]
    path, parsed, recomputed, eligible = checked_observation(row["attempt"],row["arm"],row["observation_index"],obs)
    assert sha(path)==row["raw_sha256"] and sha(ROOT/row["observation_file"])==row["observation_file_sha256"]
    assert recomputed==solution and parsed["response_sha256"]==row["response_sha256"]
    result=results["eval"][row["task_id"]][row["task_solution_index"]]
    assert result["solution"]==solution
    assert result["base_status"] in ["pass","fail","timeout"] and result["plus_status"] in ["pass","fail","timeout"]
    grades.append(dict(row, base_status=result["base_status"], plus_status=result["plus_status"],
                       accepted=bool(eligible and result["base_status"]=="pass" and result["plus_status"]=="pass")))
grade_summary={}
for stem in specs:
    grade_summary[stem]={}
    for arm in ["baseline","candidate"]:
        group=[x for x in grades if x["attempt"]==stem and x["arm"]==arm]
        grade_summary[stem][arm]={"accepted":sum(x["accepted"] for x in group),"completed_observations":len(group)}
write(prepared/"grades.json",{"schema":"cantos.empirical.partial-grades/1","scope":"Only persisted completed observation rows. No complete run receipt was synthesized. Candidate subsets are censored by thermal stops and cannot estimate full workload acceptance. Original three-trial comparison remains incomplete.","criterion":"base_status == pass AND plus_status == pass AND valid complete capture","workload_sha256":sha(ROOT/"workload.json"),"reference_sha256":sha(ROOT/"humaneval-reference.jsonl"),"normalizer_sha256":sha(ROOT/"normalize.py"),"grader_image":image_id,"results":grades,"summary":grade_summary})
unjoined=[]
for stem in specs:
    for path in sorted((ROOT/(stem+"-capture")).rglob("raw/**/*.json")):
        rel=str(path.relative_to(ROOT))
        if rel not in referenced_raw:unjoined.append(artifact(path))
# Post-cleanup proof uses exact recorded PIDs and only the four owned ports.
cleanup={"observed_at":utc(time.time()),"pids":[],"ports":[]}
for summary in summaries:
    for pid in [summary["capture_pid"]]+[x["server_pid"] for x in summary["arms"].values()]:
        p=pathlib.Path("/proc")/str(pid)
        cleanup["pids"].append({"pid":pid,"proc_exists":p.exists()})
for port in [19591,19592,19601,19602]:
    with socket.socket() as sock:
        sock.settimeout(1);cleanup["ports"].append({"loopback_port":port,"connect_ex":sock.connect_ex(("127.0.0.1",port))})
ledger_path=pathlib.Path("/home/jonathan/.local/state/tierdesk/gpu-reservations.json")
ledger=load(ledger_path);cleanup["lease_registry_sha256"]=sha(ledger_path)
cleanup["own_lease_present"]=any(v.get("owner") in ["cantos-maintainer-llama-20261118a","cantos-maintainer-llama-gpu0-20261118a"] for v in ledger.values())
cleanup["current_gpu_state"]=subprocess.check_output(["nvidia-smi","--query-gpu=index,uuid,power.limit,memory.used,utilization.gpu,temperature.gpu","--format=csv,noheader,nounits"],text=True)
assert not any(x["proc_exists"] for x in cleanup["pids"])
assert all(x["connect_ex"]!=0 for x in cleanup["ports"])
assert not cleanup["own_lease_present"]
write(ROOT/"strong-cleanup-proof.json",cleanup)
receipt={"schema":"cantos.empirical.operating-envelope/1","status":"thermal-guard-stopped-incomplete",
         "protocol":"Each attempt planned three paired trials of the predetermined 32 HumanEval tasks at client concurrency4; one versus four server slots, context4096 per slot, max_tokens1024, timeout120s. Both endpoints resident on one GPU.",
         "thermal_guard_c":80,"price_status":"unknown","attempts":summaries,"partial_grade_summary":grade_summary,
         "unjoined_raw_streams":unjoined,"request_count_scope":"Retained stream records are a lower bound on actual attempted requests. The collector termination may leave in-flight requests without durable raw records. Persisted observation counts are exact. No planned or missing request is represented as a measured completion.",
         "decision":"Both sustained serving attempts reached the existing guard. No complete three-trial comparison, qualified serving recommendation or full operating-cost result was produced.",
         "partial_grade_receipt":"partial-grade-prepared/grades.json","cleanup_proof":"strong-cleanup-proof.json",
         "guard_scope":"Recorded peak temperature and maximum sampling gap describe retained samples; temperatures between samples are not measured. Existing power limits were not changed.",
         "thermal_failure_receipt":"strong-thermal-stop-receipt.json","source":"seal_thermal.py"}
write(ROOT/"STRONG-OPERATING-ENVELOPE.json",receipt)
print(json.dumps({"status":receipt["status"],"partial_grade_summary":grade_summary,"unjoined_raw_streams":len(unjoined),"cleanup_proof":cleanup,"receipt_sha256":sha(ROOT/"STRONG-OPERATING-ENVELOPE.json")}),flush=True)
