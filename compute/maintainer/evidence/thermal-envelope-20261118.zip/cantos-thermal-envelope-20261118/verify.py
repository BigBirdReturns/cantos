#!/usr/bin/env python3
"""Verify this incomplete operating-envelope record without inference or code execution."""
import hashlib, importlib.util, json, pathlib, sys
sys.dont_write_bytecode = True
ROOT = pathlib.Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p): return json.loads(p.read_text())
manifest = load(ROOT / "MANIFEST.json")
expected = set()
for row in manifest["files"]:
    p = (ROOT / row["path"]).resolve()
    assert p.is_relative_to(ROOT) and not p.is_symlink()
    assert p.stat().st_size == row["bytes"] and sha(p) == row["sha256"], row["path"]
    expected.add(row["path"])
actual = {str(p.relative_to(ROOT)) for p in ROOT.rglob("*") if p.is_file()}
assert actual == expected | {"MANIFEST.json"}, (actual - expected - {"MANIFEST.json"})
sys.path.insert(0, str(ROOT / "analyzer"))
from streaming import parse_capture
from owner_ocl.runner import _strict_loads
ns = importlib.util.spec_from_file_location("pinned_normalizer", ROOT / "normalize.py")
normalizer = importlib.util.module_from_spec(ns); ns.loader.exec_module(normalizer)
receipt = load(ROOT / "STRONG-OPERATING-ENVELOPE.json")
assert receipt["status"] == "thermal-guard-stopped-incomplete"
grades = load(ROOT / "partial-grade-prepared/grades.json")
results = load(ROOT / "partial-grade-prepared/humaneval_eval_results.json")
assert grades["workload_sha256"] == sha(ROOT / "workload.json")
assert grades["reference_sha256"] == sha(ROOT / "humaneval-reference.jsonl")
assert grades["normalizer_sha256"] == sha(ROOT / "normalize.py")
assert results["hash"] == hashlib.md5((ROOT / "humaneval-reference.jsonl").read_bytes()).hexdigest()
workload = load(ROOT / "workload.json")
cases = {c["id"]:c for c in workload["cases"]}
seen = set()
for row in grades["results"]:
    raw_path = ROOT / row["raw_path"]
    assert sha(raw_path) == row["raw_sha256"]
    assert sha(ROOT / row["observation_file"]) == row["observation_file_sha256"]
    observations = [_strict_loads(s) for s in (ROOT / row["observation_file"]).read_text().splitlines()]
    obs = observations[row["observation_index"]]
    assert obs["task_id"] == row["task_id"] and obs["trial"] == row["trial"] and obs["repetition"] == row["repetition"]
    key = (row["attempt"],row["arm"],row["observation_index"]); assert key not in seen; seen.add(key)
    raw = _strict_loads(raw_path.read_text()); parsed = parse_capture(raw)
    assert parsed["response_sha256"] == row["response_sha256"] == obs["attempts"][-1]["response_sha256"]
    assert raw["request"]["messages"] == cases[row["task_id"]]["messages"]
    solution = normalizer.normalize(parsed["response_text"])
    assert hashlib.sha256(solution.encode()).hexdigest() == row["solution_sha256"]
    result = results["eval"][row["task_id"]][row["task_solution_index"]]
    assert result["solution"] == solution and result["base_status"] == row["base_status"] and result["plus_status"] == row["plus_status"]
    eligible = obs["accepted"] is None and parsed["error"] is None and parsed["finish_reason"] != "length"
    assert row["capture_eligible"] == eligible
    assert row["accepted"] == bool(eligible and row["base_status"] == "pass" and row["plus_status"] == "pass")
for attempt in receipt["attempts"]:
    stem = attempt["attempt"]
    status = load(ROOT / (stem + "-serving/status.json"))
    assert status["stop_reason"] == "thermal threshold" and status["capture_exit_code"] == -15
    samples = [_strict_loads(s) for s in (ROOT / (stem + "-serving/board-samples.jsonl")).read_text().splitlines()]
    assert max(x["temperature_c"] for x in samples) == attempt["recorded_peak_temperature_c"] == 80
    assert all(x["power_limit_w"] == attempt["existing_power_limit_w"] for x in samples)
    assert max(b["monotonic_s"]-a["monotonic_s"] for a,b in zip(samples,samples[1:])) == attempt["maximum_sampling_gap_seconds"]
    for arm, summary in attempt["arms"].items():
        folder = ROOT / (stem + "-capture") / arm
        assert not (folder / "run.json").exists()
        rows = (folder / "observations.jsonl").read_text().splitlines()
        group = [g for g in grades["results"] if g["attempt"] == stem and g["arm"] == arm]
        assert len(rows) == len(group) == summary["persisted_observations"]
        raws = list((folder / "raw").rglob("*.json"))
        assert len(raws) == summary["retained_stream_records"]
        for path in raws: parse_capture(_strict_loads(path.read_text()))
        assert sum(g["accepted"] for g in group) == grades["summary"][stem][arm]["accepted"]
cleanup = load(ROOT / "strong-cleanup-proof.json")
assert not cleanup["own_lease_present"] and not any(x["proc_exists"] for x in cleanup["pids"])
assert all(x["connect_ex"] != 0 for x in cleanup["ports"])
print(json.dumps({"verified":"incomplete thermal failure closure", "partial_grade_summary":grades["summary"],
                  "observations_graded":len(grades["results"]), "inference_requests":0,
                  "decision":"No complete comparison or qualified serving recommendation was produced."}, indent=2))
