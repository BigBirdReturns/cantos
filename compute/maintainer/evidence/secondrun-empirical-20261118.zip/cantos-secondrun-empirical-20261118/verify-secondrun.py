#!/usr/bin/env python3
"""Replay selective invalidation on retained real observations; performs no inference."""
import argparse, copy, hashlib, json, pathlib, subprocess, sys, time

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--evidence", required=True, type=pathlib.Path)
    ap.add_argument("--out", required=True, type=pathlib.Path)
    ap.add_argument("--source", type=pathlib.Path, default=pathlib.Path(__file__).resolve().parent / "source")
    args = ap.parse_args()
    evidence, out, source = args.evidence.resolve(), args.out.resolve(), args.source.resolve()
    expected = {
        "vllm-capture/baseline/run.json": "83b96eeb65fdf0de88fc4792e964469a2f8d0b0412d1c701c6eab268342fb2c9",
        "vllm-capture/candidate/run.json": "6cf3694f7a95ab11834fbf0c89434c5775f629f1f65571076300e2d890e430c6",
        "grade-baseline/grades.json": "af7ab10150754df5a60d228bd00b9e4d20c434f8aab4c9e688c3a2bd4d2ffd61",
        "grade-candidate/grades.json": "ef59626e3ad70f21c6bbcb562dbcdc2c8956d73c546e49ec447896a4fe4c95ab",
        "policy-vllm.json": "a1993b5c9e9491a18d6285e524025c818a78b5f8a36272af1e7751134ac04b40",
    }
    for path, digest in expected.items():
        assert sha(evidence / path) == digest, path
    out.mkdir(parents=True, exist_ok=False)
    policy = json.loads((evidence / "policy-vllm.json").read_text())
    write(out / "policy-current.json", policy)
    fixed = copy.deepcopy(policy)
    fixed["prices"] = {"baseline_per_hour": 1.0, "candidate_per_hour": 1.0}
    write(out / "policy-fixed-prices.json", fixed)
    shared = {
        "task_class": "maintainer-compare",
        "baseline": str(evidence / "vllm-capture/baseline/run.json"),
        "candidate": str(evidence / "vllm-capture/candidate/run.json"),
        "baseline_grades": str(evidence / "grade-baseline/grades.json"),
        "candidate_grades": str(evidence / "grade-candidate/grades.json"),
    }
    request = {"tasks": [
        dict(shared, id="current-policy", policy=str(out / "policy-current.json")),
        dict(shared, id="fixed-price-scenario", policy=str(out / "policy-fixed-prices.json")),
    ]}
    runs = []
    cmd = [sys.executable, "-B", str(source / "integration/work.py"), "--request",
           str(out / "request.json"), "--store", str(out / "store"), "--require-maintainer-pass"]

    def run(label, executed, reused, exit_code, verdicts):
        write(out / "request.json", request)
        write(out / (label + "-request.json"), request)
        (out / (label + "-policy.json")).write_bytes((out / "policy-current.json").read_bytes())
        start = time.time()
        proc = subprocess.run(cmd, text=True, capture_output=True, timeout=180, cwd=out)
        (out / (label + "-stdout.json")).write_text(proc.stdout)
        (out / (label + "-stderr.txt")).write_text(proc.stderr)
        value = json.loads(proc.stdout)
        assert proc.returncode == exit_code, (label, proc.returncode, proc.stderr)
        assert value["summary"] == {"executed": executed, "reused": reused, "held": 0}, value["summary"]
        assert [task["native_verdict"] for task in value["tasks"]] == verdicts
        assert all(value[key] == 0 for key in ("model_calls", "gpu_runs", "new_observations"))
        rec = dict(label=label, command=cmd, exit_code=proc.returncode,
                   summary=value["summary"], model_calls=0, gpu_runs=0, new_observations=0,
                   native_verdicts=verdicts, keys=[t["key"] for t in value["tasks"]],
                   started_epoch=start, ended_epoch=time.time(), receipt=value["receipt"])
        runs.append(rec)
        print(json.dumps(rec), flush=True)

    run("01-initial", 2, 0, 2, ["incomparable", "incomparable"])
    run("02-no-change", 0, 2, 2, ["incomparable", "incomparable"])
    assert runs[0]["keys"] == runs[1]["keys"]
    policy["prices"] = {"baseline_per_hour": 1.0, "candidate_per_hour": 2.0}
    write(out / "policy-current.json", policy)
    run("03-price-only", 1, 1, 2, ["incomparable", "incomparable"])
    assert runs[2]["keys"][0] != runs[1]["keys"][0]
    assert runs[2]["keys"][1] == runs[1]["keys"][1]
    request["tasks"][0]["candidate"] = str(evidence / "vllm-offline-candidate/run.json")
    request["tasks"][0].pop("candidate_grades")
    run("04-candidate-failure-evidence", 1, 1, 3, ["error", "incomparable"])
    assert runs[3]["keys"][0] != runs[2]["keys"][0]
    assert runs[3]["keys"][1] == runs[2]["keys"][1]
    for path, digest in expected.items():
        assert sha(evidence / path) == digest, path
    source_manifest = [{"path": str(p.relative_to(source)), "sha256": sha(p), "bytes": p.stat().st_size}
                       for p in sorted(source.rglob("*.py")) if "__pycache__" not in p.parts]
    write(out / "receipt.json", {
        "schema": "cantos.empirical.secondrun-recipient/1", "status": "verified",
        "scope": "Retained real vLLM observations. No inference or fresh observations. Explicit price values are illustrative assumptions.",
        "original_evidence_sha256": expected, "source_manifest": source_manifest, "runs": runs,
    })
    print("VERIFIED selective invalidation, unchanged original evidence, zero inference")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
