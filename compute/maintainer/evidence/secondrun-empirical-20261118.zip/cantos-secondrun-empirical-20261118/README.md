# SecondRun selective invalidation on real observations

The measured vLLM HumanEval evidence produced two retained comparisons. The initial invocation executed both; the unchanged invocation reused both; changing one price assumption recalculated one comparison and reused the independent comparison; replacing that task's candidate with the retained unavailable-endpoint evidence recalculated one comparison and propagated native error exit 3. All four invocations recorded zero model calls, GPU runs and new observations. The source snapshot is release commit 92a39104c5210d2d66afda84b7c899ba97ebfcef. The original raw responses, grades and 80% qualification policy retained their exact hashes. Both measured configurations remain incomparable under that floor, with 21/96 accepted observations per arm. The hourly prices 1.0 and 2.0 are explicit illustrative assumptions.

## Recipient replay

Obtain and extract `cantos-vllm-humaneval-evidence-20261118.zip`, SHA256 `c4bcb662a5c200a81a206d70d7d41d7a8a9d9fec9930634de05ca407d5f59a3e`, and this archive. Run the evidence archive's `verify.py` first to verify its complete raw and grading closure. From this extracted directory:

```sh
python3 -B verify-secondrun.py --evidence ../cantos-vllm-humaneval-evidence-20261118 --out ../secondrun-recipient-output
```

The output path must be new. Python 3 and its standard library suffice. The script creates a fresh store and checks all four actual state transitions without requiring a GPU, service, API key or inference request. Native comparison exit 2 and error exit 3 are expected and checked; the enclosing verifier exits 0 only after all assertions pass. To exercise another delivered source tree, supply `--source /absolute/path/to/kit-root`, containing `integration/work.py` and `compute/maintainer`. The receipt pins the Python sources actually exercised.

`native-qualification/` preserves the original receipts, requests, assumptions, source archive and complete computation store. Its absolute paths are historical custody metadata. The replay script resolves the extracted evidence and builds a new portable store. `recipient-verification.json` records the independent fresh-store replay. The dependency archive retains the HumanEval, EvalPlus and model licenses and unchanged application evidence; this archive contains the MIT source and measurement bookkeeping. The result qualifies retained-evidence reuse and failure propagation. Original broader accelerator, provider-operation and full-cost outcomes remain separately open.
