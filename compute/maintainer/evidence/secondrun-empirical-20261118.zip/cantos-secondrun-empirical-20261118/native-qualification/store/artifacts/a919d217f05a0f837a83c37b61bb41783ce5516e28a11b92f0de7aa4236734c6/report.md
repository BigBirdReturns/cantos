# Cantos maintainer verdict

**ERROR**

- candidate: captured transport or stream errors
- candidate: response model differs from requested identity or is absent
- candidate: /v1/models does not confirm requested model at before
- candidate: /v1/models does not confirm requested model at after
- undeclared changed condition: observed.version
- baseline acceptance is insufficient to establish a usable reference
- candidate acceptance falls below requirement
- candidate acceptance drop exceeds policy
- newly failing baseline-accepted task instances exceed max_new_failures
- accepted_per_s median paired-trial ratio exceeds policy

| Metric | Baseline | Candidate |
| --- | ---: | ---: |
| total_tasks | 96 | 96 |
| accepted_tasks | 21 | 0 |
| acceptance_rate | 0.21875 | 0.0 |
| p95_latency_s | unmeasured | unmeasured |
| p95_ttft_s | unmeasured | unmeasured |
| accepted_per_s | 0.20309334417508806 | 0.0 |
| peak_request_concurrency | 4 | 4 |
| cost_per_accepted | 0.001367734520823606 | unpriced |

## Evidence scope

- This verdict covers the supplied workload, serving endpoints and policy only.
- Declared weights, hardware, tokenizer and server flags are operator declarations; HTTP probes do not attest them.
- Repeated cases are correlated. Trial ranges describe variation and are not a population confidence guarantee.
- TTFT measures first visible content at the client, including network and queueing; content chunks are not tokens.
- Token counts come from server usage. The instrument does not manufacture per-token timings, power or GPU run counts.
- No request retries. Transport and incomplete stream failures are retained and force an error verdict.
- Server cache state, co-tenancy, thermals and load require operator controls and declared identity settings.
