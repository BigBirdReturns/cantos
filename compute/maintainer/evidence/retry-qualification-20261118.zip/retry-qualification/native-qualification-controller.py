"""Native, finite end-to-end retry instrumentation qualification.
Uses existing local weights and the existing digest-pinned EvalPlus image.
The eight case positions are fixed before any new result is observed.
"""
import copy,hashlib,json,os,pathlib,shutil,signal,subprocess,sys,time
BASE=pathlib.Path('/mnt/w03data/Incoming/DataArray/Projects/Products/Cantos/sessions/claims-verification-20261118')
SOURCE=pathlib.Path('/mnt/w03data/Incoming/DataArray/Projects/Products/Cantos/worktrees/claims-verification-20261118')
OLD=pathlib.Path('/mnt/w03data/Incoming/DataArray/Projects/Products/Cantos/sessions/maintainer-empirical-20261118')
RUN=BASE/'live-r01'
GPU='GPU-64559d3d-dd59-05ac-1531-88ac32ddc58b'
POSITIONS=[0,4,8,12,16,20,24,28]
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
def invoke(name,argv,timeout=120):
    started=time.monotonic_ns()
    with (RUN/(name+'.log')).open('xb') as log:
        r=subprocess.run([str(x) for x in argv],stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
    write(RUN/(name+'-invocation.json'),{'argv':[str(x) for x in argv],'exit_code':r.returncode,'started_monotonic_ns':started,'ended_monotonic_ns':time.monotonic_ns()})
    print(name+': '+str(r.returncode),flush=True)
    return r.returncode
def main():
    RUN.mkdir(exist_ok=False)
    state={'schema':'cantos.retry.native-qualification/1','status':'preparing','evidence_class':'real-model-and-isolated-evalplus-with-observed-gpu-board-power','scope':'instrument qualification on fixed small workload, not model ranking or Hy4 execution','case_positions':POSITIONS,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip(),'started_epoch':time.time()}
    write(RUN/'status.json',state)
    instrument=RUN/'instrument'
    shutil.copytree(SOURCE/'compute/maintainer',instrument,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
    write(RUN/'source-manifest.json',{'source_head':state['source_head'],'files':[{'path':str(p.relative_to(instrument)),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(instrument.rglob('*')) if p.is_file()]})
    inputs=RUN/'inputs';inputs.mkdir()
    work=json.loads((OLD/'workload.json').read_text())
    work['cases']=[work['cases'][i] for i in POSITIONS]
    work['name']='HumanEval+ fixed-position eight-case retry instrument qualification'
    work['version']='2026-11-18-retry-qualification-1'
    work['description']='Predeclared positions 0,4,8,12,16,20,24,28 from the existing 32-case workload. One instrument qualification trial; no model ranking.'
    selected={c['id'] for c in work['cases']}
    reference=[json.loads(s) for s in (OLD/'humaneval-reference.jsonl').read_text().splitlines() if s.strip()]
    reference=[r for r in reference if r['task_id'] in selected]
    assert {r['task_id'] for r in reference}==selected and len(reference)==8
    (inputs/'reference.jsonl').write_text(''.join(json.dumps(r,sort_keys=True,separators=(',',':'),ensure_ascii=False)+'\n' for r in reference))
    for c in work['cases']:c['expect']['grader']['reference_sha256']=sha(inputs/'reference.jsonl')
    write(inputs/'workload.json',work)
    shutil.copyfile(OLD/'normalize.py',inputs/'normalize.py')
    assert sha(inputs/'normalize.py')==work['cases'][0]['expect']['grader']['normalizer_sha256']
    spec=json.loads((OLD/'spec-vllm.json').read_text())
    config=spec['baseline'];config['base_url']='http://127.0.0.1:19641/v1';config['model']='qwen3-06b-retry'
    config['identity']['hardware']['description']='OCTO-W03 Quadro RTX8000 GPU0, existing200W limit, one owned endpoint; separate GPU1/host workloads may coexist'
    config['identity']['settings']={'enforce_eager':True,'gpu_memory_utilization':0.15,'max_num_seqs':2,'prefix_cache':False,'one_endpoint_resident':True}
    spec['baseline']=config;spec['candidate']=copy.deepcopy(config);spec['workload']='workload.json';spec['policy']='policy.json'
    spec['protocol'].update(trials=1,concurrency=2,repeats=1,warmup=0,seed=1729,timeout_s=60,max_tokens=512)
    write(inputs/'spec.json',spec)
    shutil.copyfile(OLD/'policy-vllm.json',inputs/'policy.json')
    write(inputs/'retry-policy.json',{'schema':'cantos.maintainer.retry-policy/1','max_attempts':3,'backoff_s':0.1,'retry_on':['rejected','transport_error'],'attempt_seed_stride':0})
    state.update(case_ids=sorted(selected),input_sha256={p.name:sha(p) for p in sorted(inputs.iterdir())},status='starting-serving')
    write(RUN/'status.json',state)
    server_text=(BASE/'serve_qwen_retry.py').read_text()
    server_text=server_text.replace("OUT=ROOT/'live-serving'","ROOT=ROOT/'live-r01'\nOUT=ROOT/'serving'")
    server_text=server_text.replace("OWNER='cantos-retry-live-20261118a'","OWNER='cantos-retry-native-20261118a'")
    (RUN/'serve.py').write_text(server_text)
    server=None;sampler=None
    try:
        server_log=(RUN/'serving-driver.log').open('xb')
        server=subprocess.Popen([sys.executable,'-u',str(RUN/'serve.py')],stdout=server_log,stderr=subprocess.STDOUT)
        deadline=time.monotonic()+260
        while time.monotonic()<deadline:
            if server.poll() is not None:raise RuntimeError('owned serving launch failed; retained serving status/log')
            p=RUN/'serving/status.json'
            if p.exists() and json.loads(p.read_text()).get('status')=='ready':break
            time.sleep(1)
        else:raise RuntimeError('owned serving readiness expired')
        print('real model ready',flush=True)
        sampler_log=(RUN/'sampler.log').open('xb')
        sampler=subprocess.Popen([sys.executable,'-B',str(instrument/'retry_resources.py'),'record','--out',str(RUN/'power.jsonl'),'--device',GPU,'--stop-file',str(RUN/'STOP-POWER'),'--interval-s','0.25','--max-gap-s','2.5','--max-seconds','1200'],stdout=sampler_log,stderr=subprocess.STDOUT)
        deadline=time.monotonic()+15
        while time.monotonic()<deadline:
            if sampler.poll() is not None:raise RuntimeError('sampler failed before campaign')
            p=RUN/'power.jsonl'
            if p.exists() and any(json.loads(line).get('kind')=='power_sample' for line in p.read_text().splitlines()):break
            time.sleep(0.2)
        else:raise RuntimeError('no initial board power sample')
        state['status']='running-campaign';write(RUN/'status.json',state)
        args=[sys.executable,'-B',instrument/'retry.py','run','--spec',inputs/'spec.json','--arm','baseline','--retry-policy',inputs/'retry-policy.json','--out',RUN/'campaign','--observation-id','qwen06b-retry-instrument-20261118-r01','--evalplus-reference',inputs/'reference.jsonl','--evalplus-normalizer',inputs/'normalize.py','--grader-timeout-s','120']
        code=invoke('campaign',args,1200);state['campaign_exit_code']=code
        (RUN/'STOP-POWER').write_text('Campaign reached terminal process state.\n')
        sampler.wait(timeout=15);state['sampler_exit_code']=sampler.returncode
        if code!=0:raise RuntimeError('campaign evidence incomplete; inspect retained receipt and grader logs')
        if sampler.returncode!=0:raise RuntimeError('sampler failed; energy unqualified')
        campaign=RUN/'campaign/retry-campaign.json'
        for name,args in [
            ('validate',[sys.executable,'-B',instrument/'retry.py','validate','--path',campaign]),
            ('inspect',[sys.executable,'-B',instrument/'retry.py','inspect','--path',RUN/'campaign']),
            ('seal',[sys.executable,'-B',instrument/'retry_resources.py','seal','--campaign',campaign,'--journal',RUN/'power.jsonl','--out',RUN/'telemetry.json']),
            ('resources',[sys.executable,'-B',instrument/'retry_resources.py','analyze','--campaign',campaign,'--telemetry',RUN/'telemetry.json','--out',RUN/'resources.json'])]:
            if invoke(name,args)!=0:raise RuntimeError(name+' qualification failed')
        c=json.loads(campaign.read_text());r=json.loads((RUN/'resources.json').read_text())
        state.update(status='complete',metrics=c['metrics'],resources=r,files={str(p.relative_to(RUN)):sha(p) for p in (campaign,RUN/'power.jsonl',RUN/'telemetry.json',RUN/'resources.json',RUN/'source-manifest.json')})
        print(json.dumps({'metrics':state['metrics'],'energy':r['energy']}),flush=True)
    except Exception as exc:
        state.update(status='failed',error=type(exc).__name__+': '+str(exc));print(state['error'],flush=True)
    finally:
        if sampler is not None and sampler.poll() is None:
            (RUN/'STOP-POWER').write_text('Parent cleanup.\n')
            try:sampler.wait(timeout=15)
            except subprocess.TimeoutExpired:sampler.terminate();sampler.wait(timeout=10)
        (RUN/'STOP-RETRY-SERVER').write_text('Native qualification terminal; release owned endpoint and lease.\n')
        if server is not None and server.poll() is None:
            try:server.wait(timeout=30)
            except subprocess.TimeoutExpired:server.terminate();server.wait(timeout=30)
        state.update(ended_epoch=time.time(),server_exit_code=server.returncode if server else None)
        state['owned_lease_remaining']=json.loads(pathlib.Path('/home/jonathan/.local/state/tierdesk/gpu-reservations.json').read_text()).get(GPU,{}).get('owner')=='cantos-retry-native-20261118a'
        write(RUN/'status.json',state)
        print(json.dumps({'status':state['status'],'owned_lease_remaining':state['owned_lease_remaining']}),flush=True)
    return int(state['status']!='complete')
if __name__=='__main__':raise SystemExit(main())
