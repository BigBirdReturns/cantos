"""Verify retained retry evidence without model, Docker or GPU access."""
import hashlib,json,pathlib,sys
ROOT=pathlib.Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((ROOT/'MANIFEST.json').read_text())
for name,record in manifest['files'].items():
    p=(ROOT/name).resolve()
    assert p.is_relative_to(ROOT) and p.is_file(),name
    assert p.stat().st_size==record['bytes'] and sha(p)==record['sha256'],name
sys.path.insert(0,str(ROOT/'instrument'))
import retry,retry_resources
campaign=ROOT/'campaign/retry-campaign.json'
c=retry.validate_campaign(campaign)
assert c['status']=='complete'
i=retry.inspect_journal(ROOT/'campaign')
assert i['automatic_replay_authorized'] is False
original=json.loads((ROOT/'resources.json').read_text())
again=retry_resources.summarize(campaign,ROOT/'telemetry.json')
for key in ('campaign','observation_id','clock_identity','campaign_window_s','campaign_duration_s','accepted_tasks','energy','economics','actual_total_cost_usd','source_code'):
    assert original[key]==again[key],key
print(json.dumps({'status':'pass','verified_files':len(manifest['files']),'metrics':c['metrics'],'energy':again['energy'],'automatic_replay_authorized':False},sort_keys=True))
