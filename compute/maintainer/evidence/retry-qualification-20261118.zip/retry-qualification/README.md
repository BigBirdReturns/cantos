# Native retry instrumentation proof

Run python -B verify.py here to validate all hashes, source-bound captures and grades, durable retry accounting and the exact power join without model inference, Docker or GPU access. The complete receipt is status.json; the raw campaign is campaign/; power.jsonl retains observed GPU board samples. The fixed eight-task Qwen3-0.6B test qualifies the instrument and reports its actual successes and failures. It supplies no Hy4 performance result or model ranking. Costs remain unknown.

The retained source snapshot omits only historical evidence ZIP payloads that remain independently shipped in the parent kit. Every production Python module and all actual campaign artifacts retain their original bytes. Synthetic acceptance checks remain explicitly classified under independent-review/.
