"""Finite existing-Qwen service for the new retry-accounting protocol.
Preserves vendor/firmware protection and existing power/cooling configuration.
This is a distinct instrument qualification, not a repeat of the stopped 30B run.
"""
import fcntl,hashlib,json,os,pathlib,signal,socket,subprocess,threading,time,urllib.request
ROOT=pathlib.Path('/mnt/w03data/Incoming/DataArray/Projects/Products/Cantos/sessions/claims-verification-20261118')
ROOT=ROOT/'live-r01'
OUT=ROOT/'serving'
REG=pathlib.Path('/home/jonathan/.local/state/tierdesk/gpu-reservations.json')
UUID='GPU-64559d3d-dd59-05ac-1531-88ac32ddc58b'
OWNER='cantos-retry-native-20261118a'
MODEL=pathlib.Path('/srv/w03/scratch/vllm-independent-20261116/model')
PYTHON='/srv/w03/scratch/vllm-independent-20261116/.venv/bin/python'
PORT=19641
MAX_SECONDS=1500
stop=threading.Event()
state={'schema':'cantos.retry.serving/1','owner':OWNER,'status':'preflight','started_epoch':time.time(),'gpu_uuid':UUID,'port':PORT,'max_seconds':MAX_SECONDS,'protocol':'New retry campaign over eight predeclared HumanEval+ tasks with exact pinned external grading; single Qwen3-0.6B endpoint.','energy_scope':'Gross selected GPU0 board campaign window; CPU grader, server startup and facility excluded.','thermal_control':'Existing vendor/firmware protection; telemetry observation, no new software thermal cutoff or power change.'}
process=None;claimed=False
def sha(path):
 h=hashlib.sha256()
 with pathlib.Path(path).open('rb') as f:
  for b in iter(lambda:f.read(8<<20),b''):h.update(b)
 return h.hexdigest()
def save():
 t=OUT/'status.tmp';t.write_text(json.dumps(state,indent=2)+'\n');t.replace(OUT/'status.json')
def gpu():
 r=subprocess.run(['nvidia-smi','--id='+UUID,'--query-gpu=uuid,power.draw,memory.used,utilization.gpu,temperature.gpu,power.limit','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=10,check=True)
 x=[s.strip() for s in r.stdout.strip().split(',')]
 if x[0]!=UUID:raise RuntimeError('GPU identity mismatch')
 return {'uuid':UUID,'watts':float(x[1]),'memory_mib':float(x[2]),'util_pct':float(x[3]),'temperature_c':float(x[4]),'power_limit_w':float(x[5]),'monotonic_s':time.monotonic()}
def lease(action):
 global claimed
 with REG.with_suffix('.lock').open('a') as f:
  fcntl.flock(f,fcntl.LOCK_EX)
  d=json.loads(REG.read_text()) if REG.exists() else {}
  if action=='claim':
   if float(d.get(UUID,{}).get('expires_epoch',0))>time.time():raise RuntimeError('Foreign GPU lease active')
   g=gpu()
   active=subprocess.check_output(['nvidia-smi','--id='+UUID,'--query-compute-apps=pid','--format=csv,noheader'],text=True,timeout=10).strip()
   if active or g['memory_mib']>512 or g['util_pct']>5:raise RuntimeError('GPU has another allocation')
   state['admission']=g
   d[UUID]={'owner':OWNER,'reason':'New retry-accounting qualification, existing small model','claimed_epoch':time.time(),'expires_epoch':time.time()+MAX_SECONDS+90}
  elif d.get(UUID,{}).get('owner')==OWNER:d.pop(UUID)
  t=REG.with_name(OWNER+'-lease.tmp');t.write_text(json.dumps(d,indent=2)+'\n');t.replace(REG)
  if action=='claim':claimed=True
def get(path):
 with urllib.request.urlopen('http://127.0.0.1:'+str(PORT)+path,timeout=3) as response:return response.read()
def main():
 global process
 OUT.mkdir(exist_ok=False);save()
 try:
  with socket.socket() as s:s.bind(('127.0.0.1',PORT))
  state['model_sha256']=sha(MODEL/'model.safetensors')
  if state['model_sha256']!='f47f71177f32bcd101b7573ec9171e6a57f4f4d31148d38e382306f42996874b':raise RuntimeError('Unexpected model weights')
  state['tokenizer_sha256']=sha(MODEL/'tokenizer.json')
  state['runtime_versions']=subprocess.check_output([PYTHON,'-c','import json,platform,importlib.metadata as m;print(json.dumps({"python":platform.python_version(),"vllm":m.version("vllm"),"torch":m.version("torch")}))'],text=True).strip()
  lease('claim')
  env={**os.environ,'CUDA_VISIBLE_DEVICES':UUID,'VLLM_WORKER_MULTIPROC_METHOD':'spawn','PYTHONUNBUFFERED':'1','OMP_NUM_THREADS':'2','MKL_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'1','NUMEXPR_NUM_THREADS':'1','HF_HUB_OFFLINE':'1'}
  cmd=[PYTHON,'-m','vllm.entrypoints.openai.api_server','--model',str(MODEL),'--served-model-name','qwen3-06b-retry','--host','127.0.0.1','--port',str(PORT),'--dtype','float16','--max-model-len','4096','--enforce-eager','--gpu-memory-utilization','0.15','--max-num-seqs','2','--disable-prefix-caching']
  log=(OUT/'server.log').open('wb');process=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,start_new_session=True)
  state.update(status='starting',pid=process.pid,command=cmd);save();deadline=time.monotonic()+240
  while time.monotonic()<deadline and not stop.is_set():
   if process.poll() is not None:raise RuntimeError('Server exited '+str(process.returncode))
   try:
    get('/health');(OUT/'models.json').write_bytes(get('/v1/models'));break
   except Exception:pass
   stop.wait(2)
  else:raise RuntimeError('Readiness deadline')
  state.update(status='ready',ready_epoch=time.time());save();print('READY',flush=True)
  with (OUT/'operating-telemetry.jsonl').open('x') as f:
   while not stop.wait(2):
    g=gpu();f.write(json.dumps(g)+'\n');f.flush()
    if json.loads(REG.read_text()).get(UUID,{}).get('owner')!=OWNER:raise RuntimeError('Resource ownership changed')
    if process.poll() is not None:raise RuntimeError('Owned service exited')
    if (ROOT/'STOP-RETRY-SERVER').exists():state['stop_reason']='completed qualification';break
    if time.time()-state['started_epoch']>=MAX_SECONDS:state['stop_reason']='finite service deadline';break
  state['status']='stopped'
 except Exception as exc:
  state.update(status='failed',error=type(exc).__name__+': '+str(exc));print(state['error'],flush=True)
 finally:
  if process is not None and process.poll() is None:
   os.killpg(process.pid,signal.SIGTERM)
   try:process.wait(timeout=15)
   except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=5)
  if claimed:lease('release')
  state.update(ended_epoch=time.time(),final_gpu=gpu());save();print(json.dumps(state),flush=True)
 return int(state['status']=='failed')
if __name__=='__main__':
 for sig in (signal.SIGTERM,signal.SIGINT):signal.signal(sig,lambda *_:stop.set())
 raise SystemExit(main())
