#!/usr/bin/env python3
"""Integrated resource CLI acceptance against real retry campaign receipts.
Telemetry and prices are explicitly synthetic arithmetic fixtures, not measurements.
"""
import argparse,hashlib,json,subprocess,sys
from pathlib import Path
from independent_cli_oracle import dump

def main():
    ap=argparse.ArgumentParser();ap.add_argument("--worktree",required=True);ap.add_argument("--oracle",required=True);ap.add_argument("--out",required=True)
    a=ap.parse_args();work=Path(a.worktree).resolve();oracle=Path(a.oracle).resolve();root=Path(a.out).resolve();root.mkdir(parents=True,exist_ok=False)
    cli=work/"compute/maintainer/retry_resources.py";checks=[];errors=[]
    def check(name,ok,actual=None,expected=None):
        checks.append({"check":name,"passed":bool(ok),"actual":actual,"expected":expected})
        if not ok:errors.append(name)
    def invoke(name,campaign,telemetry=None,scenario=None):
        cmd=[sys.executable,"-B",str(cli),"analyze","--campaign",str(campaign),"--out",str(root/(name+"-result.json"))]
        if telemetry:cmd+=["--telemetry",str(telemetry)]
        if scenario:cmd+=["--scenario",str(scenario)]
        p=subprocess.run(cmd,capture_output=True,text=True,timeout=60)
        dump(root/(name+"-invocation.json"),{"command":cmd,"exit":p.returncode,"stdout":p.stdout,"stderr":p.stderr})
        return p,json.loads(p.stdout)
    def telemetry(name,campaign,error=False,wrong_clock=False,incomplete=False):
        directory=root/name;directory.mkdir()
        raw=campaign.read_bytes();c=json.loads(raw);start=c["started_monotonic_s"];end=c["ended_monotonic_s"];d=end-start
        clock=dict(c["clock_identity"])
        if wrong_clock:clock["hostname"]="unrelated-host"
        head={"kind":"sampler_started","clock_identity":clock,"devices":["GPU-fixture-A","GPU-fixture-B"],
              "max_gap_s":max(1,2*d),"producer":{"name":"independent-arithmetic-fixture","source":"No hardware telemetry"},
              "observed_at":"fixture","t_s":start-.2,"sensor":"synthetic watts for accounting qualification"}
        samples=[{"kind":"power_sample","t_s":t,"readings":[{"device_uuid":"GPU-fixture-A","watts":50},
                                                          {"device_uuid":"GPU-fixture-B","watts":25}]} for t in (start-.1,(start+end)/2,end+.1)]
        if error:samples.insert(1,{"kind":"sample_error","t_s":start+d*.25,"error":"injected-sensor-failure"})
        events=[head]+samples+([] if incomplete else [{"kind":"sampler_ended","t_s":end+.2,"reason":"fixture-complete"}])
        journal=directory/"power.jsonl";journal.write_text("".join(json.dumps(e)+"\n" for e in events))
        receipt={"schema":"cantos.retry.telemetry/1","campaign_sha256":hashlib.sha256(raw).hexdigest(),
                 "observation_id":c["observation_id"],"clock_identity":clock,"devices":head["devices"],
                 "max_gap_s":head["max_gap_s"],"producer":head["producer"],"observed_at":"fixture",
                 "samples":{"path":journal.name,"sha256":hashlib.sha256(journal.read_bytes()).hexdigest(),"bytes":journal.stat().st_size},
                 "sensor":head["sensor"],"attribution":"Synthetic arithmetic; no observed energy",
                 "evidence_class":"synthetic-accounting-fixture"}
        out=directory/"telemetry.json";dump(out,receipt);return out,d
    values={"capex_usd":0,"residual_usd":0,"life_hours":1,"utilization":1,"financing_usd_per_hour":0,"hosting_usd_per_hour":3600,
            "operations_usd_per_hour":0,"maintenance_usd_per_hour":0,"network_usd_per_hour":0,"electricity_usd_per_kwh":0,
            "pue":1,"intervention_seconds":0,"intervention_usd_per_hour":0,"average_it_power_w":0}
    scenario={"schema":"cantos.retry.cost-scenario/1","currency":"USD","values":values,
              "field_sources":{key:"Explicit arithmetic fixture assumption, not observed spending" for key in values}}
    scenario_path=root/"scenario.json";dump(scenario_path,scenario)
    mixed=oracle/"mixed/campaign/retry-campaign.json";zero=oracle/"zero/campaign/retry-campaign.json"
    try:
        power,d=telemetry("mixed-power",mixed)
        p,r=invoke("complete",mixed,power,scenario_path)
        check("complete_analysis_succeeds",p.returncode==0,{"exit":p.returncode,"result":r},0)
        check("actual_denominator_is_three",r["accepted_tasks"]==3,r["accepted_tasks"],3)
        check("all_window_energy_over_all_successes",abs(r["energy"]["gross_board_joules"]-75*d)<1e-6,r["energy"]["gross_board_joules"],75*d)
        check("energy_per_success_uses_three",abs(r["energy"]["gross_board_joules_per_accepted_task"]-25*d)<1e-6,r["energy"]["gross_board_joules_per_accepted_task"],25*d)
        check("source_synthetic_class_preserved",r["energy"]["evidence_class"]=="synthetic-accounting-fixture")
        check("cost_includes_whole_campaign",abs(r["economics"]["total_usd"]-d)<1e-8,r["economics"]["total_usd"],d)
        check("cost_per_success_uses_three",abs(r["economics"]["modeled_cost_per_accepted_usd"]-d/3)<1e-8,r["economics"]["modeled_cost_per_accepted_usd"],d/3)
        check("observed_spending_stays_unknown",r["actual_total_cost_usd"] is None and r["economics"]["actual_total_cost_usd"] is None)
        p,r=invoke("missing-resource",mixed)
        check("missing_energy_and_cost_remain_unknown",p.returncode==0 and r["energy"] is None and r["economics"] is None)
        partial=json.loads(json.dumps(scenario));del partial["values"]["network_usd_per_hour"];del partial["field_sources"]["network_usd_per_hour"]
        partial_path=root/"partial-scenario.json";dump(partial_path,partial)
        p,r=invoke("missing-price",mixed,power,partial_path)
        check("missing_component_prevents_complete_cost",p.returncode==0 and r["economics"]["total_usd"] is None and r["economics"]["modeled_cost_per_accepted_usd"] is None)
        zp,zd=telemetry("zero-power",zero)
        p,r=invoke("zero-success",zero,zp,scenario_path)
        check("zero_success_preserves_gross_energy",p.returncode==0 and abs(r["energy"]["gross_board_joules"]-75*zd)<1e-6)
        check("zero_success_ratios_null",r["energy"]["gross_board_joules_per_accepted_task"] is None and r["economics"]["modeled_cost_per_accepted_usd"] is None)
        bad,_=telemetry("wrong-clock",mixed,wrong_clock=True);p,r=invoke("wrong-clock",mixed,bad)
        check("cross_host_clock_refused",p.returncode!=0,{"exit":p.returncode,"result":r})
        bad,_=telemetry("sample-failure",mixed,error=True);p,r=invoke("sample-failure",mixed,bad)
        check("sensor_failure_preserves_unknown_energy",p.returncode==0 and r["energy"]["gross_board_joules"] is None)
        bad,_=telemetry("incomplete",mixed,incomplete=True);p,r=invoke("incomplete",mixed,bad)
        check("incomplete_telemetry_refused",p.returncode!=0,{"exit":p.returncode,"result":r})
        p,r=invoke("wrong-campaign",zero,power)
        check("telemetry_bound_to_actual_campaign",p.returncode!=0,{"exit":p.returncode,"result":r})
    except Exception as exc:errors.append(type(exc).__name__+": "+str(exc))
    report={"schema":"cantos.independent-retry-resources-review/1","source":str(cli),"source_sha256":hashlib.sha256(cli.read_bytes()).hexdigest(),
            "classification":"Real validated retry-campaign fixture plus synthetic energy/cost arithmetic; no model-energy or spend claim",
            "checks":checks,"errors":errors,"passed":not errors and all(x["passed"] for x in checks)}
    dump(root/"REVIEW.json",report);print(json.dumps({"passed":report["passed"],"checks":len(checks),"errors":errors,"report":str(root/"REVIEW.json")}))
    return 0 if report["passed"] else 1
if __name__=="__main__":raise SystemExit(main())
